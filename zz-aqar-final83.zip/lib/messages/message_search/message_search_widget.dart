import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/messages/components/card_message/card_message_widget.dart';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'message_search_model.dart';
export 'message_search_model.dart';

class MessageSearchWidget extends StatefulWidget {
  const MessageSearchWidget({super.key});

  static String routeName = 'MessageSearch';
  static String routePath = '/messageSearch';

  @override
  State<MessageSearchWidget> createState() => _MessageSearchWidgetState();
}

class _MessageSearchWidgetState extends State<MessageSearchWidget> {
  String _query = '';

  /// محادثاتي مع بيانات الطرف الآخر — تُحمَّل مرة عند الفتح.
  /// البحث على أسماء المستخدمين الحقيقيين لا على قائمة ثابتة.
  late final Future<List<_ChatHit>> _chats = _loadChats();

  Future<List<_ChatHit>> _loadChats() async {
    final me = currentUserReference;
    if (me == null) return const [];
    final snap = await ChatsRecord.collection
        .where('users', arrayContains: me)
        .get();
    final out = <_ChatHit>[];
    for (final d in snap.docs) {
      final c = ChatsRecord.fromSnapshot(d);
      if (c.deletedFor.contains(me)) continue;
      final others = c.users.where((u) => u != me);
      if (others.isEmpty) continue;
      try {
        final u = await UsersRecord.getDocumentOnce(others.first);
        out.add(_ChatHit(
            chat: c, name: u.displayName, photo: u.photoUrl, phone: u.phoneNumber));
      } catch (_) {
        out.add(_ChatHit(chat: c, name: '', photo: '', phone: ''));
      }
    }
    out.sort((a, b) => (b.chat.lastMessageTime ?? DateTime(2000))
        .compareTo(a.chat.lastMessageTime ?? DateTime(2000)));
    return out;
  }

  /// مطابقة متسامحة مع الهمزات والتاء المربوطة والتشكيل
  static String _norm(String t) => t
      .replaceAll(RegExp(r'[\u064B-\u065F\u0670\u0640]'), '')
      .replaceAll(RegExp('[أإآٱ]'), 'ا')
      .replaceAll('ة', 'ه')
      .replaceAll('ى', 'ي')
      .toLowerCase()
      .trim();

  late MessageSearchModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => MessageSearchModel());

    _model.textController ??= TextEditingController();
    _model.textFieldFocusNode ??= FocusNode();
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    context.watch<FFAppState>();

    return GestureDetector(
      onTap: () {
        FocusScope.of(context).unfocus();
        FocusManager.instance.primaryFocus?.unfocus();
      },
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
        appBar: PreferredSize(
          preferredSize: Size.fromHeight(0.0),
          child: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).secondaryBackground,
            automaticallyImplyLeading: false,
            actions: [],
            centerTitle: true,
            elevation: 0.0,
          ),
        ),
        body: SafeArea(
          child: Column(
          mainAxisSize: MainAxisSize.max,
          children: [
            Container(
              width: double.infinity,
              height: 70.0,
              decoration: BoxDecoration(
                color: FlutterFlowTheme.of(context).secondaryBackground,
              ),
              child: Padding(
                padding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 15.0, 0.0),
                child: Row(
                  mainAxisSize: MainAxisSize.max,
                  children: [
                    Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(6.0, 6.0, 6.0, 6.0),
                      child: FlutterFlowIconButton(
                        borderColor: Colors.transparent,
                        borderRadius: 50.0,
                        buttonSize: 42.0,
                        fillColor: FlutterFlowTheme.of(context).accent4,
                        icon: Icon(
                          FFIcons.karrowLeft,
                          color: FlutterFlowTheme.of(context).primaryText,
                          size: 24.0,
                        ),
                        onPressed: () async {
                          context.safePop();
                        },
                      ),
                    ),
                    Expanded(
                      child: Padding(
                        padding:
                            EdgeInsetsDirectional.fromSTEB(5.0, 0.0, 0.0, 0.0),
                        child: Container(
                          width: double.infinity,
                          child: TextFormField(
                            controller: _model.textController,
                            focusNode: _model.textFieldFocusNode,
                            onChanged: (v) => safeSetState(() => _query = v),
                            autofocus: true,
                            obscureText: false,
                            decoration: InputDecoration(
                              isDense: true,
                              hintText: 'بحث',
                              hintStyle: FlutterFlowTheme.of(context)
                                  .titleSmall
                                  .override(
                                    font: GoogleFonts.cairo(
                                      fontWeight: FlutterFlowTheme.of(context)
                                          .titleSmall
                                          .fontWeight,
                                      fontStyle: FlutterFlowTheme.of(context)
                                          .titleSmall
                                          .fontStyle,
                                    ),
                                    color: FlutterFlowTheme.of(context)
                                        .secondaryText,
                                    letterSpacing: 0.0,
                                    fontWeight: FlutterFlowTheme.of(context)
                                        .titleSmall
                                        .fontWeight,
                                    fontStyle: FlutterFlowTheme.of(context)
                                        .titleSmall
                                        .fontStyle,
                                  ),
                              enabledBorder: OutlineInputBorder(
                                borderSide: BorderSide(
                                  color: Color(0x00000000),
                                  width: 1.0,
                                ),
                                borderRadius: BorderRadius.circular(12.0),
                              ),
                              focusedBorder: OutlineInputBorder(
                                borderSide: BorderSide(
                                  color: Color(0x00000000),
                                  width: 1.0,
                                ),
                                borderRadius: BorderRadius.circular(12.0),
                              ),
                              errorBorder: OutlineInputBorder(
                                borderSide: BorderSide(
                                  color: FlutterFlowTheme.of(context).error,
                                  width: 1.0,
                                ),
                                borderRadius: BorderRadius.circular(12.0),
                              ),
                              focusedErrorBorder: OutlineInputBorder(
                                borderSide: BorderSide(
                                  color: FlutterFlowTheme.of(context).error,
                                  width: 1.0,
                                ),
                                borderRadius: BorderRadius.circular(12.0),
                              ),
                              filled: true,
                              fillColor: FlutterFlowTheme.of(context).accent1,
                              contentPadding: EdgeInsetsDirectional.fromSTEB(
                                  15.0, 15.0, 15.0, 15.0),
                            ),
                            style: FlutterFlowTheme.of(context)
                                .titleSmall
                                .override(
                                  font: GoogleFonts.cairo(
                                    fontWeight: FlutterFlowTheme.of(context)
                                        .titleSmall
                                        .fontWeight,
                                    fontStyle: FlutterFlowTheme.of(context)
                                        .titleSmall
                                        .fontStyle,
                                  ),
                                  letterSpacing: 0.0,
                                  fontWeight: FlutterFlowTheme.of(context)
                                      .titleSmall
                                      .fontWeight,
                                  fontStyle: FlutterFlowTheme.of(context)
                                      .titleSmall
                                      .fontStyle,
                                ),
                            cursorColor:
                                FlutterFlowTheme.of(context).primaryText,
                            validator: _model.textControllerValidator
                                .asValidator(context),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Expanded(
              child: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(15.0, 15.0, 0.0, 15.0),
                      child: Text(
                        'محادثاتك',
                        style: FlutterFlowTheme.of(context).titleSmall.override(
                              font: GoogleFonts.cairo(
                                fontWeight: FlutterFlowTheme.of(context)
                                    .titleSmall
                                    .fontWeight,
                                fontStyle: FlutterFlowTheme.of(context)
                                    .titleSmall
                                    .fontStyle,
                              ),
                              color: FlutterFlowTheme.of(context).secondaryText,
                              letterSpacing: 0.0,
                              fontWeight: FlutterFlowTheme.of(context)
                                  .titleSmall
                                  .fontWeight,
                              fontStyle: FlutterFlowTheme.of(context)
                                  .titleSmall
                                  .fontStyle,
                            ),
                      ),
                    ),
                    FutureBuilder<List<_ChatHit>>(
                      future: _chats,
                      builder: (context, snap) {
                        final theme = FlutterFlowTheme.of(context);
                        if (snap.hasError) {
                          return Padding(
                            padding: EdgeInsets.all(24.0),
                            child: Text('تعذّر تحميل المحادثات',
                                textAlign: TextAlign.center,
                                style: theme.bodyMedium.override(
                                    font: GoogleFonts.cairo(),
                                    color: theme.error)),
                          );
                        }
                        if (!snap.hasData) {
                          return Padding(
                            padding: EdgeInsets.all(24.0),
                            child: Center(
                                child: SizedBox(
                                    width: 24,
                                    height: 24,
                                    child: CircularProgressIndicator(
                                        strokeWidth: 2))),
                          );
                        }
                        final q = _norm(_query);
                        final hits = q.isEmpty
                            ? snap.data!
                            : snap.data!
                                .where((h) =>
                                    _norm(h.name).contains(q) ||
                                    h.phone.contains(q) ||
                                    _norm(h.chat.lastMessage).contains(q))
                                .toList();
                        if (hits.isEmpty) {
                          return Padding(
                            padding: EdgeInsets.all(24.0),
                            child: Text(
                                q.isEmpty
                                    ? 'لا توجد محادثات بعد'
                                    : 'لا توجد نتائج لـ «$_query»',
                                textAlign: TextAlign.center,
                                style: theme.bodyMedium.override(
                                    font: GoogleFonts.cairo(),
                                    color: theme.secondaryText)),
                          );
                        }
                        return ListView.separated(
                          padding: EdgeInsets.zero,
                          primary: false,
                          shrinkWrap: true,
                          itemCount: hits.length,
                          separatorBuilder: (_, __) => SizedBox(height: 12.0),
                          itemBuilder: (context, i) {
                            final h = hits[i];
                            return Padding(
                              padding: EdgeInsetsDirectional.fromSTEB(
                                  15.0, 0.0, 15.0, 0.0),
                              child: CardMessageWidget(
                                key: Key('search_${h.chat.reference.id}'),
                                data: UsersStruct(
                                  name: h.name,
                                  image: h.photo,
                                  message: h.chat.lastMessage,
                                ),
                                index: i,
                                chatRef: h.chat.reference,
                              ),
                            );
                          },
                        );
                      },
                    ),
                  ].addToEnd(SizedBox(height: 15.0)),
                ),
              ),
            ),
          ],
        ),
        ),
      ),
    );
  }
}

class _ChatHit {
  final ChatsRecord chat;
  final String name;
  final String photo;
  final String phone;
  const _ChatHit(
      {required this.chat,
      required this.name,
      required this.photo,
      required this.phone});
}
