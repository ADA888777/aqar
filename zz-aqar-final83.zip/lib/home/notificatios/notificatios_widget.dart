import '/flutter_flow/flutter_flow_icon_button.dart';
import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/home/components/notifications_options/notifications_options_widget.dart';
import 'dart:ui';
import '/index.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'notificatios_model.dart';
export 'notificatios_model.dart';

class NotificatiosWidget extends StatefulWidget {
  const NotificatiosWidget({super.key});

  static String routeName = 'الإشعارات';
  static String routePath = '/notificatios';

  @override
  State<NotificatiosWidget> createState() => _NotificatiosWidgetState();
}

class _NotificatiosWidgetState extends State<NotificatiosWidget> {
  late NotificatiosModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => NotificatiosModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        FocusScope.of(context).unfocus();
        FocusManager.instance.primaryFocus?.unfocus();
      },
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
        appBar: AppBar(
          backgroundColor: FlutterFlowTheme.of(context).secondaryBackground,
          automaticallyImplyLeading: false,
          leading: Padding(
            padding: EdgeInsetsDirectional.fromSTEB(6.0, 6.0, 6.0, 6.0),
            child: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 50.0,
              buttonSize: 42.0,
              fillColor: FlutterFlowTheme.of(context).accent4,
              icon: Icon(
                FFIcons.karrowLeft,
                color: FlutterFlowTheme.of(context).primaryText,
                size: 24.0,
              ),
              onPressed: () async {
                context.safePop();
              },
            ),
          ),
          title: Text(
            'الإشعارات',
            style: FlutterFlowTheme.of(context).headlineSmall.override(
                  font: GoogleFonts.cairo(
                    fontWeight:
                        FlutterFlowTheme.of(context).headlineSmall.fontWeight,
                    fontStyle:
                        FlutterFlowTheme.of(context).headlineSmall.fontStyle,
                  ),
                  letterSpacing: 0.0,
                  fontWeight:
                      FlutterFlowTheme.of(context).headlineSmall.fontWeight,
                  fontStyle:
                      FlutterFlowTheme.of(context).headlineSmall.fontStyle,
                ),
          ),
          actions: [
            Padding(
              padding: EdgeInsetsDirectional.fromSTEB(0.0, 6.0, 6.0, 6.0),
              child: FlutterFlowIconButton(
                borderColor: Colors.transparent,
                borderRadius: 50.0,
                buttonSize: 42.0,
                fillColor: FlutterFlowTheme.of(context).accent4,
                icon: Icon(
                  FFIcons.kdots,
                  color: FlutterFlowTheme.of(context).primaryText,
                  size: 24.0,
                ),
                onPressed: () async {
                  await showModalBottomSheet(
                    isScrollControlled: true,
                    backgroundColor: FlutterFlowTheme.of(context).accent4,
                    barrierColor: FlutterFlowTheme.of(context).barier,
                    context: context,
                    builder: (context) {
                      return GestureDetector(
                        onTap: () {
                          FocusScope.of(context).unfocus();
                          FocusManager.instance.primaryFocus?.unfocus();
                        },
                        child: Padding(
                          padding: MediaQuery.viewInsetsOf(context),
                          child: NotificationsOptionsWidget(),
                        ),
                      );
                    },
                  ).then((value) => safeSetState(() {}));
                },
              ),
            ),
          ],
          centerTitle: true,
          elevation: 0.0,
        ),
        body: SafeArea(
          child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // ===== الإشعارات الحقيقية =====
              // مصدرها حدث فعلي واحد: رسالة غير مقروءة موجهة لي.
              // لا تُنشأ سجلات جديدة عند فتح الصفحة، ولا تُحسب إعادة
              // قراءة البيانات حدثاً جديداً، ورسالة واحدة لكل محادثة.
              StreamBuilder<List<MessagesRecord>>(
                stream: currentUserReference == null
                    ? Stream.value(<MessagesRecord>[])
                    : queryMessagesRecord(
                        // participants arrayContains: بدونه ترفض القاعدة
                        // الاستعلام (permission-denied) وتعلق الشاشة.
                        queryBuilder: (q) => q
                            .where('participants',
                                arrayContains: currentUserReference)
                            .where('receiver_ref',
                                isEqualTo: currentUserReference)
                            .where('is_read', isEqualTo: false),
                      ),
                builder: (context, snapshot) {
                  if (snapshot.hasError) {
                    return Padding(
                      padding: EdgeInsetsDirectional.fromSTEB(
                          24.0, 30.0, 24.0, 0.0),
                      child: Text(
                        'تعذّر تحميل الإشعارات\n${snapshot.error.toString().contains('permission-denied') ? 'الصلاحيات ترفض القراءة (permission-denied)' : 'تحقق من اتصالك'}',
                        textAlign: TextAlign.center,
                        style: FlutterFlowTheme.of(context)
                            .bodyMedium
                            .override(
                              font: GoogleFonts.cairo(),
                              color: FlutterFlowTheme.of(context).error,
                              letterSpacing: 0.0,
                            ),
                      ),
                    );
                  }
                  if (!snapshot.hasData) {
                    return Padding(
                      padding: EdgeInsetsDirectional.fromSTEB(
                          0.0, 30.0, 0.0, 0.0),
                      child: Center(
                        child: SizedBox(
                          width: 25.0,
                          height: 25.0,
                          child: CircularProgressIndicator(
                            valueColor: AlwaysStoppedAnimation<Color>(
                              FlutterFlowTheme.of(context).primary,
                            ),
                          ),
                        ),
                      ),
                    );
                  }
                  final msgs = snapshot.data!
                      .where((m) =>
                          !m.deletedFor.contains(currentUserReference))
                      .toList();
                  msgs.sort((a, b) => (b.createdAt ?? DateTime(2000))
                      .compareTo(a.createdAt ?? DateTime(2000)));
                  final seenChats = <String>{};
                  final unique = <MessagesRecord>[];
                  for (final m in msgs) {
                    final key = m.chatRef?.path ?? '';
                    if (key.isEmpty || seenChats.contains(key)) {
                      continue;
                    }
                    seenChats.add(key);
                    unique.add(m);
                  }
                  if (unique.isEmpty) {
                    return Padding(
                      padding: EdgeInsetsDirectional.fromSTEB(
                          24.0, 40.0, 24.0, 0.0),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(
                            Icons.notifications_none_rounded,
                            size: 44.0,
                            color: FlutterFlowTheme.of(context).secondaryText,
                          ),
                          SizedBox(height: 10.0),
                          Text(
                            'لا توجد إشعارات جديدة',
                            style: FlutterFlowTheme.of(context)
                                .bodyMedium
                                .override(
                                  font: GoogleFonts.cairo(),
                                  color: FlutterFlowTheme.of(context)
                                      .secondaryText,
                                  letterSpacing: 0.0,
                                ),
                          ),
                        ],
                      ),
                    );
                  }
                  return Padding(
                    padding: EdgeInsetsDirectional.fromSTEB(
                        15.0, 12.0, 15.0, 0.0),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: unique
                          .map((m) => Padding(
                                padding: EdgeInsetsDirectional.fromSTEB(
                                    0.0, 0.0, 0.0, 10.0),
                                // سحب لليسار = حذف هذا الإشعار (ناعم، عندي فقط)
                                child: Dismissible(
                                  key: ValueKey(m.reference.path),
                                  direction: DismissDirection.endToStart,
                                  background: Container(
                                    alignment: AlignmentDirectional(1.0, 0.0),
                                    padding: EdgeInsetsDirectional.fromSTEB(
                                        0.0, 0.0, 20.0, 0.0),
                                    decoration: BoxDecoration(
                                      color: FlutterFlowTheme.of(context).error,
                                      borderRadius: BorderRadius.circular(12.0),
                                    ),
                                    child: Icon(Icons.delete_outline_rounded,
                                        color: Colors.white),
                                  ),
                                  onDismissed: (_) async {
                                    try {
                                      await deleteNotificationForMe(m.reference);
                                    } catch (e) {
                                      debugPrint('deleteNotificationForMe: $e');
                                      if (context.mounted) {
                                        ScaffoldMessenger.of(context)
                                            .showSnackBar(SnackBar(
                                          content: Text('تعذّر الحذف'),
                                          backgroundColor:
                                              FlutterFlowTheme.of(context).error,
                                        ));
                                      }
                                    }
                                  },
                                  child: InkWell(
                                  splashColor: Colors.transparent,
                                  focusColor: Colors.transparent,
                                  hoverColor: Colors.transparent,
                                  highlightColor: Colors.transparent,
                                  onTap: () async {
                                    if (m.chatRef == null) {
                                      return;
                                    }
                                    context.pushNamed(
                                      SingleMessageWidget.routeName,
                                      queryParameters: {
                                        'chatRef': serializeParam(
                                          m.chatRef,
                                          ParamType.DocumentReference,
                                        ),
                                      }.withoutNulls,
                                    );
                                  },
                                  child: Container(
                                    decoration: BoxDecoration(
                                      color: FlutterFlowTheme.of(context)
                                          .secondaryBackground,
                                      borderRadius:
                                          BorderRadius.circular(12.0),
                                      border: Border.all(
                                        color: FlutterFlowTheme.of(context)
                                            .alternate,
                                      ),
                                    ),
                                    padding: EdgeInsets.all(14.0),
                                    child: Row(
                                      children: [
                                        Container(
                                          padding: EdgeInsets.all(9.0),
                                          decoration: BoxDecoration(
                                            color: FlutterFlowTheme.of(context)
                                                .accent1,
                                            shape: BoxShape.circle,
                                          ),
                                          child: Icon(
                                            Icons.chat_bubble_outline_rounded,
                                            size: 18.0,
                                            color: FlutterFlowTheme.of(context)
                                                .secondary,
                                          ),
                                        ),
                                        SizedBox(width: 12.0),
                                        Expanded(
                                          child: Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            mainAxisSize: MainAxisSize.min,
                                            children: [
                                              Text(
                                                'رسالة جديدة',
                                                style: FlutterFlowTheme.of(
                                                        context)
                                                    .titleSmall
                                                    .override(
                                                      font: GoogleFonts.cairo(
                                                          fontWeight:
                                                              FontWeight.w600),
                                                      letterSpacing: 0.0,
                                                    ),
                                              ),
                                              SizedBox(height: 3.0),
                                              Text(
                                                m.text,
                                                maxLines: 1,
                                                overflow:
                                                    TextOverflow.ellipsis,
                                                style: FlutterFlowTheme.of(
                                                        context)
                                                    .bodySmall
                                                    .override(
                                                      font:
                                                          GoogleFonts.cairo(),
                                                      color: FlutterFlowTheme
                                                              .of(context)
                                                          .secondaryText,
                                                      letterSpacing: 0.0,
                                                    ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                                ),
                              ))
                          .toList(),
                    ),
                  );
                },
              ),
            ].addToEnd(SizedBox(height: 25.0)),
          ),
        ),
        ),
      ),
    );
  }
}
