import '/auth/firebase_auth/auth_util.dart';
import '/backend/admin_backend.dart';
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/index.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

/// ══════════════════════════════════════════════════════════════
/// لوحة الإدارة — للأدمن فقط.
/// الواجهة تُخفيها عن غير الأدمن، لكن الحماية الحقيقية في القواعد:
/// كل كتابة هنا تُرفض من الخادم ما لم يكن المستدعي isAdmin().
/// ══════════════════════════════════════════════════════════════
class AdminDashboardWidget extends StatefulWidget {
  const AdminDashboardWidget({super.key});

  static String routeName = 'AdminDashboard';
  static String routePath = '/adminDashboard';

  @override
  State<AdminDashboardWidget> createState() => _AdminDashboardWidgetState();
}

class _AdminDashboardWidgetState extends State<AdminDashboardWidget>
    with SingleTickerProviderStateMixin {
  late final TabController _tabs;
  bool _checking = true;
  bool _allowed = false;

  static const _tabTitles = [
    'نظرة عامة', 'الإعلانات', 'البلاغات', 'المستخدمون', 'الطلبات', 'الوسطاء'
  ];

  @override
  void initState() {
    super.initState();
    _tabs = TabController(length: _tabTitles.length, vsync: this);
    _gate();
  }

  /// حارس: يُجدّد الـ claims ويتحقق. غير الأدمن يُعاد للخلف فوراً.
  Future<void> _gate() async {
    await refreshUserClaims();
    if (!mounted) return;
    if (!currentUserIsAdmin) {
      safeSetState(() { _checking = false; _allowed = false; });
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('هذه الصفحة للإدارة فقط'),
        backgroundColor: FlutterFlowTheme.of(context).error,
      ));
      context.safePop();
      return;
    }
    safeSetState(() { _checking = false; _allowed = true; });
  }

  @override
  void dispose() {
    _tabs.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = FlutterFlowTheme.of(context);
    if (_checking || !_allowed) {
      return Scaffold(
        backgroundColor: theme.primaryBackground,
        body: Center(child: CircularProgressIndicator()),
      );
    }
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: theme.primaryBackground,
        appBar: AppBar(
          backgroundColor: theme.primary,
          automaticallyImplyLeading: false,
          leading: FlutterFlowIconButton(
            borderRadius: 50.0,
            buttonSize: 42.0,
            icon: Icon(Icons.arrow_forward_rounded, color: Colors.white),
            onPressed: () => context.safePop(),
          ),
          title: Text('لوحة الإدارة',
              style: theme.headlineSmall.override(
                  font: GoogleFonts.cairo(fontWeight: FontWeight.w700),
                  color: Colors.white,
                  letterSpacing: 0.0)),
          centerTitle: true,
          elevation: 0.0,
          bottom: TabBar(
            controller: _tabs,
            isScrollable: true,
            indicatorColor: Colors.white,
            labelColor: Colors.white,
            unselectedLabelColor: Colors.white70,
            labelStyle: GoogleFonts.cairo(fontWeight: FontWeight.w600),
            tabs: _tabTitles.map((t) => Tab(text: t)).toList(),
          ),
        ),
        body: TabBarView(
          controller: _tabs,
          children: [
            _OverviewTab(onGoTo: (i) => _tabs.animateTo(i)),
            _ListingsTab(),
            _ReportsTab(onOpenListing: _openListing),
            _UsersTab(),
            _RequestsTab(),
            _RealtorsTab(),
          ],
        ),
      ),
    );
  }

  Future<void> _openListing(DocumentReference ref) async {
    try {
      final p = await PropertyDataRecord.getDocumentOnce(ref);
      if (!mounted) return;
      context.pushNamed(SingleApartmentWidget.routeName,
          queryParameters: {
            'data': serializeParam(p, ParamType.Document),
          }.withoutNulls,
          extra: <String, dynamic>{'data': p});
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('الإعلان لم يعد موجوداً')));
      }
    }
  }
}

/* ═══════════════════════════════════════════════════════════════
   أدوات مشتركة
   ═══════════════════════════════════════════════════════════════ */

String _errText(Object e) {
  final t = e.toString();
  if (t.contains('permission-denied')) return 'الصلاحيات ترفض (permission-denied)';
  if (t.contains('index') || t.contains('FAILED_PRECONDITION')) {
    return 'الفهرس قيد الإنشاء — حاول بعد دقائق';
  }
  return 'خطأ — تحقق من الاتصال';
}

void _toast(BuildContext c, String msg, {bool error = false}) {
  ScaffoldMessenger.of(c).showSnackBar(SnackBar(
    content: Text(msg),
    backgroundColor: error ? FlutterFlowTheme.of(c).error : null,
  ));
}

/// حوار سبب (تعطيل/حظر) — يعيد النص أو null عند الإلغاء
Future<String?> _askReason(BuildContext c, String title) async {
  final ctrl = TextEditingController();
  return showDialog<String>(
    context: c,
    builder: (ctx) => Directionality(
      textDirection: TextDirection.rtl,
      child: AlertDialog(
        title: Text(title, style: GoogleFonts.cairo(fontWeight: FontWeight.w700)),
        content: TextField(
          controller: ctrl,
          maxLines: 3,
          autofocus: true,
          decoration: InputDecoration(hintText: 'السبب — يظهر للمستخدم'),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: Text('إلغاء', style: GoogleFonts.cairo())),
          ElevatedButton(
              onPressed: () {
                if (ctrl.text.trim().length < 3) return;
                Navigator.pop(ctx, ctrl.text.trim());
              },
              child: Text('تأكيد', style: GoogleFonts.cairo())),
        ],
      ),
    ),
  );
}

Future<bool> _confirm(BuildContext c, String title, String body) async {
  return await showDialog<bool>(
        context: c,
        builder: (ctx) => Directionality(
          textDirection: TextDirection.rtl,
          child: AlertDialog(
            title: Text(title, style: GoogleFonts.cairo(fontWeight: FontWeight.w700)),
            content: Text(body, style: GoogleFonts.cairo()),
            actions: [
              TextButton(
                  onPressed: () => Navigator.pop(ctx, false),
                  child: Text('إلغاء', style: GoogleFonts.cairo())),
              ElevatedButton(
                  style: ElevatedButton.styleFrom(
                      backgroundColor: FlutterFlowTheme.of(c).error),
                  onPressed: () => Navigator.pop(ctx, true),
                  child: Text('تأكيد', style: GoogleFonts.cairo(color: Colors.white))),
            ],
          ),
        ),
      ) ??
      false;
}

Widget _stateBuilder(BuildContext c, AsyncSnapshot snap, Widget Function() ok) {
  final theme = FlutterFlowTheme.of(c);
  if (snap.hasError) {
    return Center(
        child: Padding(
      padding: EdgeInsets.all(24),
      child: Text(_errText(snap.error!),
          textAlign: TextAlign.center,
          style: GoogleFonts.cairo(color: theme.error)),
    ));
  }
  if (!snap.hasData) return Center(child: CircularProgressIndicator());
  return ok();
}

Widget _empty(BuildContext c, String text) => Center(
    child: Padding(
        padding: EdgeInsets.all(24),
        child: Text(text,
            style: GoogleFonts.cairo(
                color: FlutterFlowTheme.of(c).secondaryText))));

/// اسم مستخدم من مرجعه — يُحمَّل مرة ويُخزَّن
class _UserName extends StatelessWidget {
  final DocumentReference? ref;
  final bool withUid;
  const _UserName(this.ref, {this.withUid = false});
  @override
  Widget build(BuildContext context) {
    if (ref == null) return Text('—', style: GoogleFonts.cairo());
    return FutureBuilder<UsersRecord>(
      future: UsersRecord.getDocumentOnce(ref!),
      builder: (c, s) {
        final theme = FlutterFlowTheme.of(c);
        final u = s.data;
        final name = u?.displayName.isNotEmpty == true ? u!.displayName : (u?.email ?? '…');
        return Text(withUid ? '$name · ${ref!.id}' : name,
            style: GoogleFonts.cairo(fontSize: 12, color: theme.secondaryText),
            overflow: TextOverflow.ellipsis);
      },
    );
  }
}

/* ═══════════════════════════════════════════════════════════════
   1 · نظرة عامة
   ═══════════════════════════════════════════════════════════════ */
class _OverviewTab extends StatefulWidget {
  final void Function(int) onGoTo;
  const _OverviewTab({required this.onGoTo});
  @override
  State<_OverviewTab> createState() => _OverviewTabState();
}

class _OverviewTabState extends State<_OverviewTab> {
  late Future<AdminCounts> _f = adminCounts();

  @override
  Widget build(BuildContext context) {
    final theme = FlutterFlowTheme.of(context);
    return RefreshIndicator(
      onRefresh: () async => setState(() => _f = adminCounts()),
      child: FutureBuilder<AdminCounts>(
        future: _f,
        builder: (c, s) => _stateBuilder(c, s, () {
          final d = s.data!;
          final cards = <(String, int, IconData, int?)>[
            ('المستخدمون', d.users, Icons.people_outline, 3),
            ('محظورون', d.banned, Icons.block, 3),
            ('كل الإعلانات', d.listings, Icons.home_work_outlined, 1),
            ('نشطة', d.live, Icons.check_circle_outline, 1),
            ('منتهية', d.expired, Icons.timer_off_outlined, 1),
            ('معطّلة إدارياً', d.disabled, Icons.visibility_off_outlined, 1),
            ('بلاغات جديدة', d.newReports, Icons.flag_outlined, 2),
            ('طلبات العقارات', d.requests, Icons.assignment_outlined, 4),
            ('الوسطاء', d.realtors, Icons.business_outlined, 5),
            ('طلبات التواصل', d.contactRequests, Icons.contact_mail_outlined, 5),
          ];
          return GridView.builder(
            padding: EdgeInsets.all(15),
            gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2, mainAxisSpacing: 10, crossAxisSpacing: 10,
                childAspectRatio: 1.6),
            itemCount: cards.length,
            itemBuilder: (_, i) {
              final (title, n, icon, tab) = cards[i];
              final bad = title == 'بلاغات جديدة' && n > 0;
              return InkWell(
                onTap: tab == null ? null : () => widget.onGoTo(tab),
                borderRadius: BorderRadius.circular(14),
                child: Container(
                  padding: EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: bad ? theme.error.withOpacity(0.1) : theme.secondaryBackground,
                    borderRadius: BorderRadius.circular(14),
                    border: bad ? Border.all(color: theme.error) : null,
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Icon(icon, color: bad ? theme.error : theme.primary, size: 22),
                      Text(n < 0 ? '—' : '$n',
                          style: GoogleFonts.cairo(fontSize: 26, fontWeight: FontWeight.w800)),
                      Text(title, style: GoogleFonts.cairo(fontSize: 12, color: theme.secondaryText)),
                    ],
                  ),
                ),
              );
            },
          );
        }),
      ),
    );
  }
}

/* ═══════════════════════════════════════════════════════════════
   2 · الإعلانات
   ═══════════════════════════════════════════════════════════════ */
class _ListingsTab extends StatefulWidget {
  @override
  State<_ListingsTab> createState() => _ListingsTabState();
}

class _ListingsTabState extends State<_ListingsTab> {
  String _state = 'all';
  String? _category;
  String? _area;
  String _search = '';

  @override
  Widget build(BuildContext context) {
    final theme = FlutterFlowTheme.of(context);
    return Column(children: [
      Padding(
        padding: EdgeInsets.fromLTRB(12, 10, 12, 4),
        child: Column(children: [
          TextField(
            decoration: InputDecoration(
                hintText: 'بحث بالعنوان أو معرّف الإعلان', prefixIcon: Icon(Icons.search),
                isDense: true, border: OutlineInputBorder(borderRadius: BorderRadius.circular(10))),
            onChanged: (v) => setState(() => _search = v.trim()),
          ),
          SizedBox(height: 8),
          Row(children: [
            Expanded(child: DropdownButtonFormField<String>(
              value: _state, isExpanded: true,
              decoration: InputDecoration(isDense: true, border: OutlineInputBorder(borderRadius: BorderRadius.circular(10))),
              items: const [
                DropdownMenuItem(value: 'all', child: Text('الكل')),
                DropdownMenuItem(value: 'live', child: Text('نشطة')),
                DropdownMenuItem(value: 'expired', child: Text('منتهية')),
                DropdownMenuItem(value: 'disabled', child: Text('معطّلة')),
              ],
              onChanged: (v) => setState(() => _state = v ?? 'all'),
            )),
            SizedBox(width: 8),
            Expanded(child: DropdownButtonFormField<String>(
              value: _category, isExpanded: true,
              decoration: InputDecoration(hintText: 'التصنيف', isDense: true, border: OutlineInputBorder(borderRadius: BorderRadius.circular(10))),
              items: [DropdownMenuItem<String>(value: null, child: Text('كل التصنيفات')),
                ...FFAppConstants.FieldsByCategory.keys.map((c) => DropdownMenuItem(value: c, child: Text(c, overflow: TextOverflow.ellipsis)))],
              onChanged: (v) => setState(() => _category = v),
            )),
          ]),
          SizedBox(height: 8),
          DropdownButtonFormField<String>(
            value: _area, isExpanded: true,
            decoration: InputDecoration(hintText: 'المنطقة', isDense: true, border: OutlineInputBorder(borderRadius: BorderRadius.circular(10))),
            items: [DropdownMenuItem<String>(value: null, child: Text('كل المناطق')),
              ...FFAppConstants.KuwaitAreas.map((a) => DropdownMenuItem(value: a, child: Text(a)))],
            onChanged: (v) => setState(() => _area = v),
          ),
        ]),
      ),
      Expanded(child: StreamBuilder<QuerySnapshot>(
        stream: adminListingsQuery(category: _category, area: _area, state: _state).snapshots(),
        builder: (c, s) => _stateBuilder(c, s, () {
          var items = s.data!.docs.map((d) => PropertyDataRecord.fromSnapshot(d)).toList();
          if (_search.isNotEmpty) {
            final q = _search.toLowerCase();
            items = items.where((p) => p.title.toLowerCase().contains(q) || p.reference.id.contains(_search)).toList();
          }
          if (items.isEmpty) return _empty(c, 'لا توجد إعلانات');
          return ListView.separated(
            padding: EdgeInsets.all(12),
            itemCount: items.length,
            separatorBuilder: (_, __) => SizedBox(height: 8),
            itemBuilder: (_, i) => _ListingRow(items[i]),
          );
        }),
      )),
    ]);
  }
}

class _ListingRow extends StatelessWidget {
  final PropertyDataRecord p;
  const _ListingRow(this.p);

  @override
  Widget build(BuildContext context) {
    final theme = FlutterFlowTheme.of(context);
    final disabled = p.disabledByAdmin;
    final expired = p.isExpired;
    final chip = disabled ? ('معطّل إدارياً', theme.error)
        : !p.isApproved ? ('غير معتمد', theme.secondaryText)
        : expired ? ('منتهٍ', Colors.orange)
        : p.isArchived ? ('مؤرشف', theme.secondaryText)
        : ('نشط', Colors.green);
    return Container(
      padding: EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: theme.secondaryBackground,
        borderRadius: BorderRadius.circular(12),
        border: disabled ? Border.all(color: theme.error.withOpacity(0.5)) : null,
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Expanded(child: Text(p.title.isEmpty ? '(بلا عنوان)' : p.title,
              maxLines: 1, overflow: TextOverflow.ellipsis,
              style: GoogleFonts.cairo(fontWeight: FontWeight.w700))),
          Container(
            padding: EdgeInsets.symmetric(horizontal: 8, vertical: 2),
            decoration: BoxDecoration(color: chip.$2.withOpacity(0.15), borderRadius: BorderRadius.circular(20)),
            child: Text(chip.$1, style: GoogleFonts.cairo(fontSize: 11, color: chip.$2, fontWeight: FontWeight.w600)),
          ),
        ]),
        SizedBox(height: 4),
        Text('${p.category} · ${p.area} · ${p.price} د.ك · ${p.reference.id}',
            style: GoogleFonts.cairo(fontSize: 11, color: theme.secondaryText)),
        Row(children: [
          Text('المالك: ', style: GoogleFonts.cairo(fontSize: 12, color: theme.secondaryText)),
          Expanded(child: _UserName(p.ownerRef, withUid: true)),
        ]),
        if (disabled && p.disabledReason.isNotEmpty)
          Padding(
            padding: EdgeInsets.only(top: 4),
            child: Text('سبب التعطيل: ${p.disabledReason}',
                style: GoogleFonts.cairo(fontSize: 12, color: theme.error)),
          ),
        SizedBox(height: 8),
        Wrap(spacing: 6, runSpacing: 4, children: [
          _btn(context, Icons.open_in_new, 'فتح', () {
            context.pushNamed(SingleApartmentWidget.routeName,
                queryParameters: {'data': serializeParam(p, ParamType.Document)}.withoutNulls,
                extra: <String, dynamic>{'data': p});
          }),
          if (!disabled)
            _btn(context, Icons.visibility_off_outlined, 'تعطيل', () async {
              final r = await _askReason(context, 'سبب تعطيل الإعلان');
              if (r == null) return;
              try { await adminDisableListing(p.reference, r); if (context.mounted) _toast(context, 'تم التعطيل — وصل إشعار للمالك'); }
              catch (e) { if (context.mounted) _toast(context, _errText(e), error: true); }
            }, color: Colors.orange),
          if (disabled)
            _btn(context, Icons.visibility_outlined, 'إعادة تفعيل', () async {
              try { await adminEnableListing(p.reference); if (context.mounted) _toast(context, 'أُعيد تفعيل الإعلان'); }
              catch (e) { if (context.mounted) _toast(context, _errText(e), error: true); }
            }, color: Colors.green),
          _btn(context, Icons.delete_forever_outlined, 'حذف نهائي', () async {
            if (!await _confirm(context, 'حذف نهائي', 'سيُحذف الإعلان وصوره ولا يمكن التراجع.')) return;
            try { await adminDeleteListing(p); if (context.mounted) _toast(context, 'حُذف الإعلان'); }
            catch (e) { if (context.mounted) _toast(context, _errText(e), error: true); }
          }, color: theme.error),
        ]),
      ]),
    );
  }
}

Widget _btn(BuildContext c, IconData icon, String label, VoidCallback onTap, {Color? color}) {
  final theme = FlutterFlowTheme.of(c);
  return OutlinedButton.icon(
    onPressed: onTap,
    icon: Icon(icon, size: 16),
    label: Text(label, style: GoogleFonts.cairo(fontSize: 12)),
    style: OutlinedButton.styleFrom(
      foregroundColor: color ?? theme.primary,
      side: BorderSide(color: (color ?? theme.primary).withOpacity(0.5)),
      padding: EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      visualDensity: VisualDensity.compact,
    ),
  );
}

/* ═══════════════════════════════════════════════════════════════
   3 · البلاغات
   ═══════════════════════════════════════════════════════════════ */
class _ReportsTab extends StatefulWidget {
  final Future<void> Function(DocumentReference) onOpenListing;
  const _ReportsTab({required this.onOpenListing});
  @override
  State<_ReportsTab> createState() => _ReportsTabState();
}

class _ReportsTabState extends State<_ReportsTab> {
  String _status = 'new';
  static const _labels = {'new': 'جديد', 'reviewed': 'تمت المراجعة', 'resolved': 'تم التعامل'};

  @override
  Widget build(BuildContext context) {
    final theme = FlutterFlowTheme.of(context);
    return Column(children: [
      Padding(
        padding: EdgeInsets.fromLTRB(12, 10, 12, 4),
        child: SegmentedButton<String>(
          segments: [
            ButtonSegment(value: 'new', label: Text('جديد', style: GoogleFonts.cairo())),
            ButtonSegment(value: 'reviewed', label: Text('قيد المراجعة', style: GoogleFonts.cairo())),
            ButtonSegment(value: 'resolved', label: Text('منتهٍ', style: GoogleFonts.cairo())),
            ButtonSegment(value: '', label: Text('الكل', style: GoogleFonts.cairo())),
          ],
          selected: {_status},
          onSelectionChanged: (s) => setState(() => _status = s.first),
        ),
      ),
      Expanded(child: StreamBuilder<QuerySnapshot>(
        stream: reportsQuery(status: _status.isEmpty ? null : _status).snapshots(),
        builder: (c, s) => _stateBuilder(c, s, () {
          final items = s.data!.docs.map((d) => ReportsRecord.fromSnapshot(d)).toList();
          if (items.isEmpty) return _empty(c, 'لا توجد بلاغات');
          return ListView.separated(
            padding: EdgeInsets.all(12),
            itemCount: items.length,
            separatorBuilder: (_, __) => SizedBox(height: 8),
            itemBuilder: (_, i) {
              final r = items[i];
              final st = _labels[r.status] ?? r.status;
              final stColor = r.status == 'new' ? theme.error : r.status == 'reviewed' ? Colors.orange : Colors.green;
              return Container(
                padding: EdgeInsets.all(12),
                decoration: BoxDecoration(color: theme.secondaryBackground, borderRadius: BorderRadius.circular(12)),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Row(children: [
                    Expanded(child: Text(r.reason, style: GoogleFonts.cairo(fontWeight: FontWeight.w700))),
                    Container(
                      padding: EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                      decoration: BoxDecoration(color: stColor.withOpacity(0.15), borderRadius: BorderRadius.circular(20)),
                      child: Text(st, style: GoogleFonts.cairo(fontSize: 11, color: stColor, fontWeight: FontWeight.w600)),
                    ),
                  ]),
                  if (r.details.isNotEmpty) Padding(padding: EdgeInsets.only(top: 4), child: Text(r.details, style: GoogleFonts.cairo(fontSize: 13))),
                  SizedBox(height: 6),
                  Text('الإعلان: ${r.propertyTitle}', style: GoogleFonts.cairo(fontSize: 12, color: theme.secondaryText), maxLines: 1, overflow: TextOverflow.ellipsis),
                  Row(children: [Text('المُبلِّغ: ', style: GoogleFonts.cairo(fontSize: 12, color: theme.secondaryText)), Expanded(child: _UserName(r.reporterRef, withUid: true))]),
                  Row(children: [Text('صاحب الإعلان: ', style: GoogleFonts.cairo(fontSize: 12, color: theme.secondaryText)), Expanded(child: _UserName(r.ownerRef, withUid: true))]),
                  if (r.createdAt != null) Text(dateTimeFormat('relative', r.createdAt!, locale: 'ar'), style: GoogleFonts.cairo(fontSize: 11, color: theme.secondaryText)),
                  if (r.adminNote.isNotEmpty) Text('ملاحظة الإدارة: ${r.adminNote}', style: GoogleFonts.cairo(fontSize: 12, fontStyle: FontStyle.italic)),
                  SizedBox(height: 8),
                  Wrap(spacing: 6, runSpacing: 4, children: [
                    if (r.propertyRef != null) _btn(context, Icons.open_in_new, 'فتح الإعلان', () => widget.onOpenListing(r.propertyRef!)),
                    if (r.status == 'new') _btn(context, Icons.rate_review_outlined, 'قيد المراجعة', () => _set(r, 'reviewed'), color: Colors.orange),
                    if (r.status != 'resolved') _btn(context, Icons.task_alt, 'تم التعامل', () async {
                      final note = await _askReason(context, 'ما الإجراء المتخذ؟');
                      if (note != null) _set(r, 'resolved', note: note);
                    }, color: Colors.green),
                    if (r.propertyRef != null && r.status != 'resolved') _btn(context, Icons.visibility_off_outlined, 'تعطيل الإعلان', () async {
                      final reason = await _askReason(context, 'سبب التعطيل');
                      if (reason == null) return;
                      try {
                        await adminDisableListing(r.propertyRef!, reason);
                        await adminSetReportStatus(r.reference, 'resolved', note: 'عُطّل الإعلان: $reason');
                        if (context.mounted) _toast(context, 'عُطّل الإعلان وأُغلق البلاغ');
                      } catch (e) { if (context.mounted) _toast(context, _errText(e), error: true); }
                    }, color: theme.error),
                  ]),
                ]),
              );
            },
          );
        }),
      )),
    ]);
  }

  Future<void> _set(ReportsRecord r, String status, {String? note}) async {
    try {
      await adminSetReportStatus(r.reference, status, note: note);
      if (mounted) _toast(context, 'تم التحديث');
    } catch (e) {
      if (mounted) _toast(context, _errText(e), error: true);
    }
  }
}

/* ═══════════════════════════════════════════════════════════════
   4 · المستخدمون
   ═══════════════════════════════════════════════════════════════ */
class _UsersTab extends StatefulWidget {
  @override
  State<_UsersTab> createState() => _UsersTabState();
}

class _UsersTabState extends State<_UsersTab> {
  String _q = '';
  bool? _banned;

  @override
  Widget build(BuildContext context) {
    final theme = FlutterFlowTheme.of(context);
    return Column(children: [
      Padding(
        padding: EdgeInsets.fromLTRB(12, 10, 12, 4),
        child: Row(children: [
          Expanded(child: TextField(
            decoration: InputDecoration(hintText: 'بداية الاسم أو البريد', prefixIcon: Icon(Icons.search), isDense: true,
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(10))),
            onChanged: (v) => setState(() => _q = v),
          )),
          SizedBox(width: 8),
          DropdownButton<bool?>(
            value: _banned,
            items: const [DropdownMenuItem(value: null, child: Text('الكل')), DropdownMenuItem(value: true, child: Text('محظورون')), DropdownMenuItem(value: false, child: Text('نشطون'))],
            onChanged: (v) => setState(() => _banned = v),
          ),
        ]),
      ),
      Expanded(child: StreamBuilder<QuerySnapshot>(
        stream: adminUsersQuery(prefix: _q, banned: _banned).snapshots(),
        builder: (c, s) => _stateBuilder(c, s, () {
          final users = s.data!.docs.map((d) => UsersRecord.fromSnapshot(d)).toList();
          if (users.isEmpty) return _empty(c, 'لا نتائج');
          return ListView.separated(
            padding: EdgeInsets.all(12),
            itemCount: users.length,
            separatorBuilder: (_, __) => SizedBox(height: 8),
            itemBuilder: (_, i) => _UserRow(users[i]),
          );
        }),
      )),
    ]);
  }
}

class _UserRow extends StatelessWidget {
  final UsersRecord u;
  const _UserRow(this.u);

  @override
  Widget build(BuildContext context) {
    final theme = FlutterFlowTheme.of(context);
    final isAdmin = u.role.trim().toLowerCase() == 'admin';
    final me = u.reference == currentUserReference;
    return Container(
      padding: EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: theme.secondaryBackground, borderRadius: BorderRadius.circular(12),
        border: u.isBanned ? Border.all(color: theme.error.withOpacity(0.5)) : null,
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          CircleAvatar(radius: 18, backgroundColor: theme.accent1,
              backgroundImage: u.photoUrl.isNotEmpty ? NetworkImage(u.photoUrl) : null,
              child: u.photoUrl.isEmpty ? Icon(Icons.person, size: 18) : null),
          SizedBox(width: 10),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Expanded(child: Text(u.displayName.isEmpty ? '(بلا اسم)' : u.displayName, style: GoogleFonts.cairo(fontWeight: FontWeight.w700), overflow: TextOverflow.ellipsis)),
              if (isAdmin) Icon(Icons.shield, size: 16, color: theme.primary),
              if (u.isBanned) Icon(Icons.block, size: 16, color: theme.error),
            ]),
            Text(u.email, style: GoogleFonts.cairo(fontSize: 12, color: theme.secondaryText)),
            Text('UID: ${u.reference.id}${u.phoneNumber.isNotEmpty ? ' · ${u.phoneNumber}' : ''}', style: GoogleFonts.cairo(fontSize: 11, color: theme.secondaryText)),
          ])),
        ]),
        if (u.isBanned && u.banReason.isNotEmpty) Padding(padding: EdgeInsets.only(top: 4), child: Text('سبب الحظر: ${u.banReason}', style: GoogleFonts.cairo(fontSize: 12, color: theme.error))),
        SizedBox(height: 8),
        Wrap(spacing: 6, runSpacing: 4, children: [
          _btn(context, Icons.home_work_outlined, 'إعلاناته', () => _showListings(context)),
          if (!u.isBanned && !me && !isAdmin) _btn(context, Icons.block, 'حظر', () async {
            final r = await _askReason(context, 'سبب حظر ${u.displayName}');
            if (r == null) return;
            try { await adminBanUser(u.reference, r); if (context.mounted) _toast(context, 'تم الحظر — لن يستطيع النشر أو المراسلة'); }
            catch (e) { if (context.mounted) _toast(context, _errText(e), error: true); }
          }, color: theme.error),
          if (u.isBanned) _btn(context, Icons.lock_open, 'رفع الحظر', () async {
            try { await adminUnbanUser(u.reference); if (context.mounted) _toast(context, 'رُفع الحظر'); }
            catch (e) { if (context.mounted) _toast(context, _errText(e), error: true); }
          }, color: Colors.green),
          if (me) Text('(أنت)', style: GoogleFonts.cairo(fontSize: 12, color: theme.secondaryText)),
        ]),
      ]),
    );
  }

  void _showListings(BuildContext context) {
    final theme = FlutterFlowTheme.of(context);
    showModalBottomSheet(
      context: context, isScrollControlled: true,
      backgroundColor: theme.primaryBackground,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(16))),
      builder: (_) => Directionality(
        textDirection: TextDirection.rtl,
        child: DraggableScrollableSheet(
          expand: false, initialChildSize: 0.7,
          builder: (_, ctrl) => StreamBuilder<QuerySnapshot>(
            stream: userListingsQuery(u.reference).snapshots(),
            builder: (c, s) => _stateBuilder(c, s, () {
              final items = s.data!.docs.map((d) => PropertyDataRecord.fromSnapshot(d)).toList();
              if (items.isEmpty) return _empty(c, 'لا إعلانات لهذا المستخدم');
              return ListView.separated(
                controller: ctrl, padding: EdgeInsets.all(12),
                itemCount: items.length, separatorBuilder: (_, __) => SizedBox(height: 8),
                itemBuilder: (_, i) => _ListingRow(items[i]),
              );
            }),
          ),
        ),
      ),
    );
  }
}

/* ═══════════════════════════════════════════════════════════════
   5 · طلبات العقارات
   ═══════════════════════════════════════════════════════════════ */
class _RequestsTab extends StatefulWidget {
  @override
  State<_RequestsTab> createState() => _RequestsTabState();
}

class _RequestsTabState extends State<_RequestsTab> {
  String? _type;
  String? _area;

  @override
  Widget build(BuildContext context) {
    final theme = FlutterFlowTheme.of(context);
    return Column(children: [
      Padding(
        padding: EdgeInsets.fromLTRB(12, 10, 12, 4),
        child: Row(children: [
          Expanded(child: DropdownButtonFormField<String>(
            value: _type, isExpanded: true,
            decoration: InputDecoration(hintText: 'النوع', isDense: true, border: OutlineInputBorder(borderRadius: BorderRadius.circular(10))),
            items: const [DropdownMenuItem(value: null, child: Text('كل الأنواع')), DropdownMenuItem(value: 'بيع', child: Text('بيع')), DropdownMenuItem(value: 'إيجار', child: Text('إيجار')), DropdownMenuItem(value: 'بدل', child: Text('بدل'))],
            onChanged: (v) => setState(() => _type = v),
          )),
          SizedBox(width: 8),
          Expanded(child: DropdownButtonFormField<String>(
            value: _area, isExpanded: true,
            decoration: InputDecoration(hintText: 'المنطقة', isDense: true, border: OutlineInputBorder(borderRadius: BorderRadius.circular(10))),
            items: [DropdownMenuItem<String>(value: null, child: Text('كل المناطق')), ...FFAppConstants.KuwaitAreas.map((a) => DropdownMenuItem(value: a, child: Text(a)))],
            onChanged: (v) => setState(() => _area = v),
          )),
        ]),
      ),
      Expanded(child: StreamBuilder<QuerySnapshot>(
        stream: adminRequestsQuery(type: _type, area: _area).snapshots(),
        builder: (c, s) => _stateBuilder(c, s, () {
          final items = s.data!.docs.map((d) => PropertyRequestsRecord.fromSnapshot(d)).toList();
          if (items.isEmpty) return _empty(c, 'لا توجد طلبات');
          return ListView.separated(
            padding: EdgeInsets.all(12), itemCount: items.length,
            separatorBuilder: (_, __) => SizedBox(height: 8),
            itemBuilder: (_, i) {
              final r = items[i];
              return Container(
                padding: EdgeInsets.all(12),
                decoration: BoxDecoration(color: theme.secondaryBackground, borderRadius: BorderRadius.circular(12)),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('${r.requestType} · ${r.propertyType}${r.area.isNotEmpty ? ' · ${r.area}' : ''}', style: GoogleFonts.cairo(fontWeight: FontWeight.w700)),
                  if (r.details.isNotEmpty) Text(r.details, style: GoogleFonts.cairo(fontSize: 13), maxLines: 3, overflow: TextOverflow.ellipsis),
                  Row(children: [Text('صاحب الطلب: ', style: GoogleFonts.cairo(fontSize: 12, color: theme.secondaryText)), Expanded(child: _UserName(r.userRef, withUid: true))]),
                  if (r.createdAt != null) Text(dateTimeFormat('relative', r.createdAt!, locale: 'ar'), style: GoogleFonts.cairo(fontSize: 11, color: theme.secondaryText)),
                  SizedBox(height: 6),
                  _btn(context, Icons.delete_outline, 'حذف الطلب', () async {
                    if (!await _confirm(context, 'حذف الطلب', 'سيُحذف نهائياً.')) return;
                    try { await r.reference.delete(); if (context.mounted) _toast(context, 'حُذف'); }
                    catch (e) { if (context.mounted) _toast(context, _errText(e), error: true); }
                  }, color: theme.error),
                ]),
              );
            },
          );
        }),
      )),
    ]);
  }
}

/* ═══════════════════════════════════════════════════════════════
   6 · الوسطاء + طلبات التواصل
   ═══════════════════════════════════════════════════════════════ */
class _RealtorsTab extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final theme = FlutterFlowTheme.of(context);
    return ListView(padding: EdgeInsets.all(12), children: [
      Text('الوسطاء', style: GoogleFonts.cairo(fontSize: 16, fontWeight: FontWeight.w700)),
      SizedBox(height: 6),
      StreamBuilder<QuerySnapshot>(
        stream: RealtorsRecord.collection.limit(100).snapshots(),
        builder: (c, s) => _stateBuilder(c, s, () {
          final items = s.data!.docs.map((d) => RealtorsRecord.fromSnapshot(d)).toList();
          if (items.isEmpty) return Padding(padding: EdgeInsets.all(12), child: Text('لا يوجد وسطاء — يُضافون من Firebase Console', style: GoogleFonts.cairo(color: theme.secondaryText)));
          return Column(children: items.map((r) => ListTile(
            leading: CircleAvatar(backgroundImage: r.image.isNotEmpty ? NetworkImage(r.image) : null, child: r.image.isEmpty ? Icon(Icons.business) : null),
            title: Text(r.name, style: GoogleFonts.cairo(fontWeight: FontWeight.w600)),
            subtitle: Text('${r.company} · ⭐ ${r.rating}', style: GoogleFonts.cairo(fontSize: 12)),
            trailing: IconButton(icon: Icon(Icons.delete_outline, color: theme.error), onPressed: () async {
              if (!await _confirm(context, 'حذف الوسيط', r.name)) return;
              try { await r.reference.delete(); } catch (e) { if (context.mounted) _toast(context, _errText(e), error: true); }
            }),
          )).toList());
        }),
      ),
      SizedBox(height: 20),
      Text('طلبات التواصل مع الوسطاء', style: GoogleFonts.cairo(fontSize: 16, fontWeight: FontWeight.w700)),
      SizedBox(height: 6),
      StreamBuilder<QuerySnapshot>(
        stream: ContactRequestsRecord.collection.orderBy('created_at', descending: true).limit(100).snapshots(),
        builder: (c, s) => _stateBuilder(c, s, () {
          final items = s.data!.docs.map((d) => ContactRequestsRecord.fromSnapshot(d)).toList();
          if (items.isEmpty) return Padding(padding: EdgeInsets.all(12), child: Text('لا توجد طلبات تواصل', style: GoogleFonts.cairo(color: theme.secondaryText)));
          return Column(children: items.map((r) => Container(
            margin: EdgeInsets.only(bottom: 8), padding: EdgeInsets.all(12),
            decoration: BoxDecoration(color: theme.secondaryBackground, borderRadius: BorderRadius.circular(12)),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('${r.name} · ${r.phone}', style: GoogleFonts.cairo(fontWeight: FontWeight.w700)),
              if (r.email.isNotEmpty) Text(r.email, style: GoogleFonts.cairo(fontSize: 12, color: theme.secondaryText)),
              if (r.message.isNotEmpty) Text(r.message, style: GoogleFonts.cairo(fontSize: 13)),
              if (r.createdAt != null) Text(dateTimeFormat('relative', r.createdAt!, locale: 'ar'), style: GoogleFonts.cairo(fontSize: 11, color: theme.secondaryText)),
            ]),
          )).toList());
        }),
      ),
    ]);
  }
}
