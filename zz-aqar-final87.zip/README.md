# العقار — تطبيق عقارات الكويت

مشروع Flutter واحد يبني Android و iOS من نفس الكود.

## البنية

```
android/    إعدادات Android
ios/        إعدادات iOS  (Bundle ID: com.kuwait.realestate)
lib/        كود التطبيق المشترك
functions/  وظائف Firebase (is_live + search_keywords)
```

## البناء

| المنصة | الـ Workflow | الناتج |
|---|---|---|
| Android | `.github/workflows/android.yml` | APK + AAB |
| iOS | `.github/workflows/ios.yml` | IPA |

الاثنان مستقلان تماماً. أسرار Android لا تُستخدم في iOS والعكس.

## الأسرار المطلوبة

**Android** (موجودة): `KEYSTORE_BASE64`، `KEYSTORE_PASSWORD`، `KEY_PASSWORD`، `KEY_ALIAS`

**iOS** (تُضاف): `IOS_CERT_P12_BASE64`، `IOS_CERT_PASSWORD`،
`IOS_PROVISIONING_PROFILE_BASE64`، `IOS_TEAM_ID`،
`ASC_KEY_ID`، `ASC_ISSUER_ID`، `ASC_PRIVATE_KEY_BASE64`

## نشر Firebase

```bash
firebase deploy --only firestore:indexes,firestore:rules,functions
```
