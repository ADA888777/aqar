#!/usr/bin/env node
/**
 * سكربت ترحيل لمرة واحدة — قاعدة kuwait-real-estate
 *
 * التشغيل:
 *   npm i firebase-admin
 *   export GOOGLE_APPLICATION_CREDENTIALS=./service-account.json
 *   node migrate.js --dry-run     ← يعرض ما سيحدث دون كتابة
 *   node migrate.js --apply       ← ينفّذ فعلياً
 *
 * ⚠️ لا تشغّل --apply قبل أخذ نسخة احتياطية:
 *   gsutil mb -l nam5 gs://kuwait-real-estate-backup
 *   gcloud firestore export gs://kuwait-real-estate-backup/$(date +%Y%m%d) \
 *     --project=kuwait-real-estate
 */
const admin = require('firebase-admin');
admin.initializeApp();
const db = admin.firestore();

const APPLY = process.argv.includes('--apply');
const MS_PER_DAY = 86400000;
const LISTING_DAYS = 30;

if (!APPLY) console.log('══ وضع المعاينة (dry-run) — لن تُكتب أي بيانات ══\n');

/* ── تطبيع عربي (نفس منطق functions/index.js) ───────────── */
function normalizeArabic(t) {
  return String(t || '')
    .replace(/[\u064B-\u065F\u0670]/g, '')
    .replace(/\u0640/g, '')
    .replace(/[أإآٱ]/g, 'ا')
    .replace(/ة/g, 'ه')
    .replace(/ى/g, 'ي')
    .replace(/[ؤئ]/g, 'ء')
    .toLowerCase()
    .trim();
}

function buildSearchKeywords(d) {
  const src = [d.title, d.area, d.governorate, d.street,
               d.block, d.category, d.ListingTypy, d.description];
  const out = new Set();
  for (const s of src) {
    if (!s || typeof s !== 'string') continue;
    for (const w of normalizeArabic(s).split(/[\s،,.\-_/\\()]+/)) {
      if (w.length < 2) continue;
      out.add(w);
      for (let i = 3; i < w.length; i++) out.add(w.slice(0, i));
    }
  }
  return Array.from(out).slice(0, 400);
}

function computeIsLive(d) {
  if (d.isApproved !== true) return false;
  if (d.is_archived === true) return false;
  if (d.is_deleted === true) return false;
  const e = d.expires_at;
  if (e && typeof e.toMillis === 'function' && e.toMillis() <= Date.now()) return false;
  return true;
}

/* ── توحيد قيم ListingTypy الإنجليزية ───────────────────── */
const LISTING_MAP = { sale: 'بيع', rent: 'إيجار', exchange: 'بدل' };

/* ═══════════════════════════════════════════════════════════
   1) PropertyData
   ═══════════════════════════════════════════════════════════ */
async function migrateProperties() {
  console.log('── PropertyData ──');
  const snap = await db.collection('PropertyData').get();
  const suspicious = [];
  let changed = 0;

  for (const doc of snap.docs) {
    const d = doc.data();
    const patch = {};
    const notes = [];

    // expires_at: 30 يوماً من النشر
    if (!d.expires_at) {
      const base = d.published_at?.toMillis?.() ?? d.created_at?.toMillis?.() ?? Date.now();
      patch.expires_at = admin.firestore.Timestamp.fromMillis(base + LISTING_DAYS * MS_PER_DAY);
      notes.push('expires_at');
    }

    // توحيد ListingTypy الإنجليزي
    const lt = d.ListingTypy;
    if (typeof lt === 'string' && LISTING_MAP[lt.toLowerCase()]) {
      patch.ListingTypy = LISTING_MAP[lt.toLowerCase()];
      notes.push(`ListingTypy: ${lt} → ${patch.ListingTypy}`);
    }

    // search_keywords — تُبنى بعد توحيد ListingTypy
    const merged = { ...d, ...patch };
    if (!Array.isArray(d.search_keywords) || d.search_keywords.length === 0) {
      patch.search_keywords = buildSearchKeywords(merged);
      notes.push(`search_keywords (${patch.search_keywords.length})`);
    }

    // is_live — يُحسب أخيراً
    const live = computeIsLive({ ...merged, ...patch });
    if (d.is_live !== live) {
      patch.is_live = live;
      notes.push(`is_live=${live}`);
    }

    // ⚠️ floor_label لا يُنقل إلى floors — مفهومان مختلفان:
    //    floors     = عدد أدوار المبنى (int)
    //    floor_label = أي دور تقع فيه الوحدة (string)
    // النقل يُتلف البيانات. يُترك كما هو.
    if (d.floor_label !== undefined) {
      notes.push(`⚠ floor_label="${d.floor_label}" (متروك عمداً)`);
    }

    // رصد البيانات المشبوهة — للمراجعة فقط، بلا حذف
    const numericJunk = ['category', 'governorate', 'ListingTypy']
      .filter((k) => typeof d[k] === 'string' && /^\d+$/.test(d[k]));
    if (numericJunk.length) suspicious.push({ id: doc.id, reason: `قيم رقمية في ${numericJunk.join(', ')}` });
    if (typeof d.description === 'string' && /^تجرب|^test|^demo/i.test(d.description.trim()))
      suspicious.push({ id: doc.id, reason: 'وصف تجريبي' });
    if (typeof d.image === 'string' && /unsplash|picsum|placeholder/i.test(d.image))
      suspicious.push({ id: doc.id, reason: 'صورة placeholder' });

    if (Object.keys(patch).length) {
      changed++;
      console.log(`  ${doc.id}: ${notes.join(' · ')}`);
      if (APPLY) await doc.ref.update(patch);
    }
  }

  console.log(`\n  إجمالي: ${snap.size} · مُعدَّل: ${changed}`);
  if (suspicious.length) {
    console.log('\n  ⚠ وثائق للمراجعة اليدوية (لم يُحذف شيء):');
    suspicious.forEach((s) => console.log(`    ${s.id} — ${s.reason}`));
  }
  return snap;
}

/* ═══════════════════════════════════════════════════════════
   2) نقل أرقام التواصل إلى مجموعة فرعية محمية
   ═══════════════════════════════════════════════════════════ */
async function migrateContacts(snap) {
  console.log('\n── نقل أرقام التواصل ──');
  let moved = 0;

  for (const doc of snap.docs) {
    const d = doc.data();
    const phone = d.contact_phone;
    const wa = d.whatsapp_phone;
    if (!phone && !wa) continue;

    const payload = {};
    if (phone) payload.contact_phone = phone;
    if (wa) payload.whatsapp_phone = wa;
    payload.ownerRef = d.ownerRef ?? null;

    console.log(`  ${doc.id} → contact/info`);
    if (APPLY) {
      await doc.ref.collection('contact').doc('info').set(payload, { merge: true });
      // ⚠️ الحقول الأصلية تُترك مؤقتاً حتى ينتقل lib/ إلى القراءة الجديدة.
      // بعد نشر التطبيق المُحدَّث، شغّل: node migrate.js --apply --drop-legacy-phones
    }
    moved++;
  }

  console.log(`\n  نُقل: ${moved}`);
  if (moved && APPLY) {
    console.log('  ⚠ الأرقام ما زالت في الوثيقة العامة أيضاً.');
    console.log('    الحماية لا تكتمل حتى تُحذف بعد تحديث التطبيق.');
  }
}

/* ═══════════════════════════════════════════════════════════
   3) حذف الأرقام القديمة — مرحلة ثانية بعد نشر التطبيق
   ═══════════════════════════════════════════════════════════ */
async function dropLegacyPhones(snap) {
  console.log('\n── حذف الأرقام من الوثيقة العامة ──');
  const FV = admin.firestore.FieldValue;
  let n = 0;
  for (const doc of snap.docs) {
    const sub = await doc.ref.collection('contact').doc('info').get();
    if (!sub.exists) {
      console.log(`  ⏭ ${doc.id}: لا توجد نسخة في contact/ — تخطٍّ`);
      continue;
    }
    console.log(`  ${doc.id}: حذف contact_phone + whatsapp_phone`);
    if (APPLY) {
      await doc.ref.update({
        contact_phone: FV.delete(),
        whatsapp_phone: FV.delete(),
      });
    }
    n++;
  }
  console.log(`\n  حُذف من: ${n}`);
}

/* ═══════════════════════════════════════════════════════════
   4) الرسائل القديمة بلا participants
   ═══════════════════════════════════════════════════════════ */
async function migrateMessages() {
  console.log('\n── messages ──');
  const snap = await db.collection('messages').get();
  let fixed = 0;

  for (const doc of snap.docs) {
    const d = doc.data();
    if (Array.isArray(d.participants) && d.participants.length) continue;
    if (!d.chat_ref) {
      console.log(`  ⚠ ${doc.id}: بلا chat_ref — تخطٍّ`);
      continue;
    }
    const chat = await d.chat_ref.get();
    if (!chat.exists) {
      console.log(`  ⚠ ${doc.id}: المحادثة محذوفة — تخطٍّ`);
      continue;
    }
    const users = chat.data().users || [];
    const patch = { participants: users };
    if (d.is_read === undefined) patch.is_read = true;   // رسائل قديمة تُعتبر مقروءة
    if (!Array.isArray(d.deleted_for)) patch.deleted_for = [];
    if (!d.receiver_ref && d.sender_ref) {
      const other = users.find((u) => u.path !== d.sender_ref.path);
      if (other) patch.receiver_ref = other;
    }
    console.log(`  ${doc.id}: + ${Object.keys(patch).join(', ')}`);
    if (APPLY) await doc.ref.update(patch);
    fixed++;
  }
  console.log(`\n  إجمالي: ${snap.size} · مُصلَح: ${fixed}`);
}


/* ═══════════════════════════════════════════════════════════
   5) المحادثات القديمة بلا تصنيف buyer/seller
   ═══════════════════════════════════════════════════════════ */
async function migrateChats() {
  console.log('\n── chats ──');
  const snap = await db.collection('chats').get();
  let fixed = 0, ambiguous = 0;

  for (const doc of snap.docs) {
    const d = doc.data();
    if (d.seller_ref) continue;
    const users = Array.isArray(d.users) ? d.users : [];
    if (users.length !== 2) { console.log(`  ⚠ ${doc.id}: أطراف ≠ 2 — تخطٍّ`); continue; }

    // نحدد البائع من أول رسالة: المستقبِل هو صاحب الإعلان غالباً
    // (المستفسِر يبدأ المحادثة). إن لم توجد رسائل نتخطى ونُبلغ.
    const first = await db.collection('messages')
      .where('chat_ref', '==', doc.ref)
      .orderBy('created_at', 'asc').limit(1).get();
    if (first.empty || !first.docs[0].data().sender_ref) {
      ambiguous++;
      console.log(`  ⚠ ${doc.id}: بلا رسائل — لا يمكن تحديد الدور، راجعه يدوياً`);
      continue;
    }
    const sender = first.docs[0].data().sender_ref;
    const buyer = users.find((u) => u.path === sender.path);
    const seller = users.find((u) => u.path !== sender.path);
    if (!buyer || !seller) { ambiguous++; continue; }

    console.log(`  ${doc.id}: buyer=${buyer.id} seller=${seller.id}`);
    if (APPLY) await doc.ref.update({ buyer_ref: buyer, seller_ref: seller });
    fixed++;
  }
  console.log(`\n  إجمالي: ${snap.size} · مُصنَّف: ${fixed} · غامض: ${ambiguous}`);
}

/* ═══════════════════════════════════════════════════════════ */
(async () => {
  try {
    const snap = await migrateProperties();
    if (process.argv.includes('--drop-legacy-phones')) {
      await dropLegacyPhones(snap);
    } else {
      await migrateContacts(snap);
    }
    await migrateMessages();
    await migrateChats();

    console.log('\n══ انتهى ══');
    if (!APPLY) console.log('لم تُكتب أي بيانات. أعد التشغيل بـ --apply للتنفيذ.');
    else console.log('تحقّق الآن: A + B == N على PropertyData.');
  } catch (e) {
    console.error('\n✗ فشل:', e.message);
    process.exit(1);
  }
})();
