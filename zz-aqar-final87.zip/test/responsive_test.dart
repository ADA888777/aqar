// اختبارات التجاوب — تُشغَّل بـ: flutter test test/responsive_test.dart
//
// تفحص أن الشاشات لا تُنتج overflow على 9 مقاسات أندرويد حقيقية،
// مع اختبار تكبير الخط، ومحاكاة النتوء (notch) وأزرار النظام السفلية.
//
// ملاحظة: الشاشات المعتمدة على Firebase تُستثنى هنا وتُختبر يدوياً على جهاز،
// لأن تشغيلها في بيئة اختبار يتطلب محاكي Firestore.

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:google_fonts/google_fonts.dart';

import 'package:kuwait2/flutter_flow/flutter_flow_theme.dart';
import 'package:kuwait2/app_constants.dart';

/// المقاسات المطلوبة اختبارها (بالـ logical pixels)
const kDeviceSizes = <String, Size>{
  '320x568 (أصغر جهاز مدعوم)': Size(320, 568),
  '360x640 (شائع - قديم)': Size(360, 640),
  '360x800 (شائع - حديث)': Size(360, 800),
  '375x812 (نسبة طويلة)': Size(375, 812),
  '390x844': Size(390, 844),
  '412x915 (Pixel)': Size(412, 915),
  '430x932 (كبير)': Size(430, 932),
  '600x960 (تابلت صغير)': Size(600, 960),
  '800x1280 (تابلت)': Size(800, 1280),
};

/// يلتقط أخطاء التخطيط (overflow) أثناء الاختبار
class LayoutErrorCollector {
  final List<String> errors = [];
  FlutterExceptionHandler? _previous;

  void start() {
    errors.clear();
    _previous = FlutterError.onError;
    FlutterError.onError = (FlutterErrorDetails details) {
      final msg = details.exceptionAsString();
      if (msg.contains('overflowed') ||
          msg.contains('RenderFlex') ||
          msg.contains('RenderBox was not laid out') ||
          msg.contains('unbounded') ||
          msg.contains('ParentDataWidget')) {
        errors.add(msg.split('\n').first);
      }
      _previous?.call(details);
    };
  }

  void stop() {
    FlutterError.onError = _previous;
  }
}

/// يغلّف الويدجت بالبيئة التي يعمل بها التطبيق (عربي + RTL + الثيم)
Widget wrapApp(Widget child, {double textScale = 1.0, EdgeInsets? padding}) {
  return MaterialApp(
    debugShowCheckedModeBanner: false,
    locale: const Locale('ar'),
    supportedLocales: const [Locale('ar')],
    localizationsDelegates: const [
      DefaultMaterialLocalizations.delegate,
      DefaultWidgetsLocalizations.delegate,
    ],
    builder: (context, w) => MediaQuery(
      data: MediaQuery.of(context).copyWith(
        textScaler: TextScaler.linear(textScale),
        padding: padding ?? const EdgeInsets.only(top: 24, bottom: 16),
        viewPadding: padding ?? const EdgeInsets.only(top: 24, bottom: 16),
      ),
      child: Directionality(textDirection: TextDirection.rtl, child: w!),
    ),
    home: child,
  );
}

/// شاشة نموذجية تحاكي بنية بطاقات العقارات والأقسام في التطبيق
class SampleListingScreen extends StatelessWidget {
  const SampleListingScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('العقار')),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // بطاقة عقار: صورة متجاوبة + نصوص طويلة داخل صفوف
              Container(
                width: double.infinity,
                height: (MediaQuery.sizeOf(context).height * 0.32)
                    .clamp(200.0, 320.0),
                color: Colors.grey.shade300,
              ),
              const SizedBox(height: 12),
              Row(
                children: const [
                  Expanded(
                    child: Text(
                      'شقة للإيجار - ضاحية عبدالله السلام، قطعة 5، شارع 12',
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                  SizedBox(width: 8),
                  Text('350 د.ك'),
                ],
              ),
              const SizedBox(height: 12),
              // رقائق المحافظات (Wrap = يلتف بلا overflow)
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: FFAppConstants.Governorates
                    .map((g) => Chip(label: Text(g)))
                    .toList(),
              ),
              const SizedBox(height: 12),
              // صف عدّادات التقسيم الداخلي
              Row(
                children: const [
                  Expanded(child: Text('عدد غرف الماستر')),
                  Text('2'),
                ],
              ),
              const SizedBox(height: 8),
              Row(
                children: const [
                  Expanded(child: Text('غرفة عاملة منزلية')),
                  Text('نعم'),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

void main() {
  final collector = LayoutErrorCollector();

  group('التجاوب على مقاسات أندرويد', () {
    for (final entry in kDeviceSizes.entries) {
      testWidgets('لا overflow على ${entry.key}', (tester) async {
        tester.view.physicalSize = entry.value;
        tester.view.devicePixelRatio = 1.0;
        addTearDown(tester.view.resetPhysicalSize);
        addTearDown(tester.view.resetDevicePixelRatio);

        collector.start();
        await tester.pumpWidget(wrapApp(const SampleListingScreen()));
        await tester.pumpAndSettle();
        collector.stop();

        expect(collector.errors, isEmpty,
            reason: 'أخطاء تخطيط على ${entry.key}: ${collector.errors}');
      });
    }
  });

  group('تكبير خط النظام', () {
    for (final scale in [1.0, 1.15, 1.3]) {
      testWidgets('لا overflow عند تكبير الخط ×$scale على 360x640',
          (tester) async {
        tester.view.physicalSize = const Size(360, 640);
        tester.view.devicePixelRatio = 1.0;
        addTearDown(tester.view.resetPhysicalSize);
        addTearDown(tester.view.resetDevicePixelRatio);

        collector.start();
        await tester.pumpWidget(
            wrapApp(const SampleListingScreen(), textScale: scale));
        await tester.pumpAndSettle();
        collector.stop();

        expect(collector.errors, isEmpty,
            reason: 'أخطاء عند التكبير ×$scale: ${collector.errors}');
      });
    }
  });

  group('النتوء وأزرار النظام (SafeArea)', () {
    testWidgets('نتوء علوي كبير + شريط إيماءات سفلي', (tester) async {
      tester.view.physicalSize = const Size(390, 844);
      tester.view.devicePixelRatio = 1.0;
      addTearDown(tester.view.resetPhysicalSize);
      addTearDown(tester.view.resetDevicePixelRatio);

      collector.start();
      await tester.pumpWidget(wrapApp(
        const SampleListingScreen(),
        padding: const EdgeInsets.only(top: 54, bottom: 34),
      ));
      await tester.pumpAndSettle();
      collector.stop();

      expect(collector.errors, isEmpty,
          reason: 'أخطاء مع النتوء: ${collector.errors}');
    });

    testWidgets('أزرار نظام سفلية تقليدية', (tester) async {
      tester.view.physicalSize = const Size(360, 640);
      tester.view.devicePixelRatio = 1.0;
      addTearDown(tester.view.resetPhysicalSize);
      addTearDown(tester.view.resetDevicePixelRatio);

      collector.start();
      await tester.pumpWidget(wrapApp(
        const SampleListingScreen(),
        padding: const EdgeInsets.only(top: 24, bottom: 48),
      ));
      await tester.pumpAndSettle();
      collector.stop();

      expect(collector.errors, isEmpty);
    });
  });

  group('اتجاه الواجهة RTL', () {
    testWidgets('الاتجاه يمين-لليسار مفعّل', (tester) async {
      await tester.pumpWidget(wrapApp(const SampleListingScreen()));
      final dir = Directionality.of(
          tester.element(find.byType(SampleListingScreen)));
      expect(dir, TextDirection.rtl);
    });
  });
}
