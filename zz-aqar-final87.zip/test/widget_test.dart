// اختبار أساسي — تشغيل التطبيق الكامل يتطلب تهيئة Firebase،
// لذا الاختبارات الفعلية في: responsive_test.dart و data_test.dart
import 'package:flutter_test/flutter_test.dart';
import 'package:kuwait2/app_constants.dart';

void main() {
  test('ثوابت التطبيق محمّلة', () {
    expect(FFAppConstants.Governorates.length, 6);
    expect(FFAppConstants.CitiesList.length, greaterThan(100));
  });
}
