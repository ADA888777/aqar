// اختبارات البيانات — تُشغَّل بـ: flutter test test/data_test.dart
// تتحقق من محافظات ومناطق الكويت وأنواع الطلب مقابل قائمة العميل حرفياً.

import 'package:flutter_test/flutter_test.dart';
import 'package:kuwait2/app_constants.dart';

/// القائمة كما أرسلها العميل حرفاً بحرف — مرجع التحقق
const kClientAreas = <String, List<String>>{
  'العاصمة': [
    'قبلة','المرقاب','شرق','الدسمة','الدعية','بنيد القار','كيفان','الشامية',
    'الروضة','العديلية','الخالدية','القادسية','الفيحاء','النزهة','المنصورية',
    'غرناطة','الصليبيخات','الدوحة','مدينة جابر الأحمد','مدينة شمال غرب الصليبيخات',
  ],
  'حولي': [
    'حولي','السالمية','الشعب','بيان','مشرف','الزهراء','الصديق','حطين','الشهداء',
    'السلام','الرميثية','الجابرية','سلوى','البدع','ميدان حولي','النقرة','جنوب السرة',
  ],
  'الفروانية': [
    'الفروانية','خيطان','جليب الشيوخ','العمرية','الرابية','الرحاب','الأندلس',
    'إشبيلية','الفردوس','الضجيج','العارضية','العارضية الصناعية','العارضية الحرفية',
    'صباح الناصر','عبدالله المبارك','الري','الرقعي',
  ],
  'الأحمدي': [
    'الأحمدي','الفحيحيل','المنقف','أبو حليفة','المهبولة','الفنطاس','العقيلة',
    'الظهر','الرقة','هدية','الصباحية','أم الهيمان','الوفرة','الوفرة الزراعية',
    'الزور','الخيران','صباح الأحمد السكنية','صباح الأحمد البحرية',
    'علي صباح السالم','ميناء عبدالله','ميناء الأحمدي','المقوع',
  ],
  'الجهراء': [
    'الجهراء','الجهراء القديمة','القصر','النسيم','تيماء','الواحة','العيون',
    'النعيم','سعد العبدالله','كبد','العبدلي','الصليبية','الصليبية الزراعية',
    'أمغرة','مدينة المطلاع السكنية','جنوب سعد العبدالله',
  ],
  'مبارك الكبير': [
    'مبارك الكبير','صباح السالم','المسيلة','أبو فطيرة','الفنيطيس','العدان',
    'القصور','القرين','صبحان',
  ],
};

void main() {
  group('محافظات الكويت', () {
    test('المحافظات الست موجودة بالترتيب', () {
      expect(FFAppConstants.Governorates, kClientAreas.keys.toList());
    });

    test('كل محافظة لها مناطق في الخريطة', () {
      for (final g in FFAppConstants.Governorates) {
        expect(FFAppConstants.AreasByGovernorate[g], isNotNull,
            reason: 'المحافظة $g بلا مناطق');
        expect(FFAppConstants.AreasByGovernorate[g]!.isNotEmpty, isTrue);
      }
    });
  });

  group('مناطق الكويت — مطابقة قائمة العميل حرفياً', () {
    kClientAreas.forEach((gov, areas) {
      test('$gov: ${areas.length} منطقة مطابقة', () {
        final actual = FFAppConstants.AreasByGovernorate[gov] ?? const [];
        expect(actual, areas,
            reason: 'اختلاف في مناطق $gov\nالمتوقع: $areas\nالموجود: $actual');
      });
    });

    test('لا منطقة مفقودة من القائمة المسطحة', () {
      final all = kClientAreas.values.expand((e) => e).toList();
      for (final a in all) {
        expect(FFAppConstants.CitiesList.contains(a), isTrue,
            reason: 'المنطقة "$a" مفقودة من CitiesList');
      }
    });

    test('إجمالي المناطق = 101', () {
      final total = kClientAreas.values.fold<int>(0, (s, e) => s + e.length);
      final actual = FFAppConstants.AreasByGovernorate.values
          .fold<int>(0, (s, e) => s + e.length);
      expect(actual, total);
    });
  });

  group('نموذج طلب العقار', () {
    test('أنواع الطلب: شراء / إيجار / بدل', () {
      expect(FFAppConstants.RequestTypes, ['شراء', 'إيجار', 'بدل']);
    });

    test('أنواع العقار الستة', () {
      expect(FFAppConstants.RequestPropertyTypes,
          ['بيت', 'أرض', 'شقة', 'عمارة', 'مزرعة', 'محل']);
    });
  });

  group('القوائم معرّبة بالكامل', () {
    final arabic = RegExp(r'[\u0600-\u06FF]');
    final lists = <String, List<String>>{
      'Governorates': FFAppConstants.Governorates,
      'CitiesList': FFAppConstants.CitiesList,
      'PropertyType': FFAppConstants.PropertyType,
      'RequestTypes': FFAppConstants.RequestTypes,
      'RequestPropertyTypes': FFAppConstants.RequestPropertyTypes,
      'HomeTypeList': FFAppConstants.HomeTypeList,
      'AmenetiesList': FFAppConstants.AmenetiesList,
      'ViewsList': FFAppConstants.ViewsList,
      'SortByFilter': FFAppConstants.SortByFilter,
      'Speciality': FFAppConstants.Speciality,
    };
    lists.forEach((name, list) {
      test('$name بلا نصوص إنجليزية', () {
        for (final item in list) {
          if (item.trim().isEmpty) continue;
          expect(arabic.hasMatch(item), isTrue,
              reason: 'عنصر إنجليزي في $name: "$item"');
        }
      });
    });
  });
}
