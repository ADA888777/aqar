import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/realtors/components/single_realtor_options/single_realtor_options_widget.dart';
import 'dart:ui';
import '/index.dart';
import 'realtors_single_widget.dart' show RealtorsSingleWidget;
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class RealtorsSingleModel extends FlutterFlowModel<RealtorsSingleWidget> {
  ///  Local state fields for this page.

  bool isFullDescription = false;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
