import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/realtors/components/empty_list_realtors2/empty_list_realtors2_widget.dart';
import '/realtors/components/filter_realtor_language/filter_realtor_language_widget.dart';
import '/realtors/components/filter_realtor_speciality/filter_realtor_speciality_widget.dart';
import '/realtors/components/realtor_card/realtor_card_widget.dart';
import '/realtors/components/realtors_sort_by/realtors_sort_by_widget.dart';
import 'dart:ui';
import '/index.dart';
import 'package:sticky_headers/sticky_headers.dart';
import 'realtors_widget.dart' show RealtorsWidget;
import 'package:aligned_dialog/aligned_dialog.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class RealtorsModel extends FlutterFlowModel<RealtorsWidget> {
  ///  State fields for stateful widgets in this page.

  // Models for RealtorCard dynamic component.
  late FlutterFlowDynamicModels<RealtorCardModel> realtorCardModels;

  @override
  void initState(BuildContext context) {
    realtorCardModels = FlutterFlowDynamicModels(() => RealtorCardModel());
  }

  @override
  void dispose() {
    realtorCardModels.dispose();
  }
}
