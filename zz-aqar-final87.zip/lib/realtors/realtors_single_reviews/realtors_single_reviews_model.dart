import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'realtors_single_reviews_widget.dart' show RealtorsSingleReviewsWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class RealtorsSingleReviewsModel
    extends FlutterFlowModel<RealtorsSingleReviewsWidget> {
  ///  Local state fields for this page.

  bool isFullDescription = false;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
