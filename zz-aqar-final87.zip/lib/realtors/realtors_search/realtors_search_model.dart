import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/realtors/components/empty_list_realtors2/empty_list_realtors2_widget.dart';
import '/realtors/components/realtor_card/realtor_card_widget.dart';
import '/realtors/components/realtors_sort_by/realtors_sort_by_widget.dart';
import 'dart:ui';
import '/index.dart';
import 'realtors_search_widget.dart' show RealtorsSearchWidget;
import 'package:aligned_dialog/aligned_dialog.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class RealtorsSearchModel extends FlutterFlowModel<RealtorsSearchWidget> {
  ///  State fields for stateful widgets in this page.

  // State field(s) for TextField widget.
  FocusNode? textFieldFocusNode;
  TextEditingController? textController;
  String? Function(BuildContext, String?)? textControllerValidator;
  // Models for RealtorCard dynamic component.
  late FlutterFlowDynamicModels<RealtorCardModel> realtorCardModels;

  @override
  void initState(BuildContext context) {
    realtorCardModels = FlutterFlowDynamicModels(() => RealtorCardModel());
  }

  @override
  void dispose() {
    textFieldFocusNode?.dispose();
    textController?.dispose();

    realtorCardModels.dispose();
  }
}
