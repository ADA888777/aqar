import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'filter_realtor_language_widget.dart' show FilterRealtorLanguageWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class FilterRealtorLanguageModel
    extends FlutterFlowModel<FilterRealtorLanguageWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
