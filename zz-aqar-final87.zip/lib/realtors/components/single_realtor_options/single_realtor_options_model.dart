import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import '/index.dart';
import 'single_realtor_options_widget.dart' show SingleRealtorOptionsWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class SingleRealtorOptionsModel
    extends FlutterFlowModel<SingleRealtorOptionsWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
