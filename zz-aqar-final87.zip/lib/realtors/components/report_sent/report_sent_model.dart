import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'report_sent_widget.dart' show ReportSentWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:lottie/lottie.dart';
import 'package:provider/provider.dart';

class ReportSentModel extends FlutterFlowModel<ReportSentWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
