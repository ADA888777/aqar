import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_animations.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_toggle_icon.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/home/components/property_card2/property_card2_widget.dart';
import '/home/components/sent_price_offer/sent_price_offer_widget.dart';
import '/home/components/single_options2/single_options2_widget.dart';
import '/home/components/snack_bar/snack_bar_widget.dart';
import 'dart:math';
import 'dart:ui';
import '/index.dart';
import 'package:smooth_page_indicator/smooth_page_indicator.dart'
    as smooth_page_indicator;
import 'single_apartment_widget.dart' show SingleApartmentWidget;
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class SingleApartmentModel extends FlutterFlowModel<SingleApartmentWidget> {
  ///  Local state fields for this page.

  bool isFullDescription = false;

  ///  State fields for stateful widgets in this page.

  final formKey = GlobalKey<FormState>();
  // State field(s) for PageView widget.
  PageController? pageViewController;

  int get pageViewCurrentIndex => pageViewController != null &&
          pageViewController!.hasClients &&
          pageViewController!.page != null
      ? pageViewController!.page!.round()
      : 0;
  // State field(s) for TextField widget.
  FocusNode? textFieldFocusNode;
  TextEditingController? textController;
  String? Function(BuildContext, String?)? textControllerValidator;
  String? _textControllerValidator(BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'هذا الحقل مطلوب';
    }

    return null;
  }

  // Models for PropertyCard2 dynamic component.
  late FlutterFlowDynamicModels<PropertyCard2Model> propertyCard2Models;

  @override
  void initState(BuildContext context) {
    textControllerValidator = _textControllerValidator;
    propertyCard2Models = FlutterFlowDynamicModels(() => PropertyCard2Model());
  }

  @override
  void dispose() {
    textFieldFocusNode?.dispose();
    textController?.dispose();

    propertyCard2Models.dispose();
  }
}
