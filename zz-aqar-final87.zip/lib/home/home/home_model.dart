import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import '/blog/components/card3/card3_widget.dart';
import '/flutter_flow/flutter_flow_animations.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/home/components/home_location/home_location_widget.dart';
import '/home/components/home_search/home_search_widget.dart';
import '/home/components/property_card2/property_card2_widget.dart';
import '/register/components/loading2/loading2_widget.dart';
import '/walkthroughs/home.dart';
import 'dart:math';
import 'dart:ui';
import '/index.dart';
import 'home_widget.dart' show HomeWidget;
import 'package:tutorial_coach_mark/tutorial_coach_mark.dart'
    show TutorialCoachMark;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class HomeModel extends FlutterFlowModel<HomeWidget> {
  ///  State fields for stateful widgets in this page.

  TutorialCoachMark? homeController;
  // Models for PropertyCard2 dynamic component.
  late FlutterFlowDynamicModels<PropertyCard2Model> propertyCard2Models;
  // Models for Card3 dynamic component.
  late FlutterFlowDynamicModels<Card3Model> card3Models;

  @override
  void initState(BuildContext context) {
    propertyCard2Models = FlutterFlowDynamicModels(() => PropertyCard2Model());
    card3Models = FlutterFlowDynamicModels(() => Card3Model());
  }

  @override
  void dispose() {
    homeController?.finish();
    propertyCard2Models.dispose();
    card3Models.dispose();
  }
}
