import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'single_apartment2_widget.dart' show SingleApartment2Widget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class SingleApartment2Model extends FlutterFlowModel<SingleApartment2Widget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
