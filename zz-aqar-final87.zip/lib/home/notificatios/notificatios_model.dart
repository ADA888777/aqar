import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/home/components/notifications_options/notifications_options_widget.dart';
import 'dart:ui';
import 'notificatios_widget.dart' show NotificatiosWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class NotificatiosModel extends FlutterFlowModel<NotificatiosWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
