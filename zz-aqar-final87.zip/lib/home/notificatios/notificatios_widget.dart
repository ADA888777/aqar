import '/flutter_flow/flutter_flow_icon_button.dart';
import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/home/components/notifications_options/notifications_options_widget.dart';
import 'dart:ui';
import '/index.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'notificatios_model.dart';
export 'notificatios_model.dart';

class NotificatiosWidget extends StatefulWidget {
  const NotificatiosWidget({super.key});

  static String routeName = 'الإشعارات';
  static String routePath = '/notificatios';

  @override
  State<NotificatiosWidget> createState() => _NotificatiosWidgetState();
}

class _NotificatiosWidgetState extends State<NotificatiosWidget> {
  IconData _iconFor(String type) {
    switch (type) {
      case 'message': return Icons.chat_bubble_outline_rounded;
      case 'offer': return Icons.local_offer_outlined;
      case 'favorite': return Icons.favorite_border_rounded;
      case 'listing_published':
      case 'listing_republished': return Icons.check_circle_outline_rounded;
      case 'listing_updated': return Icons.edit_outlined;
      case 'listing_expiring': return Icons.schedule_rounded;
      case 'listing_expired': return Icons.timer_off_outlined;
      case 'listing_disabled': return Icons.block_rounded;
      case 'request_published': return Icons.assignment_turned_in_outlined;
      default: return Icons.notifications_none_rounded;
    }
  }

  /// يفتح الوجهة المرتبطة بالإشعار: المحادثة أو الإعلان أو الطلبات
  Future<void> _openTarget(NotificationsRecord n) async {
    final t = n.targetRef;
    if (n.targetType == 'chat' && t != null) {
      context.pushNamed(SingleMessageWidget.routeName, queryParameters: {
        'chatRef': serializeParam(t, ParamType.DocumentReference),
      }.withoutNulls);
    } else if (n.targetType == 'property' && t != null) {
      try {
        final p = await PropertyDataRecord.getDocumentOnce(t);
        if (!mounted) return;
        context.pushNamed(SingleApartmentWidget.routeName, queryParameters: {
          'data': serializeParam(p, ParamType.Document),
        }.withoutNulls, extra: <String, dynamic>{'data': p});
      } catch (_) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text('الإعلان لم يعد موجوداً')));
        }
      }
    } else if (n.targetType == 'request') {
      context.pushNamed(PropertyRequestsListWidget.routeName);
    }
  }

  late NotificatiosModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => NotificatiosModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        FocusScope.of(context).unfocus();
        FocusManager.instance.primaryFocus?.unfocus();
      },
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
        appBar: AppBar(
          backgroundColor: FlutterFlowTheme.of(context).secondaryBackground,
          automaticallyImplyLeading: false,
          leading: Padding(
            padding: EdgeInsetsDirectional.fromSTEB(6.0, 6.0, 6.0, 6.0),
            child: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 50.0,
              buttonSize: 42.0,
              fillColor: FlutterFlowTheme.of(context).accent4,
              icon: Icon(
                FFIcons.karrowLeft,
                color: FlutterFlowTheme.of(context).primaryText,
                size: 24.0,
              ),
              onPressed: () async {
                context.safePop();
              },
            ),
          ),
          title: Text(
            'الإشعارات',
            style: FlutterFlowTheme.of(context).headlineSmall.override(
                  font: GoogleFonts.cairo(
                    fontWeight:
                        FlutterFlowTheme.of(context).headlineSmall.fontWeight,
                    fontStyle:
                        FlutterFlowTheme.of(context).headlineSmall.fontStyle,
                  ),
                  letterSpacing: 0.0,
                  fontWeight:
                      FlutterFlowTheme.of(context).headlineSmall.fontWeight,
                  fontStyle:
                      FlutterFlowTheme.of(context).headlineSmall.fontStyle,
                ),
          ),
          actions: [
            Padding(
              padding: EdgeInsetsDirectional.fromSTEB(0.0, 6.0, 6.0, 6.0),
              child: FlutterFlowIconButton(
                borderColor: Colors.transparent,
                borderRadius: 50.0,
                buttonSize: 42.0,
                fillColor: FlutterFlowTheme.of(context).accent4,
                icon: Icon(
                  FFIcons.kdots,
                  color: FlutterFlowTheme.of(context).primaryText,
                  size: 24.0,
                ),
                onPressed: () async {
                  await showModalBottomSheet(
                    isScrollControlled: true,
                    backgroundColor: FlutterFlowTheme.of(context).accent4,
                    barrierColor: FlutterFlowTheme.of(context).barier,
                    context: context,
                    builder: (context) {
                      return GestureDetector(
                        onTap: () {
                          FocusScope.of(context).unfocus();
                          FocusManager.instance.primaryFocus?.unfocus();
                        },
                        child: Padding(
                          padding: MediaQuery.viewInsetsOf(context),
                          child: NotificationsOptionsWidget(),
                        ),
                      );
                    },
                  ).then((value) => safeSetState(() {}));
                },
              ),
            ),
          ],
          centerTitle: true,
          elevation: 0.0,
        ),
        body: SafeArea(
          child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // ===== الإشعارات الحقيقية =====
              // مصدرها حدث فعلي واحد: رسالة غير مقروءة موجهة لي.
              // لا تُنشأ سجلات جديدة عند فتح الصفحة، ولا تُحسب إعادة
              // قراءة البيانات حدثاً جديداً، ورسالة واحدة لكل محادثة.
              // الإشعارات الحقيقية من مجموعة notifications —
              // يُنشئها الخادم فقط عند حدث فعلي (نشر، رسالة، مفضلة…).
              // المعرّف حتمي فلا تكرار مهما أعاد StreamBuilder البناء.
              StreamBuilder<QuerySnapshot>(
                stream: currentUserReference == null
                    ? null
                    : notificationsQuery().snapshots(),
                builder: (context, snapshot) {
                  final theme = FlutterFlowTheme.of(context);
                  if (snapshot.hasError) {
                    final e = snapshot.error.toString();
                    return Padding(
                      padding: EdgeInsets.all(24.0),
                      child: Text(
                        e.contains('permission-denied')
                            ? 'الصلاحيات ترفض القراءة (permission-denied)'
                            : e.contains('index')
                                ? 'الفهرس قيد الإنشاء — حاول بعد دقائق'
                                : 'تعذّر تحميل الإشعارات — تحقق من اتصالك',
                        textAlign: TextAlign.center,
                        style: theme.bodyMedium.override(
                            font: GoogleFonts.cairo(),
                            color: theme.error,
                            letterSpacing: 0.0),
                      ),
                    );
                  }
                  if (!snapshot.hasData) {
                    return Padding(
                      padding: EdgeInsets.all(40.0),
                      child: Center(
                        child: SizedBox(
                          width: 26.0,
                          height: 26.0,
                          child: CircularProgressIndicator(
                            strokeWidth: 2.0,
                            valueColor:
                                AlwaysStoppedAnimation<Color>(theme.primary),
                          ),
                        ),
                      ),
                    );
                  }
                  final items = snapshot.data!.docs
                      .map((d) => NotificationsRecord.fromSnapshot(d))
                      .toList();
                  if (items.isEmpty) {
                    return Padding(
                      padding: EdgeInsets.all(40.0),
                      child: Center(
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(Icons.notifications_none_rounded,
                                size: 48.0, color: theme.secondaryText),
                            SizedBox(height: 12.0),
                            Text('لا توجد إشعارات بعد',
                                style: theme.bodyMedium.override(
                                    font: GoogleFonts.cairo(),
                                    color: theme.secondaryText,
                                    letterSpacing: 0.0)),
                          ],
                        ),
                      ),
                    );
                  }
                  return Padding(
                    padding:
                        EdgeInsetsDirectional.fromSTEB(15.0, 15.0, 15.0, 15.0),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: items.map((n) {
                        final icon = _iconFor(n.type);
                        return Padding(
                          padding:
                              EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 10.0),
                          child: Dismissible(
                            key: ValueKey(n.reference.path),
                            direction: DismissDirection.endToStart,
                            background: Container(
                              alignment: AlignmentDirectional(1.0, 0.0),
                              padding: EdgeInsetsDirectional.fromSTEB(
                                  0.0, 0.0, 20.0, 0.0),
                              decoration: BoxDecoration(
                                color: theme.error,
                                borderRadius: BorderRadius.circular(12.0),
                              ),
                              child: Icon(Icons.delete_outline_rounded,
                                  color: Colors.white),
                            ),
                            onDismissed: (_) => deleteNotificationForMe(
                                    n.reference)
                                .catchError((e) => debugPrint('delete: $e')),
                            child: InkWell(
                              splashColor: Colors.transparent,
                              focusColor: Colors.transparent,
                              hoverColor: Colors.transparent,
                              highlightColor: Colors.transparent,
                              onTap: () async {
                                if (!n.isRead) {
                                  markNotificationRead(n.reference)
                                      .catchError((_) {});
                                }
                                await _openTarget(n);
                              },
                              child: Container(
                                width: double.infinity,
                                padding: EdgeInsets.all(14.0),
                                decoration: BoxDecoration(
                                  color: n.isRead
                                      ? theme.secondaryBackground
                                      : theme.accent1,
                                  borderRadius: BorderRadius.circular(12.0),
                                  border: n.isRead
                                      ? null
                                      : Border.all(
                                          color: theme.primary.withOpacity(0.35),
                                          width: 1.0),
                                ),
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Container(
                                      width: 40.0,
                                      height: 40.0,
                                      decoration: BoxDecoration(
                                        color: theme.primary.withOpacity(0.12),
                                        shape: BoxShape.circle,
                                      ),
                                      child: Icon(icon,
                                          size: 20.0, color: theme.primary),
                                    ),
                                    SizedBox(width: 12.0),
                                    Expanded(
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text(n.title,
                                              style: theme.titleSmall.override(
                                                  font: GoogleFonts.cairo(
                                                      fontWeight: n.isRead
                                                          ? FontWeight.w500
                                                          : FontWeight.w700),
                                                  letterSpacing: 0.0)),
                                          if (n.body.isNotEmpty) ...[
                                            SizedBox(height: 3.0),
                                            Text(n.body,
                                                maxLines: 2,
                                                overflow: TextOverflow.ellipsis,
                                                style: theme.bodySmall.override(
                                                    font: GoogleFonts.cairo(),
                                                    color: theme.secondaryText,
                                                    letterSpacing: 0.0)),
                                          ],
                                          SizedBox(height: 5.0),
                                          Text(
                                            n.createdAt == null
                                                ? ''
                                                : dateTimeFormat('relative',
                                                    n.createdAt!,
                                                    locale: 'ar'),
                                            style: theme.bodySmall.override(
                                                font: GoogleFonts.cairo(),
                                                color: theme.secondaryText,
                                                fontSize: 11.0,
                                                letterSpacing: 0.0),
                                          ),
                                        ],
                                      ),
                                    ),
                                    if (!n.isRead)
                                      Container(
                                        width: 8.0,
                                        height: 8.0,
                                        margin: EdgeInsetsDirectional.fromSTEB(
                                            8.0, 6.0, 0.0, 0.0),
                                        decoration: BoxDecoration(
                                          color: theme.primary,
                                          shape: BoxShape.circle,
                                        ),
                                      ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        );
                      }).toList(),
                    ),
                  );
                },
              ),
            ].addToEnd(SizedBox(height: 25.0)),
          ),
        ),
        ),
      ),
    );
  }
}
