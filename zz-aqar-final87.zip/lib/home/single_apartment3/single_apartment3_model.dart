import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'single_apartment3_widget.dart' show SingleApartment3Widget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class SingleApartment3Model extends FlutterFlowModel<SingleApartment3Widget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
