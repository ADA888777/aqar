import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'filter_price_range1_widget.dart' show FilterPriceRange1Widget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class FilterPriceRange1Model extends FlutterFlowModel<FilterPriceRange1Widget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
