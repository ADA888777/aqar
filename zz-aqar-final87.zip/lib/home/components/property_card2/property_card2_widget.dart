import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_toggle_icon.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'package:smooth_page_indicator/smooth_page_indicator.dart'
    as smooth_page_indicator;
import '/index.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'property_card2_model.dart';
export 'property_card2_model.dart';

class PropertyCard2Widget extends StatefulWidget {
  const PropertyCard2Widget({
    super.key,
    this.data,
    this.index,
  });

  final PropertyDataRecord? data;
  final int? index;

  @override
  State<PropertyCard2Widget> createState() => _PropertyCard2WidgetState();
}

class _PropertyCard2WidgetState extends State<PropertyCard2Widget> {
  late PropertyCard2Model _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => PropertyCard2Model());
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    context.watch<FFAppState>();

    return InkWell(
      splashColor: Colors.transparent,
      focusColor: Colors.transparent,
      hoverColor: Colors.transparent,
      highlightColor: Colors.transparent,
      onTap: () async {
        if (widget!.data == null) {
          return;
        }
        context.pushNamed(
          SingleApartmentWidget.routeName,
          queryParameters: {
            'data': serializeParam(
              widget!.data,
              ParamType.Document,
            ),
          }.withoutNulls,
          extra: <String, dynamic>{
            'data': widget!.data,
          },
        );
      },
      child: Container(
      width: double.infinity,
      decoration: BoxDecoration(
        color: FlutterFlowTheme.of(context).cardColor,
        boxShadow: [
          BoxShadow(
            blurRadius: 8.0,
            color: Color(0x20000000),
            offset: Offset(
              0.0,
              2.0,
            ),
          )
        ],
        borderRadius: BorderRadius.circular(8.0),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.max,
        children: [
          Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(8.0),
                child: Image.network(
                  widget!.data!.propertyImages.firstOrNull ??
                        '',
                  width: 200.0,
                  height: (MediaQuery.sizeOf(context).height * 0.22).clamp(150.0, 220.0),
                  fit: BoxFit.cover,
                ),
              ),
              Stack(
                alignment: AlignmentDirectional(1.0, -1.0),
                children: [
                  Row(
                    mainAxisSize: MainAxisSize.max,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      if (widget!.index! <= 1)
                        Padding(
                          padding: EdgeInsetsDirectional.fromSTEB(
                              8.0, 8.0, 0.0, 0.0),
                          child: Container(
                            decoration: BoxDecoration(
                              color: Color(0xFFF2E8D5),
                              borderRadius: BorderRadius.circular(4.0),
                            ),
                            child: Align(
                              alignment: AlignmentDirectional(0.0, 0.0),
                              child: Padding(
                                padding: EdgeInsetsDirectional.fromSTEB(
                                    8.0, 3.0, 8.0, 3.0),
                                child: Text(
                                  'جديد',
                                  style: FlutterFlowTheme.of(context)
                                      .labelSmall
                                      .override(
                                        font: GoogleFonts.cairo(
                                          fontWeight: FontWeight.w500,
                                          fontStyle:
                                              FlutterFlowTheme.of(context)
                                                  .labelSmall
                                                  .fontStyle,
                                        ),
                                        color: Color(0xFF8A6B3F),
                                        letterSpacing: 0.0,
                                        fontWeight: FontWeight.w500,
                                        fontStyle: FlutterFlowTheme.of(context)
                                            .labelSmall
                                            .fontStyle,
                                      ),
                                ),
                              ),
                            ),
                          ),
                        ),
                      Padding(
                        padding:
                            EdgeInsetsDirectional.fromSTEB(8.0, 8.0, 0.0, 0.0),
                        child: Container(
                          decoration: BoxDecoration(
                            color: Color(0xFFF6F4EF),
                            borderRadius: BorderRadius.circular(4.0),
                          ),
                          child: Align(
                            alignment: AlignmentDirectional(0.0, 0.0),
                            child: Padding(
                              padding: EdgeInsetsDirectional.fromSTEB(
                                  8.0, 3.0, 8.0, 3.0),
                              child: Text(
                                'منذ ساعات',
                                style: FlutterFlowTheme.of(context)
                                    .labelSmall
                                    .override(
                                      font: GoogleFonts.cairo(
                                        fontWeight: FontWeight.w500,
                                        fontStyle: FlutterFlowTheme.of(context)
                                            .labelSmall
                                            .fontStyle,
                                      ),
                                      color: Color(0xFF0D1B2A),
                                      letterSpacing: 0.0,
                                      fontWeight: FontWeight.w500,
                                      fontStyle: FlutterFlowTheme.of(context)
                                          .labelSmall
                                          .fontStyle,
                                    ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                  Padding(
                    padding: EdgeInsetsDirectional.fromSTEB(0.0, 3.0, 3.0, 0.0),
                    child: Stack(
                      alignment: AlignmentDirectional(0.0, 0.0),
                      children: [
                        Icon(
                          FFIcons.kfavorite18dp000000FILL1Wght400GRAD0Opsz201,
                          color: Color(0x80000000),
                          size: 31.0,
                        ),
                        ToggleIcon(
                          onPressed: () async {
                            final ref = widget!.data?.reference;
                            if (ref == null ||
                                currentUserReference == null) {
                              if (currentUserReference == null) {
  ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(
                              content: Text('سجّل دخولك لحفظ العقارات في المفضلة'),
                            ),
                          );
                          return;
}
return;
                            }
                            final isFav =
                                FFAppState().favoritesList.contains(ref);
                            safeSetState(
                              () => isFav
                                  ? FFAppState()
                                      .removeFromFavoritesList(ref)
                                  : FFAppState().addToFavoritesList(ref),
                            );
                            await currentUserReference!.update({
                              'favorites': isFav
                                  ? FieldValue.arrayRemove([ref])
                                  : FieldValue.arrayUnion([ref]),
                            });
                          },
                          value: FFAppState()
                              .favoritesList
                              .contains(widget!.data?.reference),
                          onIcon: Icon(
                            FFIcons.kfavorite18dp000000FILL1Wght400GRAD0Opsz201,
                            color: Colors.white,
                            size: 32.0,
                          ),
                          offIcon: Icon(
                            FFIcons.kfavorite18dp000000FILL0Wght400GRAD0Opsz20,
                            color: FlutterFlowTheme.of(context).info,
                            size: 32.0,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              Padding(
                padding: EdgeInsetsDirectional.fromSTEB(12.0, 12.0, 12.0, 12.0),
                child: Column(
                  mainAxisSize: MainAxisSize.max,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      valueOrDefault<String>(
                        widget!.data?.title,
                        'null',
                      ),
                      style:
                          FlutterFlowTheme.of(context).headlineMedium.override(
                                font: GoogleFonts.cairo(
                                  fontWeight: FlutterFlowTheme.of(context)
                                      .headlineMedium
                                      .fontWeight,
                                  fontStyle: FlutterFlowTheme.of(context)
                                      .headlineMedium
                                      .fontStyle,
                                ),
                                fontSize: 20.0,
                                letterSpacing: 0.0,
                                fontWeight: FlutterFlowTheme.of(context)
                                    .headlineMedium
                                    .fontWeight,
                                fontStyle: FlutterFlowTheme.of(context)
                                    .headlineMedium
                                    .fontStyle,
                              ),
                    ),
                    Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(0.0, 8.0, 0.0, 0.0),
                      child: Row(
                        mainAxisSize: MainAxisSize.max,
                        children: [
                          Expanded(
  child: Text(
                            '${widget!.data?.rooms?.toString()} غرف',
                            style: FlutterFlowTheme.of(context)
                                .labelLarge
                                .override(
                                  font: GoogleFonts.cairo(
                                    fontWeight: FontWeight.w500,
                                    fontStyle: FlutterFlowTheme.of(context)
                                        .labelLarge
                                        .fontStyle,
                                  ),
                                  letterSpacing: 0.0,
                                  fontWeight: FontWeight.w500,
                                  fontStyle: FlutterFlowTheme.of(context)
                                      .labelLarge
                                      .fontStyle,
                                ),
                          ),
),
                          SizedBox(
                            height: 18.0,
                            child: VerticalDivider(
                              width: 20.0,
                              thickness: 1.0,
                              color: FlutterFlowTheme.of(context).border,
                            ),
                          ),
                          Text(
                            '${widget!.data?.bathrooms?.toString()} حمام${(widget!.data?.halls ?? 0) > 0 ? ' • ${widget!.data?.halls} صالة' : ''}${(widget!.data?.masterRooms ?? 0) > 0 ? ' • ${widget!.data?.masterRooms} ماستر' : ''}',
                            style: FlutterFlowTheme.of(context)
                                .labelLarge
                                .override(
                                  font: GoogleFonts.cairo(
                                    fontWeight: FontWeight.w500,
                                    fontStyle: FlutterFlowTheme.of(context)
                                        .labelLarge
                                        .fontStyle,
                                  ),
                                  letterSpacing: 0.0,
                                  fontWeight: FontWeight.w500,
                                  fontStyle: FlutterFlowTheme.of(context)
                                      .labelLarge
                                      .fontStyle,
                                ),
                          ),
                          SizedBox(
                            height: 18.0,
                            child: VerticalDivider(
                              width: 20.0,
                              thickness: 1.0,
                              color: FlutterFlowTheme.of(context).border,
                            ),
                          ),
                          Text(
                            '${widget!.data?.area} م²',
                            style: FlutterFlowTheme.of(context)
                                .labelLarge
                                .override(
                                  font: GoogleFonts.cairo(
                                    fontWeight: FontWeight.w500,
                                    fontStyle: FlutterFlowTheme.of(context)
                                        .labelLarge
                                        .fontStyle,
                                  ),
                                  letterSpacing: 0.0,
                                  fontWeight: FontWeight.w500,
                                  fontStyle: FlutterFlowTheme.of(context)
                                      .labelLarge
                                      .fontStyle,
                                ),
                          ),
                          SizedBox(
                            height: 18.0,
                            child: VerticalDivider(
                              width: 20.0,
                              thickness: 1.0,
                              color: FlutterFlowTheme.of(context).border,
                            ),
                          ),
                          Text(
                            'للبيع',
                            style: FlutterFlowTheme.of(context)
                                .labelLarge
                                .override(
                                  font: GoogleFonts.cairo(
                                    fontWeight: FlutterFlowTheme.of(context)
                                        .labelLarge
                                        .fontWeight,
                                    fontStyle: FlutterFlowTheme.of(context)
                                        .labelLarge
                                        .fontStyle,
                                  ),
                                  letterSpacing: 0.0,
                                  fontWeight: FlutterFlowTheme.of(context)
                                      .labelLarge
                                      .fontWeight,
                                  fontStyle: FlutterFlowTheme.of(context)
                                      .labelLarge
                                      .fontStyle,
                                ),
                          ),
                        ],
                      ),
                    ),
                    Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(0.0, 8.0, 0.0, 0.0),
                      child: Text(
                        valueOrDefault<String>(
                          widget!.data?.area,
                          'null',
                        ),
                        style: FlutterFlowTheme.of(context).labelSmall.override(
                              font: GoogleFonts.cairo(
                                fontWeight: FlutterFlowTheme.of(context)
                                    .labelSmall
                                    .fontWeight,
                                fontStyle: FlutterFlowTheme.of(context)
                                    .labelSmall
                                    .fontStyle,
                              ),
                              fontSize: 14.0,
                              letterSpacing: 0.0,
                              fontWeight: FlutterFlowTheme.of(context)
                                  .labelSmall
                                  .fontWeight,
                              fontStyle: FlutterFlowTheme.of(context)
                                  .labelSmall
                                  .fontStyle,
                            ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
      ),
    );
  }
}
