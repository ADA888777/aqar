import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/home/components/filter_price_range1/filter_price_range1_widget.dart';
import '/home/components/filter_price_range2/filter_price_range2_widget.dart';
import 'dart:ui';
import 'filter_price_widget.dart' show FilterPriceWidget;
import 'package:aligned_dialog/aligned_dialog.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class FilterPriceModel extends FlutterFlowModel<FilterPriceWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
