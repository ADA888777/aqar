import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'filter_price_range2_widget.dart' show FilterPriceRange2Widget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class FilterPriceRange2Model extends FlutterFlowModel<FilterPriceRange2Widget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
