import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/home/components/shimmer_effect1/shimmer_effect1_widget.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'shimmer_effect2_model.dart';
export 'shimmer_effect2_model.dart';

class ShimmerEffect2Widget extends StatefulWidget {
  const ShimmerEffect2Widget({super.key});

  @override
  State<ShimmerEffect2Widget> createState() => _ShimmerEffect2WidgetState();
}

class _ShimmerEffect2WidgetState extends State<ShimmerEffect2Widget> {
  late ShimmerEffect2Model _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => ShimmerEffect2Model());
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Builder(
      builder: (context) {
        final simpleList = FFAppConstants.SimpleList.toList();

        return ListView.separated(
          padding: EdgeInsets.zero,
          primary: false,
          scrollDirection: Axis.vertical,
          itemCount: simpleList.length,
          separatorBuilder: (_, __) => SizedBox(height: 12.0),
          itemBuilder: (context, simpleListIndex) {
            final simpleListItem = simpleList[simpleListIndex];
            return Padding(
              padding: EdgeInsetsDirectional.fromSTEB(15.0, 0.0, 15.0, 0.0),
              child: wrapWithModel(
                model: _model.shimmerEffect1Models.getModel(
                  simpleListIndex.toString(),
                  simpleListIndex,
                ),
                updateCallback: () => safeSetState(() {}),
                child: ShimmerEffect1Widget(
                  key: Key(
                    'Key1h4_${simpleListIndex.toString()}',
                  ),
                ),
              ),
            );
          },
        );
      },
    );
  }
}
