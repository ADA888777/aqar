import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/home/components/shimmer_effect1/shimmer_effect1_widget.dart';
import 'shimmer_effect2_widget.dart' show ShimmerEffect2Widget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class ShimmerEffect2Model extends FlutterFlowModel<ShimmerEffect2Widget> {
  ///  State fields for stateful widgets in this component.

  // Models for ShimmerEffect1 dynamic component.
  late FlutterFlowDynamicModels<ShimmerEffect1Model> shimmerEffect1Models;

  @override
  void initState(BuildContext context) {
    shimmerEffect1Models =
        FlutterFlowDynamicModels(() => ShimmerEffect1Model());
  }

  @override
  void dispose() {
    shimmerEffect1Models.dispose();
  }
}
