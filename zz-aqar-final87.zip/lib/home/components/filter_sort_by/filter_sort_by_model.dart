import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'filter_sort_by_widget.dart' show FilterSortByWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class FilterSortByModel extends FlutterFlowModel<FilterSortByWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
