import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'dialog_export_history_widget.dart' show DialogExportHistoryWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class DialogExportHistoryModel
    extends FlutterFlowModel<DialogExportHistoryWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
