import '/backend/schema/structs/index.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/messages/components/dialog_block_user2/dialog_block_user2_widget.dart';
import 'dart:ui';
import 'card_blocked_message_widget.dart' show CardBlockedMessageWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class CardBlockedMessageModel
    extends FlutterFlowModel<CardBlockedMessageWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
