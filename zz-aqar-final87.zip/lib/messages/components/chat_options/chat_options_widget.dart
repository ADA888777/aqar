import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/messages/components/dialog_block_user/dialog_block_user_widget.dart';
import '/messages/components/dialog_clear_mesage/dialog_clear_mesage_widget.dart';
import '/messages/components/dialog_delete_message/dialog_delete_message_widget.dart';
import '/messages/components/dialog_export_history/dialog_export_history_widget.dart';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:share_plus/share_plus.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'chat_options_model.dart';
export 'chat_options_model.dart';

class ChatOptionsWidget extends StatefulWidget {
  const ChatOptionsWidget({
    super.key,
    this.chatRef,
    this.otherUser,
  });

  final DocumentReference? chatRef;
  final DocumentReference? otherUser;

  @override
  State<ChatOptionsWidget> createState() => _ChatOptionsWidgetState();
}

class _ChatOptionsWidgetState extends State<ChatOptionsWidget> {
  late ChatOptionsModel _model;

  /// نافذة تأكيد موحّدة — تُرجع true عند الموافقة
  Future<bool> _confirm(String title, String body,
      {String okText = 'تأكيد'}) async {
    final r = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: Text(title,
            style: FlutterFlowTheme.of(context).titleMedium.override(
                  font: GoogleFonts.cairo(fontWeight: FontWeight.w600),
                  letterSpacing: 0.0,
                )),
        content: Text(body,
            style: FlutterFlowTheme.of(context).bodyMedium.override(
                  font: GoogleFonts.cairo(),
                  letterSpacing: 0.0,
                )),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(c, false),
              child: Text('إلغاء',
                  style: GoogleFonts.cairo(
                      color: FlutterFlowTheme.of(context).secondaryText))),
          TextButton(
              onPressed: () => Navigator.pop(c, true),
              child: Text(okText,
                  style: GoogleFonts.cairo(
                      fontWeight: FontWeight.w600,
                      color: FlutterFlowTheme.of(context).error))),
        ],
      ),
    );
    return r == true;
  }

  void _toast(String msg, {bool error = false}) {
    if (!context.mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg),
      backgroundColor: error
          ? FlutterFlowTheme.of(context).error
          : FlutterFlowTheme.of(context).primary,
    ));
  }

  /// مسح سجل المحادثة للمستخدم الحالي فقط (الطرف الآخر يحتفظ بنسخته)
  Future<void> _clearHistory() async {
    if (widget.chatRef == null) return;
    if (!await _confirm('مسح سجل المحادثة',
        'ستُخفى الرسائل من عندك فقط ويبقى سجل الطرف الآخر كما هو. متابعة؟',
        okText: 'مسح')) return;
    try {
      await clearChatHistoryForMe(widget.chatRef!);
      _toast('تم مسح سجل المحادثة');
    } catch (_) {
      _toast('تعذّر مسح السجل، حاول مرة أخرى', error: true);
    }
  }

  /// تصدير المحادثة كملف نصي ومشاركته بنظام المشاركة في الجهاز
  Future<void> _exportChat() async {
    if (widget.chatRef == null) return;
    try {
      final msgs = await queryMessagesRecordOnce(
        queryBuilder: (q) => q
            .where('participants', arrayContains: currentUserReference)
            .where('chat_ref', isEqualTo: widget.chatRef),
      );
      final visible = msgs
          .where((m) => !m.deletedFor.contains(currentUserReference))
          .toList()
        ..sort((a, b) => (a.createdAt ?? DateTime(2000))
            .compareTo(b.createdAt ?? DateTime(2000)));
      if (visible.isEmpty) {
        _toast('لا توجد رسائل للتصدير', error: true);
        return;
      }
      final buf = StringBuffer()
        ..writeln('سجل المحادثة — تطبيق العقار')
        ..writeln('تاريخ التصدير: ${DateTime.now()}')
        ..writeln('عدد الرسائل: ${visible.length}')
        ..writeln('─────────────────────────────');
      for (final m in visible) {
        final me = m.senderRef == currentUserReference;
        final t = m.createdAt;
        final stamp = t == null
            ? ''
            : '${t.year}/${t.month.toString().padLeft(2, '0')}/${t.day.toString().padLeft(2, '0')}'
                ' ${t.hour.toString().padLeft(2, '0')}:${t.minute.toString().padLeft(2, '0')}';
        buf.writeln('[$stamp] ${me ? 'أنا' : 'الطرف الآخر'}: ${m.text}');
      }
      // نسخ السجل للحافظة — لا نضيف مكتبة مشاركة جديدة للمشروع
      try {
        await Share.share(buf.toString(),
            subject: 'سجل المحادثة — تطبيق العقار');
      } catch (_) {
        await Clipboard.setData(ClipboardData(text: buf.toString()));
        _toast('تم نسخ سجل المحادثة (${visible.length} رسالة)');
      }
    } catch (_) {
      _toast('تعذّر تصدير المحادثة', error: true);
    }
  }

  /// حظر / فك حظر الطرف الآخر
  Future<void> _toggleBlock() async {
    final other = widget.otherUser;
    if (other == null) {
      _toast('تعذّر تحديد الطرف الآخر', error: true);
      return;
    }
    final me = currentUserReference;
    if (me == null) return;
    var blocked = false;
    try {
      final u = await UsersRecord.getDocumentOnce(me);
      blocked = u.blockedUsers.contains(other);
    } catch (_) {}
    final ok = await _confirm(
      blocked ? 'إلغاء الحظر' : 'حظر المستخدم',
      blocked
          ? 'سيتمكن من مراسلتك مجدداً. متابعة؟'
          : 'لن تصلك رسائل منه ولن يستطيع مراسلتك. متابعة؟',
      okText: blocked ? 'إلغاء الحظر' : 'حظر',
    );
    if (!ok) return;
    try {
      await setUserBlocked(other, !blocked);
      _toast(blocked ? 'تم إلغاء الحظر' : 'تم حظر المستخدم');
    } catch (_) {
      _toast('تعذّر تنفيذ العملية', error: true);
    }
  }

  /// حذف المحادثة من قائمة المستخدم الحالي
  Future<void> _deleteChat() async {
    if (widget.chatRef == null) return;
    if (!await _confirm('حذف المحادثة',
        'ستُحذف المحادثة من قائمتك ولن تظهر مجدداً. متابعة؟',
        okText: 'حذف')) return;
    try {
      await deleteChatForMe(widget.chatRef!);
      _toast('تم حذف المحادثة');
      if (context.mounted) context.safePop();
    } catch (_) {
      _toast('تعذّر حذف المحادثة', error: true);
    }
  }


  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => ChatOptionsModel());
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return InkWell(
      splashColor: Colors.transparent,
      focusColor: Colors.transparent,
      hoverColor: Colors.transparent,
      highlightColor: Colors.transparent,
      onTap: () async {
        Navigator.pop(context);
      },
      child: Column(
        mainAxisSize: MainAxisSize.max,
        mainAxisAlignment: MainAxisAlignment.end,
        children: [
          Align(
            alignment: AlignmentDirectional(0.0, 1.0),
            child: Padding(
              padding: EdgeInsetsDirectional.fromSTEB(10.0, 0.0, 10.0, 10.0),
              child: Container(
                width: double.infinity,
                decoration: BoxDecoration(
                  color: FlutterFlowTheme.of(context).secondaryBackground,
                  borderRadius: BorderRadius.circular(12.0),
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.max,
                  children: [
                    Column(
                      mainAxisSize: MainAxisSize.max,
                      children: [
                        Builder(
                          builder: (context) => InkWell(
                            splashColor: Colors.transparent,
                            focusColor: Colors.transparent,
                            hoverColor: Colors.transparent,
                            highlightColor: Colors.transparent,
                            onTap: () async {
                              Navigator.pop(context);
                              await _clearHistory();
                            },
                            child: Row(
                              mainAxisSize: MainAxisSize.max,
                              children: [
                                Padding(
                                  padding: EdgeInsetsDirectional.fromSTEB(
                                      15.0, 12.0, 0.0, 12.0),
                                  child: Container(
                                    width: 35.0,
                                    height: 35.0,
                                    decoration: BoxDecoration(
                                      color:
                                          FlutterFlowTheme.of(context).accent1,
                                      borderRadius: BorderRadius.circular(8.0),
                                    ),
                                    child: Align(
                                      alignment: AlignmentDirectional(0.0, 0.0),
                                      child: Icon(
                                        FFIcons.ktrash01,
                                        color: FlutterFlowTheme.of(context)
                                            .primaryText,
                                        size: 20.0,
                                      ),
                                    ),
                                  ),
                                ),
                                Padding(
                                  padding: EdgeInsetsDirectional.fromSTEB(
                                      15.0, 0.0, 0.0, 0.0),
                                  child: Text(
                                    'مسح سجل المحادثة',
                                    style: FlutterFlowTheme.of(context)
                                        .titleSmall
                                        .override(
                                          font: GoogleFonts.cairo(
                                            fontWeight:
                                                FlutterFlowTheme.of(context)
                                                    .titleSmall
                                                    .fontWeight,
                                            fontStyle:
                                                FlutterFlowTheme.of(context)
                                                    .titleSmall
                                                    .fontStyle,
                                          ),
                                          letterSpacing: 0.0,
                                          fontWeight:
                                              FlutterFlowTheme.of(context)
                                                  .titleSmall
                                                  .fontWeight,
                                          fontStyle:
                                              FlutterFlowTheme.of(context)
                                                  .titleSmall
                                                  .fontStyle,
                                        ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        Container(
                          width: double.infinity,
                          height: 0.5,
                          decoration: BoxDecoration(
                            color: FlutterFlowTheme.of(context).border,
                          ),
                        ),
                      ],
                    ),
                    Column(
                      mainAxisSize: MainAxisSize.max,
                      children: [
                        Builder(
                          builder: (context) => InkWell(
                            splashColor: Colors.transparent,
                            focusColor: Colors.transparent,
                            hoverColor: Colors.transparent,
                            highlightColor: Colors.transparent,
                            onTap: () async {
                              Navigator.pop(context);
                              await _exportChat();
                            },
                            child: Row(
                              mainAxisSize: MainAxisSize.max,
                              children: [
                                Padding(
                                  padding: EdgeInsetsDirectional.fromSTEB(
                                      15.0, 12.0, 0.0, 12.0),
                                  child: Container(
                                    width: 35.0,
                                    height: 35.0,
                                    decoration: BoxDecoration(
                                      color:
                                          FlutterFlowTheme.of(context).accent1,
                                      borderRadius: BorderRadius.circular(8.0),
                                    ),
                                    child: Align(
                                      alignment: AlignmentDirectional(0.0, 0.0),
                                      child: Icon(
                                        FFIcons.kdownload01,
                                        color: FlutterFlowTheme.of(context)
                                            .primaryText,
                                        size: 20.0,
                                      ),
                                    ),
                                  ),
                                ),
                                Padding(
                                  padding: EdgeInsetsDirectional.fromSTEB(
                                      15.0, 0.0, 0.0, 0.0),
                                  child: Text(
                                    'تصدير المحادثة',
                                    style: FlutterFlowTheme.of(context)
                                        .titleSmall
                                        .override(
                                          font: GoogleFonts.cairo(
                                            fontWeight:
                                                FlutterFlowTheme.of(context)
                                                    .titleSmall
                                                    .fontWeight,
                                            fontStyle:
                                                FlutterFlowTheme.of(context)
                                                    .titleSmall
                                                    .fontStyle,
                                          ),
                                          letterSpacing: 0.0,
                                          fontWeight:
                                              FlutterFlowTheme.of(context)
                                                  .titleSmall
                                                  .fontWeight,
                                          fontStyle:
                                              FlutterFlowTheme.of(context)
                                                  .titleSmall
                                                  .fontStyle,
                                        ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        Container(
                          width: double.infinity,
                          height: 0.5,
                          decoration: BoxDecoration(
                            color: FlutterFlowTheme.of(context).border,
                          ),
                        ),
                      ],
                    ),
                    Column(
                      mainAxisSize: MainAxisSize.max,
                      children: [
                        Builder(
                          builder: (context) => InkWell(
                            splashColor: Colors.transparent,
                            focusColor: Colors.transparent,
                            hoverColor: Colors.transparent,
                            highlightColor: Colors.transparent,
                            onTap: () async {
                              Navigator.pop(context);
                              await _toggleBlock();
                            },
                            child: Row(
                              mainAxisSize: MainAxisSize.max,
                              children: [
                                Padding(
                                  padding: EdgeInsetsDirectional.fromSTEB(
                                      15.0, 12.0, 0.0, 12.0),
                                  child: Container(
                                    width: 35.0,
                                    height: 35.0,
                                    decoration: BoxDecoration(
                                      color:
                                          FlutterFlowTheme.of(context).accent1,
                                      borderRadius: BorderRadius.circular(8.0),
                                    ),
                                    child: Align(
                                      alignment: AlignmentDirectional(0.0, 0.0),
                                      child: Icon(
                                        FFIcons.kslashCircle01,
                                        color: FlutterFlowTheme.of(context)
                                            .primaryText,
                                        size: 20.0,
                                      ),
                                    ),
                                  ),
                                ),
                                Padding(
                                  padding: EdgeInsetsDirectional.fromSTEB(
                                      15.0, 0.0, 0.0, 0.0),
                                  child: Text(
                                    'حظر',
                                    style: FlutterFlowTheme.of(context)
                                        .titleSmall
                                        .override(
                                          font: GoogleFonts.cairo(
                                            fontWeight:
                                                FlutterFlowTheme.of(context)
                                                    .titleSmall
                                                    .fontWeight,
                                            fontStyle:
                                                FlutterFlowTheme.of(context)
                                                    .titleSmall
                                                    .fontStyle,
                                          ),
                                          letterSpacing: 0.0,
                                          fontWeight:
                                              FlutterFlowTheme.of(context)
                                                  .titleSmall
                                                  .fontWeight,
                                          fontStyle:
                                              FlutterFlowTheme.of(context)
                                                  .titleSmall
                                                  .fontStyle,
                                        ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        Container(
                          width: double.infinity,
                          height: 0.5,
                          decoration: BoxDecoration(
                            color: FlutterFlowTheme.of(context).border,
                          ),
                        ),
                      ],
                    ),
                    Column(
                      mainAxisSize: MainAxisSize.max,
                      children: [
                        Builder(
                          builder: (context) => InkWell(
                            splashColor: Colors.transparent,
                            focusColor: Colors.transparent,
                            hoverColor: Colors.transparent,
                            highlightColor: Colors.transparent,
                            onTap: () async {
                              Navigator.pop(context);
                              await _deleteChat();
                            },
                            child: Row(
                              mainAxisSize: MainAxisSize.max,
                              children: [
                                Padding(
                                  padding: EdgeInsetsDirectional.fromSTEB(
                                      15.0, 12.0, 0.0, 12.0),
                                  child: Container(
                                    width: 35.0,
                                    height: 35.0,
                                    decoration: BoxDecoration(
                                      color:
                                          FlutterFlowTheme.of(context).accent1,
                                      borderRadius: BorderRadius.circular(8.0),
                                    ),
                                    child: Align(
                                      alignment: AlignmentDirectional(0.0, 0.0),
                                      child: Icon(
                                        FFIcons.ktrash01,
                                        color:
                                            FlutterFlowTheme.of(context).error,
                                        size: 20.0,
                                      ),
                                    ),
                                  ),
                                ),
                                Padding(
                                  padding: EdgeInsetsDirectional.fromSTEB(
                                      15.0, 0.0, 0.0, 0.0),
                                  child: Text(
                                    'حذف المحادثة',
                                    style: FlutterFlowTheme.of(context)
                                        .titleSmall
                                        .override(
                                          font: GoogleFonts.cairo(
                                            fontWeight:
                                                FlutterFlowTheme.of(context)
                                                    .titleSmall
                                                    .fontWeight,
                                            fontStyle:
                                                FlutterFlowTheme.of(context)
                                                    .titleSmall
                                                    .fontStyle,
                                          ),
                                          letterSpacing: 0.0,
                                          fontWeight:
                                              FlutterFlowTheme.of(context)
                                                  .titleSmall
                                                  .fontWeight,
                                          fontStyle:
                                              FlutterFlowTheme.of(context)
                                                  .titleSmall
                                                  .fontStyle,
                                        ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
          Align(
            alignment: AlignmentDirectional(0.0, 1.0),
            child: Padding(
              padding: EdgeInsetsDirectional.fromSTEB(10.0, 0.0, 10.0, 10.0),
              child: InkWell(
                splashColor: Colors.transparent,
                focusColor: Colors.transparent,
                hoverColor: Colors.transparent,
                highlightColor: Colors.transparent,
                onTap: () async {
                  Navigator.pop(context);
                },
                child: Container(
                  width: double.infinity,
                  height: 50.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                    borderRadius: BorderRadius.circular(12.0),
                  ),
                  child: Align(
                    alignment: AlignmentDirectional(0.0, 0.0),
                    child: Text(
                      'إلغاء',
                      style: FlutterFlowTheme.of(context).titleMedium.override(
                            font: GoogleFonts.cairo(
                              fontWeight: FlutterFlowTheme.of(context)
                                  .titleMedium
                                  .fontWeight,
                              fontStyle: FlutterFlowTheme.of(context)
                                  .titleMedium
                                  .fontStyle,
                            ),
                            color: FlutterFlowTheme.of(context).primary,
                            letterSpacing: 0.0,
                            fontWeight: FlutterFlowTheme.of(context)
                                .titleMedium
                                .fontWeight,
                            fontStyle: FlutterFlowTheme.of(context)
                                .titleMedium
                                .fontStyle,
                          ),
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
