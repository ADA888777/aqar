import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/messages/components/dialog_block_user/dialog_block_user_widget.dart';
import '/messages/components/dialog_clear_mesage/dialog_clear_mesage_widget.dart';
import '/messages/components/dialog_delete_message/dialog_delete_message_widget.dart';
import '/messages/components/dialog_export_history/dialog_export_history_widget.dart';
import 'dart:ui';
import 'chat_options_widget.dart' show ChatOptionsWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class ChatOptionsModel extends FlutterFlowModel<ChatOptionsWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
