import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import '/index.dart';
import 'message_options_widget.dart' show MessageOptionsWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class MessageOptionsModel extends FlutterFlowModel<MessageOptionsWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
