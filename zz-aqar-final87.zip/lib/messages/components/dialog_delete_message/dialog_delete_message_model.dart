import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'dialog_delete_message_widget.dart' show DialogDeleteMessageWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class DialogDeleteMessageModel
    extends FlutterFlowModel<DialogDeleteMessageWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
