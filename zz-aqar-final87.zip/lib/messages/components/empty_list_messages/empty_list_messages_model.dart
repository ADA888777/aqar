import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'empty_list_messages_widget.dart' show EmptyListMessagesWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:lottie/lottie.dart';
import 'package:provider/provider.dart';

class EmptyListMessagesModel extends FlutterFlowModel<EmptyListMessagesWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
