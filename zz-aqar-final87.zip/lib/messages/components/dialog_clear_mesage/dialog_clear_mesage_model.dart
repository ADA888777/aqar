import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'dialog_clear_mesage_widget.dart' show DialogClearMesageWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class DialogClearMesageModel extends FlutterFlowModel<DialogClearMesageWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
