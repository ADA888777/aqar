import '/backend/schema/structs/index.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/messages/components/card_message/card_message_widget.dart';
import 'dart:ui';
import 'message_search_widget.dart' show MessageSearchWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class MessageSearchModel extends FlutterFlowModel<MessageSearchWidget> {
  ///  State fields for stateful widgets in this page.

  // State field(s) for TextField widget.
  FocusNode? textFieldFocusNode;
  TextEditingController? textController;
  String? Function(BuildContext, String?)? textControllerValidator;
  // Models for CardMessage dynamic component.
  late FlutterFlowDynamicModels<CardMessageModel> cardMessageModels;

  @override
  void initState(BuildContext context) {
    cardMessageModels = FlutterFlowDynamicModels(() => CardMessageModel());
  }

  @override
  void dispose() {
    textFieldFocusNode?.dispose();
    textController?.dispose();

    cardMessageModels.dispose();
  }
}
