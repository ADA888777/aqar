import '/auth/firebase_auth/auth_util.dart';
import '/backend/schema/structs/index.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/messages/components/card_blocked_message/card_blocked_message_widget.dart';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'v_blocked_users_model.dart';
export 'v_blocked_users_model.dart';

class VBlockedUsersWidget extends StatefulWidget {
  const VBlockedUsersWidget({super.key});

  static String routeName = 'vBlockedUsers';
  static String routePath = '/vBlockedUsers';

  @override
  State<VBlockedUsersWidget> createState() => _VBlockedUsersWidgetState();
}

class _VBlockedUsersWidgetState extends State<VBlockedUsersWidget> {
  late VBlockedUsersModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => VBlockedUsersModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    context.watch<FFAppState>();

    return GestureDetector(
      onTap: () {
        FocusScope.of(context).unfocus();
        FocusManager.instance.primaryFocus?.unfocus();
      },
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
        appBar: AppBar(
          backgroundColor: FlutterFlowTheme.of(context).secondaryBackground,
          automaticallyImplyLeading: false,
          leading: Padding(
            padding: EdgeInsetsDirectional.fromSTEB(6.0, 6.0, 6.0, 6.0),
            child: FlutterFlowIconButton(
              borderRadius: 50.0,
              buttonSize: 42.0,
              fillColor: FlutterFlowTheme.of(context).accent4,
              icon: Icon(
                FFIcons.karrowLeft,
                color: FlutterFlowTheme.of(context).primaryText,
                size: 24.0,
              ),
              onPressed: () async {
                context.safePop();
              },
            ),
          ),
          title: Text(
            'المستخدمون المحظورون',
            style: FlutterFlowTheme.of(context).headlineSmall.override(
                  font: GoogleFonts.cairo(
                    fontWeight:
                        FlutterFlowTheme.of(context).headlineSmall.fontWeight,
                    fontStyle:
                        FlutterFlowTheme.of(context).headlineSmall.fontStyle,
                  ),
                  letterSpacing: 0.0,
                  fontWeight:
                      FlutterFlowTheme.of(context).headlineSmall.fontWeight,
                  fontStyle:
                      FlutterFlowTheme.of(context).headlineSmall.fontStyle,
                ),
          ),
          actions: [],
          centerTitle: true,
          elevation: 0.0,
        ),
        body: SafeArea(
          child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // قائمة المحظورين الحقيقية من users/{me}.blocked_users،
              // ومعلومات كل مستخدم من وثيقته. تُحدَّث فوراً عند فك الحظر.
              StreamBuilder<UsersRecord>(
                stream: currentUserReference == null
                    ? null
                    : UsersRecord.getDocument(currentUserReference!),
                builder: (context, meSnap) {
                  final theme = FlutterFlowTheme.of(context);
                  if (meSnap.hasError) {
                    return Padding(
                      padding: EdgeInsets.all(24.0),
                      child: Text('تعذّر التحميل',
                          textAlign: TextAlign.center,
                          style: theme.bodyMedium.override(
                              font: GoogleFonts.cairo(), color: theme.error)),
                    );
                  }
                  if (!meSnap.hasData) {
                    return Padding(
                      padding: EdgeInsets.all(24.0),
                      child: Center(
                          child: SizedBox(
                              width: 24,
                              height: 24,
                              child: CircularProgressIndicator(strokeWidth: 2))),
                    );
                  }
                  final blocked = meSnap.data!.blockedUsers;
                  if (blocked.isEmpty) {
                    return Padding(
                      padding: EdgeInsets.all(24.0),
                      child: Text('لا يوجد مستخدمون محظورون',
                          textAlign: TextAlign.center,
                          style: theme.bodyMedium.override(
                              font: GoogleFonts.cairo(),
                              color: theme.secondaryText)),
                    );
                  }
                  return ListView.separated(
                    padding: EdgeInsets.fromLTRB(0, 15.0, 0, 15.0),
                    primary: false,
                    shrinkWrap: true,
                    itemCount: blocked.length,
                    separatorBuilder: (_, __) => SizedBox(height: 12.0),
                    itemBuilder: (context, i) {
                      final ref = blocked[i];
                      return StreamBuilder<UsersRecord>(
                        stream: UsersRecord.getDocument(ref),
                        builder: (context, uSnap) {
                          final u = uSnap.data;
                          return Padding(
                            padding: EdgeInsetsDirectional.fromSTEB(
                                15.0, 0.0, 15.0, 0.0),
                            child: CardBlockedMessageWidget(
                              key: Key('blocked_${ref.id}'),
                              index: i,
                              userRef: ref,
                              data: UsersStruct(
                                name: u?.displayName ?? 'مستخدم',
                                image: u?.photoUrl ?? '',
                              ),
                            ),
                          );
                        },
                      );
                    },
                  );
                },
              ),
            ].addToEnd(SizedBox(height: 15.0)),
          ),
        ),
        ),
      ),
    );
  }
}
