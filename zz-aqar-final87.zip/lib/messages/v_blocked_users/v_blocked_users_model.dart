import '/backend/schema/structs/index.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/messages/components/card_blocked_message/card_blocked_message_widget.dart';
import 'dart:ui';
import 'v_blocked_users_widget.dart' show VBlockedUsersWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class VBlockedUsersModel extends FlutterFlowModel<VBlockedUsersWidget> {
  ///  State fields for stateful widgets in this page.

  // Models for CardBlockedMessage dynamic component.
  late FlutterFlowDynamicModels<CardBlockedMessageModel>
      cardBlockedMessageModels;

  @override
  void initState(BuildContext context) {
    cardBlockedMessageModels =
        FlutterFlowDynamicModels(() => CardBlockedMessageModel());
  }

  @override
  void dispose() {
    cardBlockedMessageModels.dispose();
  }
}
