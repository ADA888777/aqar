import '/backend/schema/structs/index.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/messages/components/card_message/card_message_widget.dart';
import '/messages/components/message_options/message_options_widget.dart';
import 'dart:ui';
import '/index.dart';
import 'messages_widget.dart' show MessagesWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class MessagesModel extends FlutterFlowModel<MessagesWidget> {
  ///  State fields for stateful widgets in this page.

  // Models for CardMessage dynamic component.
  late FlutterFlowDynamicModels<CardMessageModel> cardMessageModels1;
  // Models for CardMessage dynamic component.
  late FlutterFlowDynamicModels<CardMessageModel> cardMessageModels2;

  @override
  void initState(BuildContext context) {
    cardMessageModels1 = FlutterFlowDynamicModels(() => CardMessageModel());
    cardMessageModels2 = FlutterFlowDynamicModels(() => CardMessageModel());
  }

  @override
  void dispose() {
    cardMessageModels1.dispose();
    cardMessageModels2.dispose();
  }
}
