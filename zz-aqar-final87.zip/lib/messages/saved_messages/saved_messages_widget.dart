import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/index.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

/// الرسائل المحفوظة — كل رسالة حفظها المستخدم الحالي (ضغط مطوّل في المحادثة).
/// المصدر: messages.saved_by arrayContains me — لا قائمة محلية.
class SavedMessagesWidget extends StatelessWidget {
  const SavedMessagesWidget({super.key});

  static String routeName = 'SavedMessages';
  static String routePath = '/savedMessages';

  @override
  Widget build(BuildContext context) {
    final theme = FlutterFlowTheme.of(context);
    return Scaffold(
      backgroundColor: theme.primaryBackground,
      appBar: AppBar(
        backgroundColor: theme.primaryBackground,
        automaticallyImplyLeading: false,
        leading: FlutterFlowIconButton(
          borderRadius: 50.0,
          buttonSize: 42.0,
          icon: Icon(Icons.arrow_forward_rounded,
              color: theme.primaryText, size: 24.0),
          onPressed: () => context.safePop(),
        ),
        title: Text(
          'الرسائل المحفوظة',
          style: theme.headlineSmall.override(
            font: GoogleFonts.cairo(fontWeight: FontWeight.w600),
            letterSpacing: 0.0,
          ),
        ),
        centerTitle: true,
        elevation: 0.0,
      ),
      body: SafeArea(
        child: StreamBuilder<QuerySnapshot>(
          stream: currentUserReference == null
              ? null
              : savedMessagesQuery().snapshots(),
          builder: (context, snap) {
            if (snap.hasError) {
              return _center(
                  context,
                  snap.error.toString().contains('permission')
                      ? 'الصلاحيات ترفض القراءة (permission-denied)'
                      : snap.error.toString().contains('index')
                          ? 'الفهرس قيد الإنشاء — حاول بعد دقائق'
                          : 'تعذّر التحميل — تحقق من اتصالك',
                  error: true);
            }
            if (!snap.hasData) {
              return Center(
                  child: SizedBox(
                      width: 24,
                      height: 24,
                      child: CircularProgressIndicator(strokeWidth: 2)));
            }
            final msgs = snap.data!.docs
                .map((d) => MessagesRecord.fromSnapshot(d))
                .where((m) => !m.deletedFor.contains(currentUserReference))
                .toList();
            if (msgs.isEmpty) {
              return _center(context,
                  'لا توجد رسائل محفوظة\nاضغط مطوّلاً على أي رسالة في المحادثة لحفظها');
            }
            return ListView.separated(
              padding: EdgeInsets.all(15.0),
              itemCount: msgs.length,
              separatorBuilder: (_, __) => SizedBox(height: 10.0),
              itemBuilder: (context, i) {
                final m = msgs[i];
                return Dismissible(
                  key: ValueKey(m.reference.path),
                  direction: DismissDirection.endToStart,
                  background: Container(
                    alignment: AlignmentDirectional(1.0, 0.0),
                    padding: EdgeInsetsDirectional.fromSTEB(0, 0, 20, 0),
                    decoration: BoxDecoration(
                      color: theme.error,
                      borderRadius: BorderRadius.circular(12.0),
                    ),
                    child: Icon(Icons.bookmark_remove_outlined,
                        color: Colors.white),
                  ),
                  onDismissed: (_) => setMessageSaved(m.reference, false)
                      .catchError((e) => debugPrint('unsave: $e')),
                  child: InkWell(
                    onTap: () {
                      if (m.chatRef == null) return;
                      context.pushNamed(
                        SingleMessageWidget.routeName,
                        queryParameters: {
                          'chatRef': serializeParam(
                              m.chatRef, ParamType.DocumentReference),
                        }.withoutNulls,
                      );
                    },
                    child: Container(
                      width: double.infinity,
                      padding: EdgeInsets.all(14.0),
                      decoration: BoxDecoration(
                        color: theme.secondaryBackground,
                        borderRadius: BorderRadius.circular(12.0),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(m.text,
                              style: theme.bodyMedium.override(
                                  font: GoogleFonts.cairo(),
                                  letterSpacing: 0.0)),
                          SizedBox(height: 6.0),
                          Row(
                            children: [
                              Icon(Icons.bookmark_rounded,
                                  size: 14, color: theme.primary),
                              SizedBox(width: 4),
                              Text(
                                m.createdAt == null
                                    ? ''
                                    : dateTimeFormat('d MMM · HH:mm',
                                        m.createdAt!),
                                style: theme.bodySmall.override(
                                    font: GoogleFonts.cairo(),
                                    color: theme.secondaryText,
                                    letterSpacing: 0.0),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                );
              },
            );
          },
        ),
      ),
    );
  }

  Widget _center(BuildContext context, String text, {bool error = false}) {
    final theme = FlutterFlowTheme.of(context);
    return Padding(
      padding: EdgeInsets.all(24.0),
      child: Center(
        child: Text(text,
            textAlign: TextAlign.center,
            style: theme.bodyMedium.override(
                font: GoogleFonts.cairo(),
                color: error ? theme.error : theme.secondaryText,
                letterSpacing: 0.0)),
      ),
    );
  }
}
