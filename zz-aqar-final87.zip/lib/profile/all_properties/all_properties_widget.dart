import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/profile/components/published_card/published_card_widget.dart';
import '/profile/components/published_card2/published_card2_widget.dart';
import '/profile/components/t_a_b_b_a_r_all_properties/t_a_b_b_a_r_all_properties_widget.dart';
import 'dart:ui';
import '/index.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'all_properties_model.dart';
export 'all_properties_model.dart';

class AllPropertiesWidget extends StatefulWidget {
  const AllPropertiesWidget({
    super.key,
    bool? fromAddNew,
  }) : this.fromAddNew = fromAddNew ?? false;

  final bool fromAddNew;

  static String routeName = 'AllProperties';
  static String routePath = '/allProperties';

  @override
  State<AllPropertiesWidget> createState() => _AllPropertiesWidgetState();
}

class _AllPropertiesWidgetState extends State<AllPropertiesWidget> {
  late AllPropertiesModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => AllPropertiesModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    context.watch<FFAppState>();

    return GestureDetector(
      onTap: () {
        FocusScope.of(context).unfocus();
        FocusManager.instance.primaryFocus?.unfocus();
      },
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
        appBar: AppBar(
          backgroundColor: FlutterFlowTheme.of(context).secondaryBackground,
          automaticallyImplyLeading: false,
          leading: Padding(
            padding: EdgeInsetsDirectional.fromSTEB(6.0, 6.0, 6.0, 6.0),
            child: FlutterFlowIconButton(
              borderRadius: 50.0,
              buttonSize: 42.0,
              fillColor: FlutterFlowTheme.of(context).accent4,
              icon: Icon(
                FFIcons.karrowLeft,
                color: FlutterFlowTheme.of(context).primaryText,
                size: 24.0,
              ),
              onPressed: () async {
                if (widget!.fromAddNew) {
                  context.pushNamed(AAProfileWidget.routeName);
                } else {
                  context.safePop();
                }
              },
            ),
          ),
          title: Text(
            'كل إعلاناتي',
            style: FlutterFlowTheme.of(context).headlineSmall.override(
                  font: GoogleFonts.cairo(
                    fontWeight:
                        FlutterFlowTheme.of(context).headlineSmall.fontWeight,
                    fontStyle:
                        FlutterFlowTheme.of(context).headlineSmall.fontStyle,
                  ),
                  letterSpacing: 0.0,
                  fontWeight:
                      FlutterFlowTheme.of(context).headlineSmall.fontWeight,
                  fontStyle:
                      FlutterFlowTheme.of(context).headlineSmall.fontStyle,
                ),
          ),
          actions: [],
          centerTitle: true,
          elevation: 0.0,
        ),
        body: SafeArea(
          child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              wrapWithModel(
                model: _model.tABBARAllPropertiesModel,
                updateCallback: () => safeSetState(() {}),
                updateOnChange: true,
                child: TABBARAllPropertiesWidget(),
              ),
              Column(
                mainAxisSize: MainAxisSize.max,
                children: [
                  if (FFAppState().messagesTab == 0)
                    Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(0.0, 1.0, 0.0, 0.0),
                      child: StreamBuilder<List<PropertyDataRecord>>(
                        stream: queryPropertyDataRecord(
                          queryBuilder: (propertyDataRecord) =>
                              // النشر مباشر: نعرض كل إعلانات المستخدم بلا تصفية بالحالة
                              propertyDataRecord.where('ownerRef',
                                  isEqualTo: currentUserReference),
                          // حد أعلى: مستخدم واحد لن ينشر آلاف الإعلانات
                          limit: 100,
                        ),
                        builder: (context, snapshot) {
                          // Customize what your widget looks like when it's loading.
                          if (!snapshot.hasData) {
                            return Center(
                              child: SizedBox(
                                width: 25.0,
                                height: 25.0,
                                child: CircularProgressIndicator(
                                  valueColor: AlwaysStoppedAnimation<Color>(
                                    FlutterFlowTheme.of(context).primary,
                                  ),
                                ),
                              ),
                            );
                          }
                          List<PropertyDataRecord>
                              listViewPropertyDataRecordList = snapshot.data!;

                          return ListView.separated(
                            padding: EdgeInsets.zero,
                            primary: false,
                            shrinkWrap: true,
                            scrollDirection: Axis.vertical,
                            itemCount: listViewPropertyDataRecordList.length,
                            separatorBuilder: (_, __) => SizedBox(height: 12.0),
                            itemBuilder: (context, listViewIndex) {
                              final listViewPropertyDataRecord =
                                  listViewPropertyDataRecordList[listViewIndex];
                              return Padding(
                                padding: EdgeInsetsDirectional.fromSTEB(
                                    15.0, 0.0, 15.0, 0.0),
                                child: wrapWithModel(
                                  model: _model.publishedCardModels.getModel(
                                    listViewIndex.toString(),
                                    listViewIndex,
                                  ),
                                  updateCallback: () => safeSetState(() {}),
                                  child: PublishedCardWidget(
                                    key: Key(
                                      'Key7v0_${listViewIndex.toString()}',
                                    ),
                                    data: listViewPropertyDataRecord,
                                  ),
                                ),
                              );
                            },
                          );
                        },
                      ),
                    ),
                  if (FFAppState().messagesTab == 1)
                    Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(0.0, 1.0, 0.0, 0.0),
                      child: StreamBuilder<List<PropertyDataRecord>>(
                        stream: queryPropertyDataRecord(
                          queryBuilder: (propertyDataRecord) =>
                              // إعلانات قديمة أُنشئت قبل إلغاء المراجعة (إن وُجدت)
                              propertyDataRecord
                                  .where('ownerRef',
                                      isEqualTo: currentUserReference)
                                  .where('isApproved', isEqualTo: false),
                          limit: 100,
                        ),
                        builder: (context, snapshot) {
                          // Customize what your widget looks like when it's loading.
                          if (!snapshot.hasData) {
                            return Center(
                              child: SizedBox(
                                width: 25.0,
                                height: 25.0,
                                child: CircularProgressIndicator(
                                  valueColor: AlwaysStoppedAnimation<Color>(
                                    FlutterFlowTheme.of(context).primary,
                                  ),
                                ),
                              ),
                            );
                          }
                          List<PropertyDataRecord>
                              listViewPropertyDataRecordList = snapshot.data!;

                          return ListView.separated(
                            padding: EdgeInsets.zero,
                            primary: false,
                            shrinkWrap: true,
                            scrollDirection: Axis.vertical,
                            itemCount: listViewPropertyDataRecordList.length,
                            separatorBuilder: (_, __) => SizedBox(height: 12.0),
                            itemBuilder: (context, listViewIndex) {
                              final listViewPropertyDataRecord =
                                  listViewPropertyDataRecordList[listViewIndex];
                              return Padding(
                                padding: EdgeInsetsDirectional.fromSTEB(
                                    15.0, 0.0, 15.0, 0.0),
                                child: wrapWithModel(
                                  model: _model.publishedCard2Models.getModel(
                                    listViewIndex.toString(),
                                    listViewIndex,
                                  ),
                                  updateCallback: () => safeSetState(() {}),
                                  child: PublishedCard2Widget(
                                    key: Key(
                                      'Keyhdk_${listViewIndex.toString()}',
                                    ),
                                    data: listViewPropertyDataRecord,
                                  ),
                                ),
                              );
                            },
                          );
                        },
                      ),
                    ),
                ],
              ),
            ].addToEnd(SizedBox(height: 15.0)),
          ),
        ),
        ),
      ),
    );
  }
}
