import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/profile/components/published_card/published_card_widget.dart';
import '/profile/components/published_card2/published_card2_widget.dart';
import '/profile/components/t_a_b_b_a_r_all_properties/t_a_b_b_a_r_all_properties_widget.dart';
import 'dart:ui';
import '/index.dart';
import 'all_properties_widget.dart' show AllPropertiesWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class AllPropertiesModel extends FlutterFlowModel<AllPropertiesWidget> {
  ///  State fields for stateful widgets in this page.

  // Model for TABBARAllProperties component.
  late TABBARAllPropertiesModel tABBARAllPropertiesModel;
  // Models for PublishedCard dynamic component.
  late FlutterFlowDynamicModels<PublishedCardModel> publishedCardModels;
  // Models for PublishedCard2 dynamic component.
  late FlutterFlowDynamicModels<PublishedCard2Model> publishedCard2Models;

  @override
  void initState(BuildContext context) {
    tABBARAllPropertiesModel =
        createModel(context, () => TABBARAllPropertiesModel());
    publishedCardModels = FlutterFlowDynamicModels(() => PublishedCardModel());
    publishedCard2Models =
        FlutterFlowDynamicModels(() => PublishedCard2Model());
  }

  @override
  void dispose() {
    tABBARAllPropertiesModel.dispose();
    publishedCardModels.dispose();
    publishedCard2Models.dispose();
  }
}
