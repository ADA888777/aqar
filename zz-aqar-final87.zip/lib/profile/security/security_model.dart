import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import '/index.dart';
import 'security_widget.dart' show SecurityWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class SecurityModel extends FlutterFlowModel<SecurityWidget> {
  ///  State fields for stateful widgets in this page.

  // State field(s) for Switch widget.
  bool? switchValue1;
  // State field(s) for Switch widget.
  bool? switchValue2;
  // State field(s) for Switch widget.
  bool? switchValue3;

  // ===== نموذج تغيير كلمة المرور =====
  final pwdFormKey = GlobalKey<FormState>();
  TextEditingController? oldPwdController;
  TextEditingController? newPwdController;
  TextEditingController? confirmPwdController;
  bool isChangingPwd = false;

  @override
  void initState(BuildContext context) {
    oldPwdController = TextEditingController();
    newPwdController = TextEditingController();
    confirmPwdController = TextEditingController();
  }

  @override
  void dispose() {
    oldPwdController?.dispose();
    newPwdController?.dispose();
    confirmPwdController?.dispose();}
}
