import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'help_center_terms_model.dart';
export 'help_center_terms_model.dart';

class HelpCenterTermsWidget extends StatefulWidget {
  const HelpCenterTermsWidget({super.key});

  static String routeName = 'HelpCenterTerms';
  static String routePath = '/helpCenterTerms';

  @override
  State<HelpCenterTermsWidget> createState() => _HelpCenterTermsWidgetState();
}

class _HelpCenterTermsWidgetState extends State<HelpCenterTermsWidget> {
  late HelpCenterTermsModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => HelpCenterTermsModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        FocusScope.of(context).unfocus();
        FocusManager.instance.primaryFocus?.unfocus();
      },
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: FlutterFlowTheme.of(context).secondaryBackground,
        appBar: AppBar(
          backgroundColor: FlutterFlowTheme.of(context).secondaryBackground,
          automaticallyImplyLeading: false,
          leading: Padding(
            padding: EdgeInsetsDirectional.fromSTEB(6.0, 6.0, 6.0, 6.0),
            child: FlutterFlowIconButton(
              borderRadius: 50.0,
              buttonSize: 42.0,
              fillColor: FlutterFlowTheme.of(context).accent4,
              icon: Icon(
                FFIcons.karrowLeft,
                color: FlutterFlowTheme.of(context).primaryText,
                size: 24.0,
              ),
              onPressed: () async {
                context.safePop();
              },
            ),
          ),
          title: Text(
            'الشروط والأحكام',
            style: FlutterFlowTheme.of(context).headlineSmall.override(
                  font: GoogleFonts.cairo(
                    fontWeight:
                        FlutterFlowTheme.of(context).headlineSmall.fontWeight,
                    fontStyle:
                        FlutterFlowTheme.of(context).headlineSmall.fontStyle,
                  ),
                  letterSpacing: 0.0,
                  fontWeight:
                      FlutterFlowTheme.of(context).headlineSmall.fontWeight,
                  fontStyle:
                      FlutterFlowTheme.of(context).headlineSmall.fontStyle,
                ),
          ),
          actions: [],
          centerTitle: true,
          elevation: 0.0,
        ),
        body: SafeArea(
          child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Padding(
                padding: EdgeInsetsDirectional.fromSTEB(16.0, 0.0, 16.0, 0.0),
                child: Text(
                  'مرحبًا بك في تطبيق العقار | AL AQAR. باستخدامك للتطبيق أو إنشاء حساب أو نشر إعلان من خلاله، فإنك تقر بقراءة هذه الشروط والأحكام والموافقة عليها.\n\n1. طبيعة التطبيق\nتطبيق العقار | AL AQAR هو منصة إلكترونية تهدف إلى تسهيل عرض وتصفح الإعلانات العقارية والتواصل بين المستخدمين والمعلنين.\nلا يُعد التطبيق طرفًا في عمليات البيع أو الشراء أو الإيجار أو البدل أو أي اتفاق يتم بين المستخدمين، ولا يضمن إتمام أي صفقة عقارية بين الأطراف.\n\n2. الإعلانات العقارية\nيتحمل المعلن المسؤولية الكاملة عن صحة ودقة جميع المعلومات والصور والأسعار والمواصفات والمواقع والتفاصيل التي يقوم بنشرها.\nويقر المعلن بأن لديه الحق أو الصلاحية اللازمة للإعلان عن العقار، وأن الإعلان لا يخالف القوانين واللوائح المعمول بها في دولة الكويت.\n\n3. التحقق من المعلومات\nيجب على المستخدم التحقق بنفسه من العقار وملكيته ومستنداته ومواصفاته وسعره وهوية وصفة الطرف الآخر قبل دفع أي مبالغ أو إبرام أي اتفاق أو التزام.\nوجود إعلان داخل التطبيق لا يعني أن العقار | AL AQAR يضمن العقار أو المعلن أو صحة جميع البيانات الواردة في الإعلان.\n\n4. مسؤولية الصفقات\nأي تواصل أو تفاوض أو اتفاق أو دفعات مالية أو عقود تتم بين المستخدمين والمعلنين تكون على مسؤولية أطرافها.\nولا يتحمل التطبيق المسؤولية عن أي خسائر أو أضرار أو نزاعات تنشأ نتيجة تعامل بين المستخدمين، وذلك في الحدود التي يسمح بها القانون.\n\n5. الإعلانات المخالفة\nيحق لإدارة التطبيق، وفق تقديرها وبما يتوافق مع القانون، رفض أو إخفاء أو حذف أي إعلان يتضمن معلومات مضللة أو محتوى مخالف أو مكرر أو غير متعلق بالعقار أو يشتبه في عدم صحته.\nكما يحق للإدارة تعليق أو إيقاف الحسابات التي تسيء استخدام التطبيق أو تخالف هذه الشروط.\n\n6. المكاتب والمعلنين\nظهور مكتب عقاري أو معلن أو حساب داخل التطبيق لا يُعد ضمانًا من التطبيق لأعماله أو للعقارات التي يعرضها.\nويتحمل كل مكتب أو معلن مسؤولية الالتزام بالتراخيص والاشتراطات والقوانين المنظمة لنشاطه وإعلاناته.\n\n7. الأسعار والمعلومات\nالأسعار والمعلومات المعروضة يحددها المعلنون وقد تتغير دون إشعار مسبق.\nوعلى المستخدم التأكد من السعر النهائي وتوافر العقار وجميع التفاصيل مباشرةً مع المعلن قبل اتخاذ أي قرار.\n\n8. الحسابات\nيتحمل المستخدم مسؤولية المحافظة على بيانات حسابه وعدم السماح للآخرين باستخدامه بصورة غير مصرح بها.\nويجب تقديم معلومات صحيحة عند التسجيل أو استخدام الخدمات التي تتطلب بيانات المستخدم.\n\n9. الاستخدام الممنوع\nيُمنع استخدام التطبيق لنشر إعلانات وهمية أو معلومات مضللة، أو انتحال صفة الآخرين، أو الاحتيال، أو نشر محتوى مخالف للقانون، أو محاولة الإضرار بالتطبيق أو مستخدميه.\n\n10. الصور والمحتوى\nيتحمل المستخدم مسؤولية المحتوى والصور التي يقوم برفعها، ويقر بأن لديه الحق في استخدامها ونشرها.\nويمنح المستخدم التطبيق الإذن بعرض المحتوى المنشور بالقدر اللازم لتقديم خدمات التطبيق وتشغيل الإعلانات.\n\n11. حقوق التطبيق\nاسم العقار | AL AQAR وشعار التطبيق وتصميماته ومحتواه الخاص والهوية البصرية والبرمجيات التابعة له محمية وفق الحقوق المقررة قانونًا، ولا يجوز استخدامها أو نسخها دون إذن، باستثناء المحتوى المملوك للمستخدمين أو الأطراف الأخرى.\n\n12. توفر الخدمة\nنسعى إلى توفير التطبيق بصورة مستقرة، إلا أنه قد يتم إيقاف بعض الخدمات مؤقتًا لأغراض الصيانة أو التحديث أو لأسباب تقنية خارجة عن السيطرة.\n\n13. الخصوصية\nتتم معالجة بيانات المستخدمين وفق سياسة الخصوصية الخاصة بالتطبيق، ويُنصح بقراءتها قبل استخدام التطبيق.\n\n14. تعديل الشروط\nيجوز تحديث هذه الشروط والأحكام عند الحاجة، وسيتم نشر النسخة المحدثة داخل التطبيق أو عبر الوسائل المناسبة، ويصبح استمرار استخدام التطبيق بعد سريان التحديث خاضعًا للشروط المحدثة.\n\n15. القانون المعمول به\nتخضع هذه الشروط والأحكام للقوانين والأنظمة المعمول بها في دولة الكويت، وتختص الجهات القضائية الكويتية بالنظر في النزاعات وفقًا للقانون.\n\n16. التواصل\nلأي استفسار أو بلاغ عن إعلان مخالف، يمكن التواصل مع إدارة العقار | AL AQAR من خلال وسائل التواصل المعتمدة والمبيّنة داخل التطبيق.\n\nآخر تحديث: سبتمبر 2026',
                  textAlign: TextAlign.justify,
                  style: FlutterFlowTheme.of(context).titleSmall.override(
                        font: GoogleFonts.cairo(
                          fontWeight: FlutterFlowTheme.of(context)
                              .titleSmall
                              .fontWeight,
                          fontStyle:
                              FlutterFlowTheme.of(context).titleSmall.fontStyle,
                        ),
                        letterSpacing: 0.0,
                        fontWeight:
                            FlutterFlowTheme.of(context).titleSmall.fontWeight,
                        fontStyle:
                            FlutterFlowTheme.of(context).titleSmall.fontStyle,
                      ),
                ),
              ),
            ]
                .addToStart(SizedBox(height: 15.0))
                .addToEnd(SizedBox(height: 15.0)),
          ),
        ),
        ),
      ),
    );
  }
}
