import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/profile/components/invite_friendss/invite_friendss_widget.dart';
import '/walkthroughs/invite_friends.dart';
import 'dart:ui';
import 'invite_friends_widget.dart' show InviteFriendsWidget;
import 'package:tutorial_coach_mark/tutorial_coach_mark.dart'
    show TutorialCoachMark;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class InviteFriendsModel extends FlutterFlowModel<InviteFriendsWidget> {
  ///  State fields for stateful widgets in this page.

  TutorialCoachMark? inviteFriendsController;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    inviteFriendsController?.finish();
  }
}
