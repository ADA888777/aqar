import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'help_center_privacy_model.dart';
export 'help_center_privacy_model.dart';

class HelpCenterPrivacyWidget extends StatefulWidget {
  const HelpCenterPrivacyWidget({super.key});

  static String routeName = 'HelpCenterPrivacy';
  static String routePath = '/helpCenterPrivacy';

  @override
  State<HelpCenterPrivacyWidget> createState() =>
      _HelpCenterPrivacyWidgetState();
}

class _HelpCenterPrivacyWidgetState extends State<HelpCenterPrivacyWidget> {
  late HelpCenterPrivacyModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => HelpCenterPrivacyModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        FocusScope.of(context).unfocus();
        FocusManager.instance.primaryFocus?.unfocus();
      },
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: FlutterFlowTheme.of(context).secondaryBackground,
        appBar: AppBar(
          backgroundColor: FlutterFlowTheme.of(context).secondaryBackground,
          automaticallyImplyLeading: false,
          leading: Padding(
            padding: EdgeInsetsDirectional.fromSTEB(6.0, 6.0, 6.0, 6.0),
            child: FlutterFlowIconButton(
              borderRadius: 50.0,
              buttonSize: 42.0,
              fillColor: FlutterFlowTheme.of(context).accent4,
              icon: Icon(
                FFIcons.karrowLeft,
                color: FlutterFlowTheme.of(context).primaryText,
                size: 24.0,
              ),
              onPressed: () async {
                context.safePop();
              },
            ),
          ),
          title: Text(
            'سياسة الخصوصية',
            style: FlutterFlowTheme.of(context).headlineSmall.override(
                  font: GoogleFonts.cairo(
                    fontWeight:
                        FlutterFlowTheme.of(context).headlineSmall.fontWeight,
                    fontStyle:
                        FlutterFlowTheme.of(context).headlineSmall.fontStyle,
                  ),
                  letterSpacing: 0.0,
                  fontWeight:
                      FlutterFlowTheme.of(context).headlineSmall.fontWeight,
                  fontStyle:
                      FlutterFlowTheme.of(context).headlineSmall.fontStyle,
                ),
          ),
          actions: [],
          centerTitle: true,
          elevation: 0.0,
        ),
        body: SafeArea(
          child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Padding(
                padding: EdgeInsetsDirectional.fromSTEB(16.0, 0.0, 16.0, 0.0),
                child: Text(
                  'At عقارات الكويت, we value and respect your privacy. This Privacy Policy outlines how we collect, use, disclose, and safeguard your personal information when you use our platform. By accessing or using عقارات الكويت, you agree to the terms of this policy.\n\n1. Information We Collect\nWe collect personal information that you provide to us, as well as information automatically gathered when you use our platform.\n\n1.1 Personal Information:\n\nAccount Information: When you register for an account, we collect details such as your name, email address, phone number, and payment information (for premium services).\nProperty Information: If you list a property, we may collect information such as property details, images, and location.\nCommunication Information: If you contact us, we may collect information related to your inquiry or feedback.\n1.2 Usage Information:\n\nLog Data: We collect data such as your IP address, browser type, operating system, and browsing activity on our platform.\nCookies: We use cookies to enhance your experience, track usage patterns, and personalize content.\n2. How We Use Your Information\nWe use the information we collect for the following purposes:\n\nProviding Services: To process your transactions, create and manage your account, and provide customer support.\nImproving User Experience: To personalize content, recommendations, and advertisements based on your preferences and activities.\nMarketing Communications: To send you updates, promotions, and information about عقارات الكويت, which you can opt-out of at any time.\nSecurity: To monitor activity for fraud prevention and maintain the safety and integrity of our platform.\n3. Sharing Your Information\nWe do not sell your personal information. However, we may share your information with third parties in the following cases:\n\nService Providers: We may share your information with trusted third-party vendors who help us operate our platform (e.g., payment processors, hosting services).\nLegal Requirements: If required by law, we may disclose your information to comply with legal processes or protect our rights.\nBusiness Transfers: In the event of a merger, acquisition, or sale of assets, your information may be transferred to the new owner.\n4. Data Security\nWe implement reasonable security measures to protect your personal information. However, no data transmission over the internet or electronic storage system can be guaranteed to be 100% secure. While we strive to protect your information, we cannot guarantee its absolute security.\n\n5. Your Rights\nYou have the right to:\n\nAccess: Request a copy of the personal information we hold about you.\nCorrection: Request corrections to any inaccurate or incomplete information.\nDeletion: Request the deletion of your personal information, subject to legal obligations.\nOpt-Out: You can opt-out of marketing communications at any time by following the unsubscribe instructions in emails or contacting us directly.\n6. Third-Party Links\nOur platform may contain links to third-party websites or services. This Privacy Policy applies only to عقارات الكويت, and we are not responsible for the privacy practices of other websites. We encourage you to read the privacy policies of any third-party websites you visit.\n\n7. Children\'s Privacy\nعقارات الكويت is not intended for users under the age of 13. We do not knowingly collect personal information from children. If we become aware that a child has provided us with personal information, we will take steps to delete such information from our records.\n\n8. Changes to This Privacy Policy\nWe may update this Privacy Policy from time to time. If we make significant changes, we will notify you by email or post a notice on our platform. By continuing to use our platform after such changes, you accept the updated policy.',
                  style: FlutterFlowTheme.of(context).titleSmall.override(
                        font: GoogleFonts.cairo(
                          fontWeight: FlutterFlowTheme.of(context)
                              .titleSmall
                              .fontWeight,
                          fontStyle:
                              FlutterFlowTheme.of(context).titleSmall.fontStyle,
                        ),
                        letterSpacing: 0.0,
                        fontWeight:
                            FlutterFlowTheme.of(context).titleSmall.fontWeight,
                        fontStyle:
                            FlutterFlowTheme.of(context).titleSmall.fontStyle,
                      ),
                ),
              ),
            ]
                .addToStart(SizedBox(height: 15.0))
                .addToEnd(SizedBox(height: 15.0)),
          ),
        ),
        ),
      ),
    );
  }
}
