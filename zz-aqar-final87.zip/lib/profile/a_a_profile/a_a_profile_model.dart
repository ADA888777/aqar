import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/profile/components/dialog_logut/dialog_logut_widget.dart';
import '/profile/components/profile_options/profile_options_widget.dart';
import 'dart:ui';
import '/index.dart';
import 'a_a_profile_widget.dart' show AAProfileWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class AAProfileModel extends FlutterFlowModel<AAProfileWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
