import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'about_houzy_widget.dart' show AboutHouzyWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class AboutHouzyModel extends FlutterFlowModel<AboutHouzyWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
