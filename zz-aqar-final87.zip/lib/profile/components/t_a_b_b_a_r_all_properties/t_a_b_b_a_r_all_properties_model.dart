import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 't_a_b_b_a_r_all_properties_widget.dart' show TABBARAllPropertiesWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class TABBARAllPropertiesModel
    extends FlutterFlowModel<TABBARAllPropertiesWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
