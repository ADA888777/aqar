import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import '/index.dart';
import 'published_card2_widget.dart' show PublishedCard2Widget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class PublishedCard2Model extends FlutterFlowModel<PublishedCard2Widget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
