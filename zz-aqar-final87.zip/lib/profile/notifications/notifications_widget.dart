import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'notifications_model.dart';
export 'notifications_model.dart';

class NotificationsWidget extends StatefulWidget {
  const NotificationsWidget({super.key});

  static String routeName = 'الإشعارات';
  static String routePath = '/notifications';

  @override
  State<NotificationsWidget> createState() => _NotificationsWidgetState();
}

class _NotificationsWidgetState extends State<NotificationsWidget> {
  late NotificationsModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => NotificationsModel());

    // القيم الافتراضية تظهر فوراً، ثم تُستبدل بالمحفوظة في Firestore
    _settings = Map.of(kNotifDefaults);
    _load();
  }

  Map<String, bool> _settings = {};
  bool _loading = true;
  String? _error;

  Future<void> _load() async {
    try {
      final s = await loadNotificationSettings();
      if (mounted) safeSetState(() { _settings = s; _loading = false; });
    } catch (e) {
      debugPrint('loadNotificationSettings: $e');
      if (mounted) safeSetState(() { _loading = false; _error = e.toString(); });
    }
  }

  Future<void> _toggle(String key, bool value) async {
    final prev = _settings[key];
    safeSetState(() => _settings[key] = value); // استجابة فورية
    try {
      await saveNotificationSetting(key, value);
    } catch (e) {
      debugPrint('saveNotificationSetting($key): $e');
      if (mounted) {
        safeSetState(() => _settings[key] = prev ?? value); // تراجع
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text('تعذّر حفظ الإعداد — '
              '${e.toString().contains('permission') ? 'الصلاحيات' : 'تحقق من الاتصال'}'),
          backgroundColor: FlutterFlowTheme.of(context).error,
        ));
      }
    }
  }

  Widget _row(String title, String subtitle, String key) {
    final theme = FlutterFlowTheme.of(context);
    return Padding(
      padding: EdgeInsetsDirectional.fromSTEB(15.0, 0.0, 15.0, 10.0),
      child: Container(
        decoration: BoxDecoration(
          color: theme.secondaryBackground,
          borderRadius: BorderRadius.circular(12.0),
        ),
        child: SwitchListTile.adaptive(
          value: _settings[key] ?? kNotifDefaults[key] ?? true,
          onChanged: _loading ? null : (v) => _toggle(key, v),
          activeColor: theme.primary,
          title: Text(title,
              style: theme.titleSmall.override(
                  font: GoogleFonts.cairo(fontWeight: FontWeight.w600),
                  letterSpacing: 0.0)),
          subtitle: Text(subtitle,
              style: theme.bodySmall.override(
                  font: GoogleFonts.cairo(),
                  color: theme.secondaryText,
                  letterSpacing: 0.0)),
        ),
      ),
    );
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        FocusScope.of(context).unfocus();
        FocusManager.instance.primaryFocus?.unfocus();
      },
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: FlutterFlowTheme.of(context).secondaryBackground,
        appBar: AppBar(
          backgroundColor: FlutterFlowTheme.of(context).secondaryBackground,
          automaticallyImplyLeading: false,
          leading: Padding(
            padding: EdgeInsetsDirectional.fromSTEB(6.0, 6.0, 6.0, 6.0),
            child: FlutterFlowIconButton(
              borderRadius: 50.0,
              buttonSize: 42.0,
              fillColor: FlutterFlowTheme.of(context).accent4,
              icon: Icon(
                FFIcons.karrowLeft,
                color: FlutterFlowTheme.of(context).primaryText,
                size: 24.0,
              ),
              onPressed: () async {
                context.safePop();
              },
            ),
          ),
          title: Text(
            'الإشعارات',
            style: FlutterFlowTheme.of(context).headlineSmall.override(
                  font: GoogleFonts.cairo(
                    fontWeight:
                        FlutterFlowTheme.of(context).headlineSmall.fontWeight,
                    fontStyle:
                        FlutterFlowTheme.of(context).headlineSmall.fontStyle,
                  ),
                  letterSpacing: 0.0,
                  fontWeight:
                      FlutterFlowTheme.of(context).headlineSmall.fontWeight,
                  fontStyle:
                      FlutterFlowTheme.of(context).headlineSmall.fontStyle,
                ),
          ),
          actions: [],
          centerTitle: true,
          elevation: 0.0,
        ),
        body: SafeArea(
          top: true,
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.max,
              children: [
                if (_error != null)
                  Padding(
                    padding: EdgeInsetsDirectional.fromSTEB(15.0, 15.0, 15.0, 0.0),
                    child: Text(
                      'تعذّر تحميل الإعدادات — تُعرض القيم الافتراضية',
                      textAlign: TextAlign.center,
                      style: FlutterFlowTheme.of(context).bodySmall.override(
                          font: GoogleFonts.cairo(),
                          color: FlutterFlowTheme.of(context).error,
                          letterSpacing: 0.0),
                    ),
                  ),
                SizedBox(height: 15.0),
                _row('الإشعارات العامة', 'رسائل جديدة وتحديثات الإعلانات', 'messages'),
                _row('طلبات العقارات', 'تنبيه عند ورود طلب يناسب إعلاناتك', 'requests'),
                _row('الصوت', 'تشغيل صوت مع الإشعار', 'sound'),
                _row('عروض مميزة', 'أخبار وعروض من العقار', 'marketing'),
                if (_loading)
                  Padding(
                    padding: EdgeInsets.all(20.0),
                    child: SizedBox(
                      width: 22, height: 22,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    ),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
