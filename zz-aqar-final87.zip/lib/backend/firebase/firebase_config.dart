import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: FirebaseOptions(
            apiKey: "AIzaSyAIg6y_kRa9ETDGGkKXyafJGbwlpgsoJho",
            authDomain: "kuwait-real-estate.firebaseapp.com",
            projectId: "kuwait-real-estate",
            storageBucket: "kuwait-real-estate.firebasestorage.app",
            messagingSenderId: "313156990199",
            appId: "1:313156990199:web:10ac7fb068e4a5efb4cff2"));
  } else {
    await Firebase.initializeApp();
  }
}
