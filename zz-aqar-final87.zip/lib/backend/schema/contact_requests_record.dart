import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class ContactRequestsRecord extends FirestoreRecord {
  ContactRequestsRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "user_ref" field.
  DocumentReference? _userRef;
  DocumentReference? get userRef => _userRef;
  bool hasUserRef() => _userRef != null;

  // "realtor_ref" field.
  DocumentReference? _realtorRef;
  DocumentReference? get realtorRef => _realtorRef;
  bool hasRealtorRef() => _realtorRef != null;

  // "name" field.
  String? _name;
  String get name => _name ?? '';
  bool hasName() => _name != null;

  // "email" field.
  String? _email;
  String get email => _email ?? '';
  bool hasEmail() => _email != null;

  // "phone" field.
  String? _phone;
  String get phone => _phone ?? '';
  bool hasPhone() => _phone != null;

  // "message" field.
  String? _message;
  String get message => _message ?? '';
  bool hasMessage() => _message != null;

  // "created_at" field.
  DateTime? _createdAt;
  DateTime? get createdAt => _createdAt;
  bool hasCreatedAt() => _createdAt != null;

  void _initializeFields() {
    _userRef = snapshotData['user_ref'] as DocumentReference?;
    _realtorRef = snapshotData['realtor_ref'] as DocumentReference?;
    _name = snapshotData['name'] as String?;
    _email = snapshotData['email'] as String?;
    _phone = snapshotData['phone'] as String?;
    _message = snapshotData['message'] as String?;
    _createdAt = snapshotData['created_at'] as DateTime?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('contactRequests');

  static Stream<ContactRequestsRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => ContactRequestsRecord.fromSnapshot(s));

  static Future<ContactRequestsRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => ContactRequestsRecord.fromSnapshot(s));

  static ContactRequestsRecord fromSnapshot(DocumentSnapshot snapshot) =>
      ContactRequestsRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static ContactRequestsRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      ContactRequestsRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'ContactRequestsRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is ContactRequestsRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createContactRequestsRecordData({
  DocumentReference? userRef,
  DocumentReference? realtorRef,
  String? name,
  String? email,
  String? phone,
  String? message,
  DateTime? createdAt,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'user_ref': userRef,
      'realtor_ref': realtorRef,
      'name': name,
      'email': email,
      'phone': phone,
      'message': message,
      'created_at': createdAt,
    }.withoutNulls,
  );

  return firestoreData;
}

class ContactRequestsRecordDocumentEquality
    implements Equality<ContactRequestsRecord> {
  const ContactRequestsRecordDocumentEquality();

  @override
  bool equals(ContactRequestsRecord? e1, ContactRequestsRecord? e2) {
    return e1?.userRef == e2?.userRef &&
        e1?.realtorRef == e2?.realtorRef &&
        e1?.name == e2?.name &&
        e1?.email == e2?.email &&
        e1?.phone == e2?.phone &&
        e1?.message == e2?.message &&
        e1?.createdAt == e2?.createdAt;
  }

  @override
  int hash(ContactRequestsRecord? e) => const ListEquality().hash([
        e?.userRef,
        e?.realtorRef,
        e?.name,
        e?.email,
        e?.phone,
        e?.message,
        e?.createdAt
      ]);

  @override
  bool isValidKey(Object? o) => o is ContactRequestsRecord;
}
