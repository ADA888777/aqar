import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

/// إشعار — يُنشئه الخادم (Cloud Function) فقط عند حدث حقيقي.
/// المعرّف حتمي (type + target + user) فلا يتكرر أبداً.
class NotificationsRecord extends FirestoreRecord {
  NotificationsRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  DocumentReference? _userRef;
  DocumentReference? get userRef => _userRef;
  bool hasUserRef() => _userRef != null;

  String? _type;
  String get type => _type ?? '';
  bool hasType() => _type != null;

  String? _title;
  String get title => _title ?? '';
  bool hasTitle() => _title != null;

  String? _body;
  String get body => _body ?? '';
  bool hasBody() => _body != null;

  DocumentReference? _targetRef;
  DocumentReference? get targetRef => _targetRef;
  bool hasTargetRef() => _targetRef != null;

  String? _targetType;
  String get targetType => _targetType ?? '';
  bool hasTargetType() => _targetType != null;

  DateTime? _createdAt;
  DateTime? get createdAt => _createdAt;
  bool hasCreatedAt() => _createdAt != null;

  bool? _isRead;
  bool get isRead => _isRead ?? false;
  bool hasIsRead() => _isRead != null;

  void _initializeFields() {
    _userRef = snapshotData['user_ref'] as DocumentReference?;
    _type = snapshotData['type'] as String?;
    _title = snapshotData['title'] as String?;
    _body = snapshotData['body'] as String?;
    _targetRef = snapshotData['target_ref'] as DocumentReference?;
    _targetType = snapshotData['target_type'] as String?;
    _createdAt = snapshotData['created_at'] as DateTime?;
    _isRead = snapshotData['is_read'] as bool?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('notifications');

  static Stream<NotificationsRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => NotificationsRecord.fromSnapshot(s));

  static Future<NotificationsRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => NotificationsRecord.fromSnapshot(s));

  static NotificationsRecord fromSnapshot(DocumentSnapshot snapshot) =>
      NotificationsRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static NotificationsRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      NotificationsRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'NotificationsRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is NotificationsRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

class NotificationsRecordDocumentEquality
    implements Equality<NotificationsRecord> {
  const NotificationsRecordDocumentEquality();

  @override
  bool equals(NotificationsRecord? e1, NotificationsRecord? e2) {
    return e1?.userRef == e2?.userRef &&
        e1?.type == e2?.type &&
        e1?.title == e2?.title &&
        e1?.body == e2?.body &&
        e1?.targetRef == e2?.targetRef &&
        e1?.targetType == e2?.targetType &&
        e1?.createdAt == e2?.createdAt &&
        e1?.isRead == e2?.isRead;
  }

  @override
  int hash(NotificationsRecord? e) => const ListEquality().hash([
        e?.userRef, e?.type, e?.title, e?.body,
        e?.targetRef, e?.targetType, e?.createdAt, e?.isRead
      ]);

  @override
  bool isValidKey(Object? o) => o is NotificationsRecord;
}
