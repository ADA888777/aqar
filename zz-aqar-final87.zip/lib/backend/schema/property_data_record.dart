import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class PropertyDataRecord extends FirestoreRecord {
  PropertyDataRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "title" field.
  String? _title;
  String get title => _title ?? '';
  bool hasTitle() => _title != null;

  // "price" field.
  double? _price;
  double get price => _price ?? 0.0;
  bool hasPrice() => _price != null;

  // "ListingTypy" field.
  String? _listingTypy;
  String get listingTypy => _listingTypy ?? '';
  bool hasListingTypy() => _listingTypy != null;

  // "category" field.
  String? _category;
  String get category => _category ?? '';
  bool hasCategory() => _category != null;

  // "area" field.
  String? _area;
  String get area => _area ?? '';
  bool hasArea() => _area != null;

  // "block" field.
  String? _block;
  String get block => _block ?? '';
  bool hasBlock() => _block != null;

  // "street" field.
  String? _street;
  String get street => _street ?? '';
  bool hasStreet() => _street != null;

  // "propertyNumber" field.
  String? _propertyNumber;
  String get propertyNumber => _propertyNumber ?? '';
  bool hasPropertyNumber() => _propertyNumber != null;

  // "images" field.
  List<String>? _images;
  List<String> get images => _images ?? const [];
  bool hasImages() => _images != null;

  // "rooms" field.
  int? _rooms;
  int get rooms => _rooms ?? 0;
  bool hasRooms() => _rooms != null;

  // "bathrooms" field.
  int? _bathrooms;
  int get bathrooms => _bathrooms ?? 0;
  bool hasBathrooms() => _bathrooms != null;

  // "isApproved" field.
  bool? _isApproved;
  bool get isApproved => _isApproved ?? false;
  bool hasIsApproved() => _isApproved != null;

  // "ownerRef" field.
  DocumentReference? _ownerRef;
  DocumentReference? get ownerRef => _ownerRef;
  bool hasOwnerRef() => _ownerRef != null;

  // "propertyImages" field.
  List<String>? _propertyImages;
  List<String> get propertyImages => _propertyImages ?? const [];
  bool hasPropertyImages() => _propertyImages != null;

  void _initializeFields() {
    _title = snapshotData['title'] as String?;
    _price = castToType<double>(snapshotData['price']);
    _listingTypy = snapshotData['ListingTypy'] as String?;
    _category = snapshotData['category'] as String?;
    _area = snapshotData['area'] as String?;
    _block = snapshotData['block'] as String?;
    _street = snapshotData['street'] as String?;
    _propertyNumber = snapshotData['propertyNumber'] as String?;
    _images = getDataList(snapshotData['images']);
    _rooms = castToType<int>(snapshotData['rooms']);
    _bathrooms = castToType<int>(snapshotData['bathrooms']);
    _isApproved = snapshotData['isApproved'] as bool?;
    _ownerRef = snapshotData['ownerRef'] as DocumentReference?;
    _propertyImages = getDataList(snapshotData['propertyImages']);
    _description = snapshotData['description'] as String?;
    _deposit = castToType<double>(snapshotData['deposit']);
    _createdAt = snapshotData['created_at'] as DateTime?;
    _halls = castToType<int>(snapshotData['halls']);
    _size = snapshotData['size'] as String?;
    _masterRooms = castToType<int>(snapshotData['master_rooms']);
    _kitchens = castToType<int>(snapshotData['kitchens']);
    _diwaniyas = castToType<int>(snapshotData['diwaniyas']);
    _maidRoom = snapshotData['maid_room'] as bool?;
    _laundryRoom = snapshotData['laundry_room'] as bool?;
    _governorate = snapshotData['governorate'] as String?;
    _contactPhone = snapshotData['contact_phone'] as String?;
    _location = snapshotData['location'] as LatLng?;
    _whatsappPhone = snapshotData['whatsapp_phone'] as String?;
    _features = getDataList(snapshotData['features']);
    _viewedBy = getDataList(snapshotData['viewed_by']);
    _units = castToType<int>(snapshotData['units']);
    _floors = castToType<int>(snapshotData['floors']);
    _frontage = snapshotData['frontage'] as String?;
    _publishedAt = snapshotData['published_at'] as DateTime?;
    _expiresAt = snapshotData['expires_at'] as DateTime?;
    _isArchived = snapshotData['is_archived'] as bool?;
  }

  // "published_at" field — تاريخ آخر نشر/إعادة نشر.
  DateTime? _publishedAt;
  DateTime? get publishedAt => _publishedAt ?? _createdAt;
  bool hasPublishedAt() => _publishedAt != null;

  // "expires_at" field — تاريخ انتهاء الإعلان (30 يوماً من النشر).
  DateTime? _expiresAt;
  DateTime? get expiresAt => _expiresAt;
  bool hasExpiresAt() => _expiresAt != null;

  // "is_archived" field — أرشفة يدوية من المالك (حذف ناعم).
  bool? _isArchived;
  bool get isArchived => _isArchived ?? false;
  bool hasIsArchived() => _isArchived != null;

  /// هل انتهت مدة الإعلان؟ (الإعلانات القديمة بلا expires_at تُعتبر سارية)
  bool get isExpired =>
      _expiresAt != null && _expiresAt!.isBefore(DateTime.now());

  /// هل الإعلان ظاهر للعامة؟
  bool get isLive => isApproved && !isArchived && !isExpired;

  /// الأيام المتبقية قبل الانتهاء (سالبة إن انتهى)
  int get daysLeft => _expiresAt == null
      ? 30
      : _expiresAt!.difference(DateTime.now()).inDays;

  // "units" field — عدد الوحدات (أبراج/عمائر/شاليهات).
  int? _units;
  int get units => _units ?? 0;
  bool hasUnits() => _units != null;

  // "floors" field — عدد الأدوار (عمائر/محلات ومكاتب).
  int? _floors;
  int get floors => _floors ?? 0;
  bool hasFloors() => _floors != null;

  // "frontage" field — عرض الواجهة بالمتر (محلات ومكاتب).
  String? _frontage;
  String get frontage => _frontage ?? '';
  bool hasFrontage() => _frontage != null;

  // "viewed_by" field — قائمة من شاهد الإعلان (مرجع لكل مستخدم مرة واحدة).
  // العدّاد = طول القائمة، فلا تتضخم بإعادة بناء الواجهة.
  List<DocumentReference>? _viewedBy;
  List<DocumentReference> get viewedBy => _viewedBy ?? const [];
  int get viewsCount => viewedBy.length;
  bool hasViewedBy() => _viewedBy != null;

  // "features" field — مميزات العقار التي اختارها المعلن (اختيارية).
  List<String>? _features;
  List<String> get features => _features ?? const [];
  bool hasFeatures() => _features != null;

  // "whatsapp_phone" field — رقم واتساب صاحب الإعلان للتواصل المباشر.
  String? _whatsappPhone;
  String get whatsappPhone => _whatsappPhone ?? '';
  bool hasWhatsappPhone() => _whatsappPhone != null;

  // "location" field — إحداثيات العقار (خط العرض/الطول).
  LatLng? _location;
  LatLng? get location => _location;
  bool hasLocation() => _location != null;

  // "contact_phone" field — رقم التواصل مع صاحب الإعلان.
  String? _contactPhone;
  String get contactPhone => _contactPhone ?? '';
  bool hasContactPhone() => _contactPhone != null;

  // "master_rooms" field.
  int? _masterRooms;
  int get masterRooms => _masterRooms ?? 0;
  bool hasMasterRooms() => _masterRooms != null;

  // "kitchens" field.
  int? _kitchens;
  int get kitchens => _kitchens ?? 0;
  bool hasKitchens() => _kitchens != null;

  // "diwaniyas" field.
  int? _diwaniyas;
  int get diwaniyas => _diwaniyas ?? 0;
  bool hasDiwaniyas() => _diwaniyas != null;

  // "maid_room" field.
  bool? _maidRoom;
  bool get maidRoom => _maidRoom ?? false;
  bool hasMaidRoom() => _maidRoom != null;

  // "laundry_room" field.
  bool? _laundryRoom;
  bool get laundryRoom => _laundryRoom ?? false;
  bool hasLaundryRoom() => _laundryRoom != null;

  // "governorate" field.
  String? _governorate;
  String get governorate => _governorate ?? '';
  bool hasGovernorate() => _governorate != null;

  // "halls" field.
  int? _halls;
  int get halls => _halls ?? 0;
  bool hasHalls() => _halls != null;

  // "size" field.
  String? _size;
  String get size => _size ?? '';
  bool hasSize() => _size != null;

  // "description" field.
  String? _description;
  String get description => _description ?? '';
  bool hasDescription() => _description != null;

  // "deposit" field.
  double? _deposit;
  double get deposit => _deposit ?? 0.0;
  bool hasDeposit() => _deposit != null;

  // "created_at" field.
  DateTime? _createdAt;
  DateTime? get createdAt => _createdAt;
  bool hasCreatedAt() => _createdAt != null;

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('PropertyData');

  static Stream<PropertyDataRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => PropertyDataRecord.fromSnapshot(s));

  static Future<PropertyDataRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => PropertyDataRecord.fromSnapshot(s));

  static PropertyDataRecord fromSnapshot(DocumentSnapshot snapshot) =>
      PropertyDataRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static PropertyDataRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      PropertyDataRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'PropertyDataRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is PropertyDataRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createPropertyDataRecordData({
  String? title,
  double? price,
  String? listingTypy,
  String? category,
  String? area,
  String? block,
  String? street,
  String? propertyNumber,
  int? rooms,
  int? bathrooms,
  bool? isApproved,
  DocumentReference? ownerRef,
  String? description,
  double? deposit,
  DateTime? createdAt,
  int? halls,
  String? size,
  int? masterRooms,
  int? kitchens,
  int? diwaniyas,
  bool? maidRoom,
  bool? laundryRoom,
  String? governorate,
  String? contactPhone,
  LatLng? location,
  String? whatsappPhone,
  int? units,
  int? floors,
  String? frontage,
  DateTime? publishedAt,
  DateTime? expiresAt,
  bool? isArchived,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'title': title,
      'price': price,
      'ListingTypy': listingTypy,
      'category': category,
      'area': area,
      'block': block,
      'street': street,
      'propertyNumber': propertyNumber,
      'rooms': rooms,
      'bathrooms': bathrooms,
      'isApproved': isApproved,
      'ownerRef': ownerRef,
      'description': description,
      'deposit': deposit,
      'created_at': createdAt,
      'halls': halls,
      'size': size,
      'master_rooms': masterRooms,
      'kitchens': kitchens,
      'diwaniyas': diwaniyas,
      'maid_room': maidRoom,
      'laundry_room': laundryRoom,
      'governorate': governorate,
      'contact_phone': contactPhone,
      'location': location,
      'whatsapp_phone': whatsappPhone,
      'units': units,
      'floors': floors,
      'frontage': frontage,
      'published_at': publishedAt,
      'expires_at': expiresAt,
      'is_archived': isArchived,
    }.withoutNulls,
  );

  return firestoreData;
}

class PropertyDataRecordDocumentEquality
    implements Equality<PropertyDataRecord> {
  const PropertyDataRecordDocumentEquality();

  @override
  bool equals(PropertyDataRecord? e1, PropertyDataRecord? e2) {
    const listEquality = ListEquality();
    return e1?.title == e2?.title &&
        e1?.price == e2?.price &&
        e1?.listingTypy == e2?.listingTypy &&
        e1?.category == e2?.category &&
        e1?.area == e2?.area &&
        e1?.block == e2?.block &&
        e1?.street == e2?.street &&
        e1?.propertyNumber == e2?.propertyNumber &&
        listEquality.equals(e1?.images, e2?.images) &&
        e1?.rooms == e2?.rooms &&
        e1?.bathrooms == e2?.bathrooms &&
        e1?.isApproved == e2?.isApproved &&
        e1?.ownerRef == e2?.ownerRef &&
        listEquality.equals(e1?.propertyImages, e2?.propertyImages);
  }

  @override
  int hash(PropertyDataRecord? e) => const ListEquality().hash([
        e?.title,
        e?.price,
        e?.listingTypy,
        e?.category,
        e?.area,
        e?.block,
        e?.street,
        e?.propertyNumber,
        e?.images,
        e?.rooms,
        e?.bathrooms,
        e?.isApproved,
        e?.ownerRef,
        e?.propertyImages
      ]);

  @override
  bool isValidKey(Object? o) => o is PropertyDataRecord;
}
