import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class RealtorsRecord extends FirestoreRecord {
  RealtorsRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "company" field.
  String? _company;
  String get company => _company ?? '';
  bool hasCompany() => _company != null;

  // "image" field.
  String? _image;
  String get image => _image ?? '';
  bool hasImage() => _image != null;

  // "name" field.
  String? _name;
  String get name => _name ?? '';
  bool hasName() => _name != null;

  // "rating" field.
  String? _rating;
  String get rating => _rating ?? '';
  bool hasRating() => _rating != null;

  // "reviews" field.
  int? _reviews;
  int get reviews => _reviews ?? 0;
  bool hasReviews() => _reviews != null;

  void _initializeFields() {
    _company = snapshotData['company'] as String?;
    _image = snapshotData['image'] as String?;
    _name = snapshotData['name'] as String?;
    _rating = snapshotData['rating'] as String?;
    _reviews = castToType<int>(snapshotData['reviews']);
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('Realtors');

  static Stream<RealtorsRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => RealtorsRecord.fromSnapshot(s));

  static Future<RealtorsRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => RealtorsRecord.fromSnapshot(s));

  static RealtorsRecord fromSnapshot(DocumentSnapshot snapshot) =>
      RealtorsRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static RealtorsRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      RealtorsRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'RealtorsRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is RealtorsRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createRealtorsRecordData({
  String? company,
  String? image,
  String? name,
  String? rating,
  int? reviews,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'company': company,
      'image': image,
      'name': name,
      'rating': rating,
      'reviews': reviews,
    }.withoutNulls,
  );

  return firestoreData;
}

class RealtorsRecordDocumentEquality implements Equality<RealtorsRecord> {
  const RealtorsRecordDocumentEquality();

  @override
  bool equals(RealtorsRecord? e1, RealtorsRecord? e2) {
    return e1?.company == e2?.company &&
        e1?.image == e2?.image &&
        e1?.name == e2?.name &&
        e1?.rating == e2?.rating &&
        e1?.reviews == e2?.reviews;
  }

  @override
  int hash(RealtorsRecord? e) => const ListEquality()
      .hash([e?.company, e?.image, e?.name, e?.rating, e?.reviews]);

  @override
  bool isValidKey(Object? o) => o is RealtorsRecord;
}
