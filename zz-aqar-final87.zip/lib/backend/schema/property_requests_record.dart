import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class PropertyRequestsRecord extends FirestoreRecord {
  PropertyRequestsRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "request_type" field.
  String? _requestType;
  String get requestType => _requestType ?? '';
  bool hasRequestType() => _requestType != null;

  // "property_type" field.
  String? _propertyType;
  String get propertyType => _propertyType ?? '';
  bool hasPropertyType() => _propertyType != null;

  // "governorate" field.
  String? _governorate;
  String get governorate => _governorate ?? '';
  bool hasGovernorate() => _governorate != null;

  // "area" field.
  String? _area;
  String get area => _area ?? '';
  bool hasArea() => _area != null;

  // "budget" field.
  String? _budget;
  String get budget => _budget ?? '';
  bool hasBudget() => _budget != null;

  // "details" field.
  String? _details;
  String get details => _details ?? '';
  bool hasDetails() => _details != null;

  // "phone" field.
  String? _phone;
  String get phone => _phone ?? '';
  bool hasPhone() => _phone != null;

  // "user_ref" field.
  DocumentReference? _userRef;
  DocumentReference? get userRef => _userRef;
  bool hasUserRef() => _userRef != null;

  // "created_at" field.
  DateTime? _createdAt;
  DateTime? get createdAt => _createdAt;
  bool hasCreatedAt() => _createdAt != null;

  void _initializeFields() {
    _requestType = snapshotData['request_type'] as String?;
    _propertyType = snapshotData['property_type'] as String?;
    _governorate = snapshotData['governorate'] as String?;
    _area = snapshotData['area'] as String?;
    _budget = snapshotData['budget'] as String?;
    _details = snapshotData['details'] as String?;
    _phone = snapshotData['phone'] as String?;
    _userRef = snapshotData['user_ref'] as DocumentReference?;
    _createdAt = snapshotData['created_at'] as DateTime?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('propertyRequests');

  static Stream<PropertyRequestsRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => PropertyRequestsRecord.fromSnapshot(s));

  static Future<PropertyRequestsRecord> getDocumentOnce(
          DocumentReference ref) =>
      ref.get().then((s) => PropertyRequestsRecord.fromSnapshot(s));

  static PropertyRequestsRecord fromSnapshot(DocumentSnapshot snapshot) =>
      PropertyRequestsRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static PropertyRequestsRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      PropertyRequestsRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'PropertyRequestsRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is PropertyRequestsRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createPropertyRequestsRecordData({
  String? requestType,
  String? propertyType,
  String? governorate,
  String? area,
  String? budget,
  String? details,
  String? phone,
  DocumentReference? userRef,
  DateTime? createdAt,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'request_type': requestType,
      'property_type': propertyType,
      'governorate': governorate,
      'area': area,
      'budget': budget,
      'details': details,
      'phone': phone,
      'user_ref': userRef,
      'created_at': createdAt,
    }.withoutNulls,
  );

  return firestoreData;
}

class PropertyRequestsRecordDocumentEquality
    implements Equality<PropertyRequestsRecord> {
  const PropertyRequestsRecordDocumentEquality();

  @override
  bool equals(PropertyRequestsRecord? e1, PropertyRequestsRecord? e2) {
    return e1?.requestType == e2?.requestType &&
        e1?.propertyType == e2?.propertyType &&
        e1?.governorate == e2?.governorate &&
        e1?.area == e2?.area &&
        e1?.budget == e2?.budget &&
        e1?.details == e2?.details &&
        e1?.phone == e2?.phone &&
        e1?.userRef == e2?.userRef &&
        e1?.createdAt == e2?.createdAt;
  }

  @override
  int hash(PropertyRequestsRecord? e) => const ListEquality().hash([
        e?.requestType,
        e?.propertyType,
        e?.governorate,
        e?.area,
        e?.budget,
        e?.details,
        e?.phone,
        e?.userRef,
        e?.createdAt
      ]);

  @override
  bool isValidKey(Object? o) => o is PropertyRequestsRecord;
}
