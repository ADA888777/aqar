import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class MessagesRecord extends FirestoreRecord {
  MessagesRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "chat_ref" field.
  DocumentReference? _chatRef;
  DocumentReference? get chatRef => _chatRef;
  bool hasChatRef() => _chatRef != null;

  // "sender_ref" field.
  DocumentReference? _senderRef;
  DocumentReference? get senderRef => _senderRef;
  bool hasSenderRef() => _senderRef != null;

  // "text" field.
  String? _text;
  String get text => _text ?? '';
  bool hasText() => _text != null;

  // "created_at" field.
  DateTime? _createdAt;
  DateTime? get createdAt => _createdAt;
  bool hasCreatedAt() => _createdAt != null;

  // "saved_by" — من حفظ هذه الرسالة (الرسائل المحفوظة)
  List<DocumentReference>? _savedBy;
  List<DocumentReference> get savedBy => _savedBy ?? const [];
  bool hasSavedBy() => _savedBy != null;

  void _initializeFields() {
    _savedBy = getDataList(snapshotData['saved_by']);
    _chatRef = snapshotData['chat_ref'] as DocumentReference?;
    _senderRef = snapshotData['sender_ref'] as DocumentReference?;
    _text = snapshotData['text'] as String?;
    _createdAt = snapshotData['created_at'] as DateTime?;
    _participants = getDataList(snapshotData['participants']);
    _receiverRef = snapshotData['receiver_ref'] as DocumentReference?;
    _isRead = snapshotData['is_read'] as bool?;
    _deletedFor = getDataList(snapshotData['deleted_for']);
  }

  // "participants" field — نسخة من أطراف المحادثة داخل الرسالة.
  // ضرورية لقواعد الأمان: تسمح بالتحقق بلا get() في الاستعلامات.
  List<DocumentReference>? _participants;
  List<DocumentReference> get participants => _participants ?? const [];
  bool hasParticipants() => _participants != null;

  // "receiver_ref" field — المستقبل (للإشعارات وحالة القراءة).
  DocumentReference? _receiverRef;
  DocumentReference? get receiverRef => _receiverRef;
  bool hasReceiverRef() => _receiverRef != null;

  // "is_read" field
  bool? _isRead;
  bool get isRead => _isRead ?? false;
  bool hasIsRead() => _isRead != null;

  // "deleted_for" field — حذف ناعم لكل مستخدم على حدة.
  List<DocumentReference>? _deletedFor;
  List<DocumentReference> get deletedFor => _deletedFor ?? const [];
  bool hasDeletedFor() => _deletedFor != null;

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('messages');

  static Stream<MessagesRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => MessagesRecord.fromSnapshot(s));

  static Future<MessagesRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => MessagesRecord.fromSnapshot(s));

  static MessagesRecord fromSnapshot(DocumentSnapshot snapshot) =>
      MessagesRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static MessagesRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      MessagesRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'MessagesRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is MessagesRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createMessagesRecordData({
  DocumentReference? chatRef,
  DocumentReference? senderRef,
  String? text,
  DateTime? createdAt,
  DocumentReference? receiverRef,
  bool? isRead,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'chat_ref': chatRef,
      'sender_ref': senderRef,
      'text': text,
      'created_at': createdAt,
      'receiver_ref': receiverRef,
      'is_read': isRead,
    }.withoutNulls,
  );

  return firestoreData;
}

class MessagesRecordDocumentEquality implements Equality<MessagesRecord> {
  const MessagesRecordDocumentEquality();

  @override
  bool equals(MessagesRecord? e1, MessagesRecord? e2) {
    return e1?.chatRef == e2?.chatRef &&
        e1?.senderRef == e2?.senderRef &&
        e1?.text == e2?.text &&
        e1?.createdAt == e2?.createdAt;
  }

  @override
  int hash(MessagesRecord? e) => const ListEquality()
      .hash([e?.chatRef, e?.senderRef, e?.text, e?.createdAt]);

  @override
  bool isValidKey(Object? o) => o is MessagesRecord;
}
