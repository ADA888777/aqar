// ignore_for_file: unnecessary_getters_setters

import 'package:cloud_firestore/cloud_firestore.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class PropertyStruct extends FFFirebaseStruct {
  PropertyStruct({
    String? title,
    List<String>? imageList,
    String? location,
    double? price,
    String? description,
    int? bds,
    int? ba,
    double? sqft,
    int? hours,
    String? pricee,
    FirestoreUtilData firestoreUtilData = const FirestoreUtilData(),
  })  : _title = title,
        _imageList = imageList,
        _location = location,
        _price = price,
        _description = description,
        _bds = bds,
        _ba = ba,
        _sqft = sqft,
        _hours = hours,
        _pricee = pricee,
        super(firestoreUtilData);

  // "Title" field.
  String? _title;
  String get title => _title ?? '';
  set title(String? val) => _title = val;

  bool hasTitle() => _title != null;

  // "imageList" field.
  List<String>? _imageList;
  List<String> get imageList => _imageList ?? const [];
  set imageList(List<String>? val) => _imageList = val;

  void updateImageList(Function(List<String>) updateFn) {
    updateFn(_imageList ??= []);
  }

  bool hasImageList() => _imageList != null;

  // "location" field.
  String? _location;
  String get location => _location ?? '';
  set location(String? val) => _location = val;

  bool hasLocation() => _location != null;

  // "price" field.
  double? _price;
  double get price => _price ?? 0.0;
  set price(double? val) => _price = val;

  void incrementPrice(double amount) => price = price + amount;

  bool hasPrice() => _price != null;

  // "description" field.
  String? _description;
  String get description => _description ?? '';
  set description(String? val) => _description = val;

  bool hasDescription() => _description != null;

  // "bds" field.
  int? _bds;
  int get bds => _bds ?? 0;
  set bds(int? val) => _bds = val;

  void incrementBds(int amount) => bds = bds + amount;

  bool hasBds() => _bds != null;

  // "ba" field.
  int? _ba;
  int get ba => _ba ?? 0;
  set ba(int? val) => _ba = val;

  void incrementBa(int amount) => ba = ba + amount;

  bool hasBa() => _ba != null;

  // "sqft" field.
  double? _sqft;
  double get sqft => _sqft ?? 0.0;
  set sqft(double? val) => _sqft = val;

  void incrementSqft(double amount) => sqft = sqft + amount;

  bool hasSqft() => _sqft != null;

  // "hours" field.
  int? _hours;
  int get hours => _hours ?? 0;
  set hours(int? val) => _hours = val;

  void incrementHours(int amount) => hours = hours + amount;

  bool hasHours() => _hours != null;

  // "pricee" field.
  String? _pricee;
  String get pricee => _pricee ?? '';
  set pricee(String? val) => _pricee = val;

  bool hasPricee() => _pricee != null;

  static PropertyStruct fromMap(Map<String, dynamic> data) => PropertyStruct(
        title: data['Title'] as String?,
        imageList: getDataList(data['imageList']),
        location: data['location'] as String?,
        price: castToType<double>(data['price']),
        description: data['description'] as String?,
        bds: castToType<int>(data['bds']),
        ba: castToType<int>(data['ba']),
        sqft: castToType<double>(data['sqft']),
        hours: castToType<int>(data['hours']),
        pricee: data['pricee'] as String?,
      );

  static PropertyStruct? maybeFromMap(dynamic data) =>
      data is Map ? PropertyStruct.fromMap(data.cast<String, dynamic>()) : null;

  Map<String, dynamic> toMap() => {
        'Title': _title,
        'imageList': _imageList,
        'location': _location,
        'price': _price,
        'description': _description,
        'bds': _bds,
        'ba': _ba,
        'sqft': _sqft,
        'hours': _hours,
        'pricee': _pricee,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'Title': serializeParam(
          _title,
          ParamType.String,
        ),
        'imageList': serializeParam(
          _imageList,
          ParamType.String,
          isList: true,
        ),
        'location': serializeParam(
          _location,
          ParamType.String,
        ),
        'price': serializeParam(
          _price,
          ParamType.double,
        ),
        'description': serializeParam(
          _description,
          ParamType.String,
        ),
        'bds': serializeParam(
          _bds,
          ParamType.int,
        ),
        'ba': serializeParam(
          _ba,
          ParamType.int,
        ),
        'sqft': serializeParam(
          _sqft,
          ParamType.double,
        ),
        'hours': serializeParam(
          _hours,
          ParamType.int,
        ),
        'pricee': serializeParam(
          _pricee,
          ParamType.String,
        ),
      }.withoutNulls;

  static PropertyStruct fromSerializableMap(Map<String, dynamic> data) =>
      PropertyStruct(
        title: deserializeParam(
          data['Title'],
          ParamType.String,
          false,
        ),
        imageList: deserializeParam<String>(
          data['imageList'],
          ParamType.String,
          true,
        ),
        location: deserializeParam(
          data['location'],
          ParamType.String,
          false,
        ),
        price: deserializeParam(
          data['price'],
          ParamType.double,
          false,
        ),
        description: deserializeParam(
          data['description'],
          ParamType.String,
          false,
        ),
        bds: deserializeParam(
          data['bds'],
          ParamType.int,
          false,
        ),
        ba: deserializeParam(
          data['ba'],
          ParamType.int,
          false,
        ),
        sqft: deserializeParam(
          data['sqft'],
          ParamType.double,
          false,
        ),
        hours: deserializeParam(
          data['hours'],
          ParamType.int,
          false,
        ),
        pricee: deserializeParam(
          data['pricee'],
          ParamType.String,
          false,
        ),
      );

  @override
  String toString() => 'PropertyStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    const listEquality = ListEquality();
    return other is PropertyStruct &&
        title == other.title &&
        listEquality.equals(imageList, other.imageList) &&
        location == other.location &&
        price == other.price &&
        description == other.description &&
        bds == other.bds &&
        ba == other.ba &&
        sqft == other.sqft &&
        hours == other.hours &&
        pricee == other.pricee;
  }

  @override
  int get hashCode => const ListEquality().hash([
        title,
        imageList,
        location,
        price,
        description,
        bds,
        ba,
        sqft,
        hours,
        pricee
      ]);
}

PropertyStruct createPropertyStruct({
  String? title,
  String? location,
  double? price,
  String? description,
  int? bds,
  int? ba,
  double? sqft,
  int? hours,
  String? pricee,
  Map<String, dynamic> fieldValues = const {},
  bool clearUnsetFields = true,
  bool create = false,
  bool delete = false,
}) =>
    PropertyStruct(
      title: title,
      location: location,
      price: price,
      description: description,
      bds: bds,
      ba: ba,
      sqft: sqft,
      hours: hours,
      pricee: pricee,
      firestoreUtilData: FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
        delete: delete,
        fieldValues: fieldValues,
      ),
    );

PropertyStruct? updatePropertyStruct(
  PropertyStruct? property, {
  bool clearUnsetFields = true,
  bool create = false,
}) =>
    property
      ?..firestoreUtilData = FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
      );

void addPropertyStructData(
  Map<String, dynamic> firestoreData,
  PropertyStruct? property,
  String fieldName, [
  bool forFieldValue = false,
]) {
  firestoreData.remove(fieldName);
  if (property == null) {
    return;
  }
  if (property.firestoreUtilData.delete) {
    firestoreData[fieldName] = FieldValue.delete();
    return;
  }
  final clearFields =
      !forFieldValue && property.firestoreUtilData.clearUnsetFields;
  if (clearFields) {
    firestoreData[fieldName] = <String, dynamic>{};
  }
  final propertyData = getPropertyFirestoreData(property, forFieldValue);
  final nestedData = propertyData.map((k, v) => MapEntry('$fieldName.$k', v));

  final mergeFields = property.firestoreUtilData.create || clearFields;
  firestoreData
      .addAll(mergeFields ? mergeNestedFields(nestedData) : nestedData);
}

Map<String, dynamic> getPropertyFirestoreData(
  PropertyStruct? property, [
  bool forFieldValue = false,
]) {
  if (property == null) {
    return {};
  }
  final firestoreData = mapToFirestore(property.toMap());

  // Add any Firestore field values
  mapToFirestore(property.firestoreUtilData.fieldValues)
      .forEach((k, v) => firestoreData[k] = v);

  return forFieldValue ? mergeNestedFields(firestoreData) : firestoreData;
}

List<Map<String, dynamic>> getPropertyListFirestoreData(
  List<PropertyStruct>? propertys,
) =>
    propertys?.map((e) => getPropertyFirestoreData(e, true)).toList() ?? [];
