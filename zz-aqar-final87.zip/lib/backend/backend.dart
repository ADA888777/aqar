import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/foundation.dart' show debugPrint;
import 'package:firebase_auth/firebase_auth.dart';
import '../auth/firebase_auth/auth_util.dart';

import '../flutter_flow/flutter_flow_util.dart';
import 'schema/util/firestore_util.dart';

import 'schema/users_record.dart';
import 'schema/property_data_record.dart';
import 'schema/realtors_record.dart';
import 'schema/chats_record.dart';
import 'schema/messages_record.dart';
import 'schema/notifications_record.dart';
import 'schema/reviews_record.dart';
import 'schema/contact_requests_record.dart';
import 'schema/property_requests_record.dart';

export 'dart:async' show StreamSubscription;
export 'package:cloud_firestore/cloud_firestore.dart' hide Order;
export 'package:firebase_core/firebase_core.dart';
export 'schema/index.dart';
export 'schema/util/firestore_util.dart';
export 'schema/util/schema_util.dart';

export 'schema/users_record.dart';
export 'schema/property_data_record.dart';
export 'schema/realtors_record.dart';
export 'schema/chats_record.dart';
export 'schema/messages_record.dart';
export 'schema/notifications_record.dart';
export 'schema/reviews_record.dart';
export 'schema/contact_requests_record.dart';
export 'schema/property_requests_record.dart';

/// Functions to query UsersRecords (as a Stream and as a Future).
Future<int> queryUsersRecordCount({
  Query Function(Query)? queryBuilder,
  int limit = -1,
}) =>
    queryCollectionCount(
      UsersRecord.collection,
      queryBuilder: queryBuilder,
      limit: limit,
    );

Stream<List<UsersRecord>> queryUsersRecord({
  Query Function(Query)? queryBuilder,
  int limit = -1,
  bool singleRecord = false,
}) =>
    queryCollection(
      UsersRecord.collection,
      UsersRecord.fromSnapshot,
      queryBuilder: queryBuilder,
      limit: limit,
      singleRecord: singleRecord,
    );

Future<List<UsersRecord>> queryUsersRecordOnce({
  Query Function(Query)? queryBuilder,
  int limit = -1,
  bool singleRecord = false,
}) =>
    queryCollectionOnce(
      UsersRecord.collection,
      UsersRecord.fromSnapshot,
      queryBuilder: queryBuilder,
      limit: limit,
      singleRecord: singleRecord,
    );

/// Functions to query PropertyDataRecords (as a Stream and as a Future).
Future<int> queryPropertyDataRecordCount({
  Query Function(Query)? queryBuilder,
  int limit = -1,
}) =>
    queryCollectionCount(
      PropertyDataRecord.collection,
      queryBuilder: queryBuilder,
      limit: limit,
    );

Stream<List<PropertyDataRecord>> queryPropertyDataRecord({
  Query Function(Query)? queryBuilder,
  int limit = -1,
  bool singleRecord = false,
}) =>
    queryCollection(
      PropertyDataRecord.collection,
      PropertyDataRecord.fromSnapshot,
      queryBuilder: queryBuilder,
      limit: limit,
      singleRecord: singleRecord,
    );

Future<List<PropertyDataRecord>> queryPropertyDataRecordOnce({
  Query Function(Query)? queryBuilder,
  int limit = -1,
  bool singleRecord = false,
}) =>
    queryCollectionOnce(
      PropertyDataRecord.collection,
      PropertyDataRecord.fromSnapshot,
      queryBuilder: queryBuilder,
      limit: limit,
      singleRecord: singleRecord,
    );

/// Functions to query RealtorsRecords (as a Stream and as a Future).
Future<int> queryRealtorsRecordCount({
  Query Function(Query)? queryBuilder,
  int limit = -1,
}) =>
    queryCollectionCount(
      RealtorsRecord.collection,
      queryBuilder: queryBuilder,
      limit: limit,
    );

Stream<List<RealtorsRecord>> queryRealtorsRecord({
  Query Function(Query)? queryBuilder,
  int limit = -1,
  bool singleRecord = false,
}) =>
    queryCollection(
      RealtorsRecord.collection,
      RealtorsRecord.fromSnapshot,
      queryBuilder: queryBuilder,
      limit: limit,
      singleRecord: singleRecord,
    );

Future<List<RealtorsRecord>> queryRealtorsRecordOnce({
  Query Function(Query)? queryBuilder,
  int limit = -1,
  bool singleRecord = false,
}) =>
    queryCollectionOnce(
      RealtorsRecord.collection,
      RealtorsRecord.fromSnapshot,
      queryBuilder: queryBuilder,
      limit: limit,
      singleRecord: singleRecord,
    );

/// Functions to query ChatsRecords (as a Stream and as a Future).
Future<int> queryChatsRecordCount({
  Query Function(Query)? queryBuilder,
  int limit = -1,
}) =>
    queryCollectionCount(
      ChatsRecord.collection,
      queryBuilder: queryBuilder,
      limit: limit,
    );

Stream<List<ChatsRecord>> queryChatsRecord({
  Query Function(Query)? queryBuilder,
  int limit = -1,
  bool singleRecord = false,
}) =>
    queryCollection(
      ChatsRecord.collection,
      ChatsRecord.fromSnapshot,
      queryBuilder: queryBuilder,
      limit: limit,
      singleRecord: singleRecord,
    );

Future<List<ChatsRecord>> queryChatsRecordOnce({
  Query Function(Query)? queryBuilder,
  int limit = -1,
  bool singleRecord = false,
}) =>
    queryCollectionOnce(
      ChatsRecord.collection,
      ChatsRecord.fromSnapshot,
      queryBuilder: queryBuilder,
      limit: limit,
      singleRecord: singleRecord,
    );

/// Functions to query MessagesRecords (as a Stream and as a Future).
Future<int> queryMessagesRecordCount({
  Query Function(Query)? queryBuilder,
  int limit = -1,
}) =>
    queryCollectionCount(
      MessagesRecord.collection,
      queryBuilder: queryBuilder,
      limit: limit,
    );

Stream<List<MessagesRecord>> queryMessagesRecord({
  Query Function(Query)? queryBuilder,
  int limit = -1,
  bool singleRecord = false,
}) =>
    queryCollection(
      MessagesRecord.collection,
      MessagesRecord.fromSnapshot,
      queryBuilder: queryBuilder,
      limit: limit,
      singleRecord: singleRecord,
    );

Future<List<MessagesRecord>> queryMessagesRecordOnce({
  Query Function(Query)? queryBuilder,
  int limit = -1,
  bool singleRecord = false,
}) =>
    queryCollectionOnce(
      MessagesRecord.collection,
      MessagesRecord.fromSnapshot,
      queryBuilder: queryBuilder,
      limit: limit,
      singleRecord: singleRecord,
    );

/// Functions to query ReviewsRecords (as a Stream and as a Future).
Future<int> queryReviewsRecordCount({
  Query Function(Query)? queryBuilder,
  int limit = -1,
}) =>
    queryCollectionCount(
      ReviewsRecord.collection,
      queryBuilder: queryBuilder,
      limit: limit,
    );

Stream<List<ReviewsRecord>> queryReviewsRecord({
  Query Function(Query)? queryBuilder,
  int limit = -1,
  bool singleRecord = false,
}) =>
    queryCollection(
      ReviewsRecord.collection,
      ReviewsRecord.fromSnapshot,
      queryBuilder: queryBuilder,
      limit: limit,
      singleRecord: singleRecord,
    );

Future<List<ReviewsRecord>> queryReviewsRecordOnce({
  Query Function(Query)? queryBuilder,
  int limit = -1,
  bool singleRecord = false,
}) =>
    queryCollectionOnce(
      ReviewsRecord.collection,
      ReviewsRecord.fromSnapshot,
      queryBuilder: queryBuilder,
      limit: limit,
      singleRecord: singleRecord,
    );

/// Functions to query PropertyRequestsRecords.
Stream<List<PropertyRequestsRecord>> queryPropertyRequestsRecord({
  Query Function(Query)? queryBuilder,
  int limit = -1,
  bool singleRecord = false,
}) =>
    queryCollection(
      PropertyRequestsRecord.collection,
      PropertyRequestsRecord.fromSnapshot,
      queryBuilder: queryBuilder,
      limit: limit,
      singleRecord: singleRecord,
    );

Future<List<PropertyRequestsRecord>> queryPropertyRequestsRecordOnce({
  Query Function(Query)? queryBuilder,
  int limit = -1,
  bool singleRecord = false,
}) =>
    queryCollectionOnce(
      PropertyRequestsRecord.collection,
      PropertyRequestsRecord.fromSnapshot,
      queryBuilder: queryBuilder,
      limit: limit,
      singleRecord: singleRecord,
    );

/// هل المستخدم الحالي مدير؟
/// ملاحظة أمنية: هذا للواجهة فقط (إظهار/إخفاء الأزرار).
/// الحماية الحقيقية في Firestore Rules عبر isAdmin() هناك —
/// فحتى لو تلاعب أحد بالتطبيق، الخادم يرفض العملية.
bool get currentUserIsAdmin =>
    currentUserDocument?.role.trim().toLowerCase() == 'admin';

/// حذف إعلان مخالف (للمدير فقط).
/// الخادم يتحقق من الصلاحية؛ الفشل يعني أن المستخدم ليس مديراً.
Future<void> adminDeleteProperty(PropertyDataRecord property) async {
  await property.reference.delete();
}

/// تعطيل إعلان مخالف بدل حذفه (أفضل للمراجعة والاسترجاع).
Future<void> adminDisableProperty(PropertyDataRecord property) async {
  await property.reference.update({
    'isApproved': false,
    'disabled_by_admin': true, // تميّز الإيقاف الإداري عن أرشفة المالك — للإشعار
    'is_archived': true,
  });
}

/// ═══ دورة حياة الإعلان ═══
/// مدة صلاحية الإعلان بالأيام (قابلة للتعديل من مكان واحد)
const int kListingDurationDays = 30;

/// مدة الاحتفاظ بالإعلانات المؤرشفة قبل الحذف اليدوي (للمراجعة)
const int kArchiveRetentionDays = 180;

/// إعادة نشر إعلان: يمدّد صلاحيته 30 يوماً ويعيده للقوائم.
Future<void> republishProperty(PropertyDataRecord property) async {
  final me = currentUserReference;
  if (me == null || property.ownerRef != me) {
    throw Exception('not-owner');
  }
  final now = DateTime.now();
  await property.reference.update({
    'published_at': now,
    // expires_at لا يُكتب من العميل — حقل خادمي، تحسبه Cloud Function
    // من published_at (وإلا استطاع المالك تمديد إعلانه إلى ما لا نهاية).
    'is_archived': false,
  });
}

/// أرشفة إعلان (حذف ناعم): يختفي من العامة ويبقى عند مالكه.
Future<void> archiveProperty(PropertyDataRecord property) async {
  final me = currentUserReference;
  if (me == null || property.ownerRef != me) {
    throw Exception('not-owner');
  }
  await property.reference.update({'is_archived': true});
}

/// حذف نهائي — يُستخدم فقط بطلب صريح من المالك بعد تأكيد.
Future<void> deletePropertyPermanently(PropertyDataRecord property) async {
  final me = currentUserReference;
  if (me == null || property.ownerRef != me) {
    throw Exception('not-owner');
  }
  await property.reference.delete();
}

/// جلب صفحة واحدة من الإعلانات — Pagination حقيقية بـ cursor.
///
/// يطلب من Firestore [pageSize] وثيقة فقط (لا يجلب المجموعة كاملة)،
/// ويبدأ بعد آخر وثيقة في الصفحة السابقة عبر startAfterDocument.
/// هذا يجعل التكلفة ثابتة مهما بلغ عدد الإعلانات (50 ألف أو أكثر).
Future<List<PropertyDataRecord>> fetchPropertiesPage({
  int pageSize = 15,
  DocumentSnapshot? startAfter,
  String? category,
  String? listingType,
  String? area, // مناطق الكويت — بدل المحافظة (قرار العميل)
  int? floors,
}) async {
  Query q = PropertyDataRecord.collection
      .where('isApproved', isEqualTo: true);

  // فلاتر المساواة تُنفَّذ على الخادم (لا محلياً) فتقل الوثائق المنقولة
  if (category != null && category.trim().isNotEmpty) {
    q = q.where('category', isEqualTo: category.trim());
  }
  if (listingType != null && listingType.trim().isNotEmpty) {
    q = q.where('ListingTypy', isEqualTo: listingType.trim());
  }
  if (area != null && area.trim().isNotEmpty) {
    q = q.where('area', isEqualTo: area.trim());
  }
  if (floors != null && floors > 0) {
    q = q.where('floors', isEqualTo: floors);
  }

  q = q.orderBy('created_at', descending: true);
  if (startAfter != null) {
    q = q.startAfterDocument(startAfter);
  }
  q = q.limit(pageSize);

  final snap = await q.get();
  // استبعاد المنتهية والمؤرشفة (الفلترة الزمنية محلياً لتفادي
  // فهرس مركّب إضافي؛ الحجم صغير أصلاً — 20 وثيقة فقط)
  return snap.docs
      .map((d) => PropertyDataRecord.fromSnapshot(d))
      .where((p) => p.isLive)
      .toList();
}

/// نفس الاستعلام لكن يُرجع لقطات الوثائق أيضاً (لازمة للـ cursor).
Future<QuerySnapshot> fetchPropertiesPageSnapshot({
  int pageSize = 15,
  DocumentSnapshot? startAfter,
  String? category,
  String? listingType,
  String? area, // مناطق الكويت — بدل المحافظة (قرار العميل)
  int? floors,
}) async {
  Query q = PropertyDataRecord.collection
      .where('isApproved', isEqualTo: true);
  if (category != null && category.trim().isNotEmpty) {
    q = q.where('category', isEqualTo: category.trim());
  }
  if (listingType != null && listingType.trim().isNotEmpty) {
    q = q.where('ListingTypy', isEqualTo: listingType.trim());
  }
  if (area != null && area.trim().isNotEmpty) {
    q = q.where('area', isEqualTo: area.trim());
  }
  if (floors != null && floors > 0) {
    q = q.where('floors', isEqualTo: floors);
  }
  q = q.orderBy('created_at', descending: true);
  if (startAfter != null) {
    q = q.startAfterDocument(startAfter);
  }
  return q.limit(pageSize).get();
}

/// تسجيل مشاهدة للإعلان — مرة واحدة فقط لكل مستخدم.
/// لا تُحسب مشاهدة المالك لإعلانه، ولا تتكرر بإعادة بناء الواجهة
/// لأننا نستخدم arrayUnion (لا increment).
Future<void> recordPropertyView(PropertyDataRecord property) async {
  final me = currentUserReference;
  if (me == null) return;                       // الزائر لا يُحتسب
  if (property.ownerRef == me) return;          // المالك لا يزيد عدّاد إعلانه
  if (property.viewedBy.contains(me)) return;   // شوهد من قبل
  try {
    await property.reference.update({
      'viewed_by': FieldValue.arrayUnion([me]),
    });
  } catch (_) {
    // فشل التسجيل لا يجب أن يعطّل عرض الإعلان
  }
}

/// إرسال رسالة — نقطة واحدة يستخدمها كل التطبيق.
/// تكتب participants (مطلوبة لقواعد الأمان) و receiver_ref (للإشعارات)
/// وتحدّث ملخص المحادثة في عملية واحدة.
Future<void> sendChatMessage({
  required DocumentReference chatRef,
  required String text,
  String? type,
}) async {
  final me = currentUserReference;
  if (me == null || text.trim().isEmpty) return;

  final chat = await ChatsRecord.getDocumentOnce(chatRef);
  final users = chat.users.toList();
  final other = users.firstWhere((u) => u != me, orElse: () => me);

  // منع الإرسال إن كان أحد الطرفين حاظراً للآخر
  if (await isBlockedBetween(me, other)) {
    throw Exception('blocked-conversation');
  }

  await MessagesRecord.collection.doc().set({
    ...createMessagesRecordData(
      chatRef: chatRef,
      senderRef: me,
      text: text.trim(),
      createdAt: DateTime.now(),
      receiverRef: other,
      isRead: false,
    ),
    'participants': users.isNotEmpty ? users : [me, other],
    if (type != null) 'type': type, // 'offer' لعروض السعر — يميّزها الخادم
    'deleted_for': <DocumentReference>[],
  });

  await chatRef.update(createChatsRecordData(
    lastMessage: text.trim(),
    lastMessageTime: DateTime.now(),
  ));
}

/// هل بين المستخدمَين حظر (بأي اتجاه)؟
Future<bool> isBlockedBetween(
    DocumentReference a, DocumentReference b) async {
  try {
    final ua = await UsersRecord.getDocumentOnce(a);
    if (ua.blockedUsers.contains(b)) return true;
    final ub = await UsersRecord.getDocumentOnce(b);
    return ub.blockedUsers.contains(a);
  } catch (_) {
    return false;
  }
}

/// حظر / فك حظر مستخدم
Future<void> setUserBlocked(DocumentReference other, bool blocked) async {
  final me = currentUserReference;
  if (me == null) return;
  await me.update({
    'blocked_users':
        blocked ? FieldValue.arrayUnion([other]) : FieldValue.arrayRemove([other]),
  });
}

/// مسح سجل المحادثة للمستخدم الحالي فقط (حذف ناعم — لا يمس الطرف الآخر)
Future<void> clearChatHistoryForMe(DocumentReference chatRef) async {
  final me = currentUserReference;
  if (me == null) return;
  // participants arrayContains: شرط لإثبات القاعدة على استعلام قائمة
  final snap = await MessagesRecord.collection
      .where('participants', arrayContains: me)
      .where('chat_ref', isEqualTo: chatRef)
      .get();
  // WriteBatch بدل await متتابع: محادثة 200 رسالة = رحلة واحدة لا 200
  for (var i = 0; i < snap.docs.length; i += 400) {
    final batch = FirebaseFirestore.instance.batch();
    for (final d in snap.docs.skip(i).take(400)) {
      batch.update(d.reference, {
        'deleted_for': FieldValue.arrayUnion([me]),
      });
    }
    await batch.commit();
  }
}

/// حذف المحادثة للمستخدم الحالي (تُخفى من قائمته)
Future<void> deleteChatForMe(DocumentReference chatRef) async {
  final me = currentUserReference;
  if (me == null) return;
  await clearChatHistoryForMe(chatRef);
  await chatRef.update({
    'deleted_for': FieldValue.arrayUnion([me]),
  });
}

/// تعليم رسائل المحادثة كمقروءة للمستخدم الحالي
Future<void> markChatAsRead(DocumentReference chatRef) async {
  final me = currentUserReference;
  if (me == null) return;
  final snap = await MessagesRecord.collection
      .where('participants', arrayContains: me)
      .where('chat_ref', isEqualTo: chatRef)
      .where('receiver_ref', isEqualTo: me)
      .where('is_read', isEqualTo: false)
      .get();
  for (var i = 0; i < snap.docs.length; i += 400) {
    final batch = FirebaseFirestore.instance.batch();
    for (final d in snap.docs.skip(i).take(400)) {
      batch.update(d.reference, {'is_read': true});
    }
    await batch.commit();
  }
}

/// Returns an existing chat between the current user and [otherUser],
/// or creates a new one if none exists.
/// يُنشئ أو يجلب محادثة مع [otherUser].
///
/// التصنيف يُكتب في قاعدة البيانات لحظة الإنشاء — لا في الواجهة:
///   seller_ref  = صاحب الإعلان (الطرف الآخر عند التواصل من صفحة عقار)
///   buyer_ref   = المستفسِر (المستخدم الحالي)
///   property_ref = الإعلان الذي بدأت منه المحادثة (إن وُجد)
/// فتظهر المحادثة في «كبايع» عند صاحب الإعلان وفي «كمشتري» عند المستفسِر،
/// ولا تتكرر أبداً لأن الاستعلامين مختلفان.
Future<DocumentReference> getOrCreateChat(
  DocumentReference otherUser, {
  DocumentReference? propertyRef,
}) async {
  final me = currentUserReference!;
  final existing = await ChatsRecord.collection
      .where('users', arrayContains: me)
      .get()
      .then((s) => s.docs.where((d) {
            final users = (d.data() as Map<String, dynamic>)['users'];
            return users is List && users.contains(otherUser);
          }));
  if (existing.isNotEmpty) {
    final ref = existing.first.reference;
    // محادثة قديمة بلا تصنيف: نكمل الحقول الناقصة (لا نكتب فوق الموجود)
    final data = existing.first.data() as Map<String, dynamic>;
    if (data['seller_ref'] == null) {
      await ref.set({
        'seller_ref': otherUser,
        'buyer_ref': me,
        if (propertyRef != null) 'property_ref': propertyRef,
      }, SetOptions(merge: true));
    }
    return ref;
  }
  final chatRef = ChatsRecord.collection.doc();
  await chatRef.set({
    ...createChatsRecordData(
      lastMessage: '',
      lastMessageTime: DateTime.now(),
    ),
    'users': [me, otherUser],
    'seller_ref': otherUser,
    'buyer_ref': me,
    if (propertyRef != null) 'property_ref': propertyRef,
  });
  return chatRef;
}

/// محادثات «كمشتري»: أنا المستفسِر
Query chatsAsBuyerQuery() => ChatsRecord.collection
    .where('buyer_ref', isEqualTo: currentUserReference)
    .orderBy('last_message_time', descending: true);

/// محادثات «كبايع»: أنا صاحب الإعلان
Query chatsAsSellerQuery() => ChatsRecord.collection
    .where('seller_ref', isEqualTo: currentUserReference)
    .orderBy('last_message_time', descending: true);

/// حذف عدة محادثات للمستخدم الحالي (ناعم) — لـ «تحديد المحادثات»
Future<int> deleteChatsForMe(List<DocumentReference> chatRefs) async {
  final me = currentUserReference;
  if (me == null || chatRefs.isEmpty) return 0;
  for (final c in chatRefs) {
    await clearChatHistoryForMe(c);
  }
  for (var i = 0; i < chatRefs.length; i += 400) {
    final batch = FirebaseFirestore.instance.batch();
    for (final c in chatRefs.skip(i).take(400)) {
      batch.update(c, {'deleted_for': FieldValue.arrayUnion([me])});
    }
    await batch.commit();
  }
  return chatRefs.length;
}

/* ═══════════════════════════════════════════════════════════
   حالة الاتصال — users/{uid}: is_online + last_seen
   ═══════════════════════════════════════════════════════════ */

/// تُستدعى من مراقب دورة الحياة في main.dart:
/// resumed → true، paused/inactive/detached → false، وعند تسجيل الخروج.
Future<void> setPresence(bool online) async {
  final me = currentUserReference;
  if (me == null) return;
  try {
    await me.set({
      'is_online': online,
      'last_seen': FieldValue.serverTimestamp(),
    }, SetOptions(merge: true));
  } catch (e) {
    debugPrint('setPresence: $e');
  }
}

/// «متصل» يُعتبر صحيحاً فقط إن كان is_online=true **و** آخر نبضة
/// خلال 3 دقائق. هذا يحمي من بقاء الحالة معلقة لو أُغلق التطبيق قسراً
/// (إزالة من المهام، نفاد بطارية) دون أن يصل حدث paused.
bool isUserOnline({required bool? isOnline, required DateTime? lastSeen}) {
  if (isOnline != true || lastSeen == null) return false;
  return DateTime.now().difference(lastSeen).inMinutes < 3;
}

/// «آخر ظهور» بصيغة عربية
String lastSeenLabel(DateTime? lastSeen) {
  if (lastSeen == null) return 'غير متصل';
  final d = DateTime.now().difference(lastSeen);
  if (d.inMinutes < 1) return 'آخر ظهور الآن';
  if (d.inMinutes < 60) return 'آخر ظهور منذ ${d.inMinutes} د';
  if (d.inHours < 24) return 'آخر ظهور منذ ${d.inHours} س';
  if (d.inDays == 1) return 'آخر ظهور أمس';
  return 'آخر ظهور منذ ${d.inDays} يوم';
}

/* ═══════════════════════════════════════════════════════════
   الرسائل المحفوظة — messages.saved_by (مصفوفة مراجع)
   ═══════════════════════════════════════════════════════════ */

Future<void> setMessageSaved(DocumentReference msgRef, bool saved) async {
  final me = currentUserReference;
  if (me == null) return;
  await msgRef.update({
    'saved_by': saved ? FieldValue.arrayUnion([me]) : FieldValue.arrayRemove([me]),
  });
}

/// Firestore يسمح بـ arrayContains واحد فقط لكل استعلام.
/// نستعلم بـ saved_by وحدها، والقاعدة تسمح بالقراءة لمن في saved_by
/// (لا يمكن أن تكون في saved_by دون أن تكون طرفاً — قاعدة التعديل تضمن ذلك).
Query savedMessagesQuery() => MessagesRecord.collection
    .where('saved_by', arrayContains: currentUserReference)
    .orderBy('created_at', descending: true);

Future<int> queryCollectionCount(
  Query collection, {
  Query Function(Query)? queryBuilder,
  int limit = -1,
}) {
  final builder = queryBuilder ?? (q) => q;
  var query = builder(collection);
  if (limit > 0) {
    query = query.limit(limit);
  }

  return query.count().get().catchError((err) {
    print('Error querying $collection: $err');
  }).then((value) => value.count!);
}

Stream<List<T>> queryCollection<T>(
  Query collection,
  RecordBuilder<T> recordBuilder, {
  Query Function(Query)? queryBuilder,
  int limit = -1,
  bool singleRecord = false,
}) {
  final builder = queryBuilder ?? (q) => q;
  var query = builder(collection);
  if (limit > 0 || singleRecord) {
    query = query.limit(singleRecord ? 1 : limit);
  }
  // كان handleError يبتلع الخطأ فلا يصل إلى StreamBuilder.hasError،
  // فتبقى الشاشة على مؤشر التحميل إلى الأبد (permission-denied مثلاً).
  // الآن نسجّله ثم نعيد رميه ليصل إلى الواجهة ويظهر للمستخدم.
  return query.snapshots().handleError((err) {
    debugPrint('Error querying ${collection.toString()}: $err');
    throw err;
  }).map((s) => s.docs
      .map(
        (d) => safeGet(
          () => recordBuilder(d),
          (e) => print('Error serializing doc ${d.reference.path}:\n$e'),
        ),
      )
      .where((d) => d != null)
      .map((d) => d!)
      .toList());
}

Future<List<T>> queryCollectionOnce<T>(
  Query collection,
  RecordBuilder<T> recordBuilder, {
  Query Function(Query)? queryBuilder,
  int limit = -1,
  bool singleRecord = false,
}) {
  final builder = queryBuilder ?? (q) => q;
  var query = builder(collection);
  if (limit > 0 || singleRecord) {
    query = query.limit(singleRecord ? 1 : limit);
  }
  return query.get().then((s) => s.docs
      .map(
        (d) => safeGet(
          () => recordBuilder(d),
          (e) => print('Error serializing doc ${d.reference.path}:\n$e'),
        ),
      )
      .where((d) => d != null)
      .map((d) => d!)
      .toList());
}

Filter filterIn(String field, List? list) => (list?.isEmpty ?? true)
    ? Filter(field, whereIn: null)
    : Filter(field, whereIn: list);

Filter filterArrayContainsAny(String field, List? list) =>
    (list?.isEmpty ?? true)
        ? Filter(field, arrayContainsAny: null)
        : Filter(field, arrayContainsAny: list);

extension QueryExtension on Query {
  Query whereIn(String field, List? list) => (list?.isEmpty ?? true)
      ? where(field, whereIn: null)
      : where(field, whereIn: list);

  Query whereNotIn(String field, List? list) => (list?.isEmpty ?? true)
      ? where(field, whereNotIn: null)
      : where(field, whereNotIn: list);

  Query whereArrayContainsAny(String field, List? list) =>
      (list?.isEmpty ?? true)
          ? where(field, arrayContainsAny: null)
          : where(field, arrayContainsAny: list);
}

class FFFirestorePage<T> {
  final List<T> data;
  final Stream<List<T>>? dataStream;
  final QueryDocumentSnapshot? nextPageMarker;

  FFFirestorePage(this.data, this.dataStream, this.nextPageMarker);
}

Future<FFFirestorePage<T>> queryCollectionPage<T>(
  Query collection,
  RecordBuilder<T> recordBuilder, {
  Query Function(Query)? queryBuilder,
  DocumentSnapshot? nextPageMarker,
  required int pageSize,
  required bool isStream,
}) async {
  final builder = queryBuilder ?? (q) => q;
  var query = builder(collection).limit(pageSize);
  if (nextPageMarker != null) {
    query = query.startAfterDocument(nextPageMarker);
  }
  Stream<QuerySnapshot>? docSnapshotStream;
  QuerySnapshot docSnapshot;
  if (isStream) {
    docSnapshotStream = query.snapshots();
    docSnapshot = await docSnapshotStream.first;
  } else {
    docSnapshot = await query.get();
  }
  final getDocs = (QuerySnapshot s) => s.docs
      .map(
        (d) => safeGet(
          () => recordBuilder(d),
          (e) => print('Error serializing doc ${d.reference.path}:\n$e'),
        ),
      )
      .where((d) => d != null)
      .map((d) => d!)
      .toList();
  final data = getDocs(docSnapshot);
  final dataStream = docSnapshotStream?.map(getDocs);
  final nextPageToken = docSnapshot.docs.isEmpty ? null : docSnapshot.docs.last;
  return FFFirestorePage(data, dataStream, nextPageToken);
}

// Creates a Firestore document representing the logged in user if it doesn't yet exist
Future maybeCreateUser(User user) async {
  final userRecord = UsersRecord.collection.doc(user.uid);
  final userExists = await userRecord.get().then((u) => u.exists);
  if (userExists) {
    currentUserDocument = await UsersRecord.getDocumentOnce(userRecord);
    return;
  }

  final userData = createUsersRecordData(
    email: user.email ??
        FirebaseAuth.instance.currentUser?.email ??
        user.providerData.firstOrNull?.email,
    displayName:
        user.displayName ?? FirebaseAuth.instance.currentUser?.displayName,
    photoUrl: user.photoURL,
    uid: user.uid,
    phoneNumber: user.phoneNumber,
    createdTime: getCurrentTimestamp,
  );

  await userRecord.set(userData);
  currentUserDocument = UsersRecord.getDocumentFromData(userData, userRecord);
}

Future updateUserDocument({String? email}) async {
  await currentUserDocument?.reference
      .update(createUsersRecordData(email: email));
}

/* ═══════════════════════════════════════════════════════════
   الإشعارات — مجموعة notifications، يُنشئها الخادم فقط
   ═══════════════════════════════════════════════════════════ */

/// إشعارات المستخدم الحالي، الأحدث أولاً.
/// user_ref == me هو ما تثبته القاعدة على استعلام القائمة.
Query notificationsQuery() => NotificationsRecord.collection
    .where('user_ref', isEqualTo: currentUserReference)
    .orderBy('created_at', descending: true)
    .limit(100);

/// غير المقروءة فقط — للعدّاد وقراءة الكل
Query unreadNotificationsQuery() => NotificationsRecord.collection
    .where('user_ref', isEqualTo: currentUserReference)
    .where('is_read', isEqualTo: false);

/// «قراءة الكل» — WriteBatch، على إشعارات المستخدم الحالي فقط
Future<int> markAllNotificationsRead() async {
  if (currentUserReference == null) return 0;
  final snap = await unreadNotificationsQuery().get();
  for (var i = 0; i < snap.docs.length; i += 400) {
    final batch = FirebaseFirestore.instance.batch();
    for (final d in snap.docs.skip(i).take(400)) {
      batch.update(d.reference, {'is_read': true});
    }
    await batch.commit();
  }
  return snap.docs.length;
}

Future<void> markNotificationRead(DocumentReference ref) =>
    ref.update({'is_read': true});

/// «حذف الكل» — حذف فعلي، القاعدة تسمح للمالك فقط
Future<int> deleteAllNotificationsForMe() async {
  if (currentUserReference == null) return 0;
  final snap = await notificationsQuery().get();
  for (var i = 0; i < snap.docs.length; i += 400) {
    final batch = FirebaseFirestore.instance.batch();
    for (final d in snap.docs.skip(i).take(400)) {
      batch.delete(d.reference);
    }
    await batch.commit();
  }
  return snap.docs.length;
}

Future<void> deleteNotificationForMe(DocumentReference ref) => ref.delete();

/// استعلام الرسائل غير المقروءة — ما زال مستخدماً في عدّاد الرسائل
/// وشاشة المحادثة، لا للإشعارات.
Query unreadMessagesQuery() {
  return MessagesRecord.collection
      .where('participants', arrayContains: currentUserReference)
      .where('receiver_ref', isEqualTo: currentUserReference)
      .where('is_read', isEqualTo: false);
}

/* ── إعدادات الإشعارات: تُحفظ في users/{uid}.notification_settings ── */

const kNotifDefaults = <String, bool>{
  'messages': true,   // رسائل جديدة
  'requests': true,   // طلبات عقارية
  'listings': true,   // تحديثات الإعلانات
  'marketing': false, // عروض وأخبار
  'sound': true,      // صوت
};

Future<Map<String, bool>> loadNotificationSettings() async {
  final ref = currentUserReference;
  if (ref == null) return Map.of(kNotifDefaults);
  final doc = await ref.get();
  final raw = (doc.data() as Map<String, dynamic>?)?['notification_settings'];
  final out = Map<String, bool>.of(kNotifDefaults);
  if (raw is Map) {
    raw.forEach((k, v) {
      if (v is bool && out.containsKey(k)) out[k as String] = v;
    });
  }
  return out;
}

Future<void> saveNotificationSetting(String key, bool value) async {
  final ref = currentUserReference;
  if (ref == null) return;
  // set+merge: لا يكتب فوق باقي حقول المستخدم ولا يفشل إن غاب الحقل
  await ref.set({
    'notification_settings': {key: value},
  }, SetOptions(merge: true));
}
