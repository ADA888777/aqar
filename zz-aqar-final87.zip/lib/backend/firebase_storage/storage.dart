import 'dart:typed_data';

import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/foundation.dart' show debugPrint;

/// يحدد نوع الصورة من **البايتات** (التوقيع السحري) لا من اسم الملف.
///
/// السبب: قاعدة Storage تشترط contentType صورة. الاعتماد على امتداد الاسم
/// يفشل عندما يعيد منتقي الصور اسماً بلا امتداد (بعض أجهزة أندرويد) أو
/// بامتداد .HEIC (آيفون) — فيصبح contentType فارغاً أو غير مسموح، وترفض
/// القاعدة الرفع برسالة permission-denied لا تدل على السبب.
String? detectImageMime(Uint8List b) {
  if (b.length < 12) return null;
  // JPEG: FF D8 FF
  if (b[0] == 0xFF && b[1] == 0xD8 && b[2] == 0xFF) return 'image/jpeg';
  // PNG: 89 50 4E 47 0D 0A 1A 0A
  if (b[0] == 0x89 && b[1] == 0x50 && b[2] == 0x4E && b[3] == 0x47) {
    return 'image/png';
  }
  // GIF: 47 49 46 38
  if (b[0] == 0x47 && b[1] == 0x49 && b[2] == 0x46 && b[3] == 0x38) {
    return 'image/gif';
  }
  // WEBP: RIFF....WEBP
  if (b[0] == 0x52 && b[1] == 0x49 && b[2] == 0x46 && b[3] == 0x46 &&
      b[8] == 0x57 && b[9] == 0x45 && b[10] == 0x42 && b[11] == 0x50) {
    return 'image/webp';
  }
  // HEIC/HEIF: ....ftypheic / ftypmif1 / ftypheix
  if (b[4] == 0x66 && b[5] == 0x74 && b[6] == 0x79 && b[7] == 0x70) {
    return 'image/heic';
  }
  return null;
}

/// يرفع البيانات إلى [path] ويعيد رابط التحميل، أو null عند الفشل.
///
/// يرمي [FirebaseException] كما هي ليصل الكود الأصلي (storage/unauthorized،
/// storage/quota-exceeded، …) إلى الواجهة ويُعرض للمستخدم.
Future<String?> uploadData(String path, Uint8List data) async {
  final detected = detectImageMime(data);

  // المسموح في قاعدة Storage: jpeg/png/webp/gif.
  // HEIC غير مسموح — لكن image_picker يعيد ترميزه إلى JPEG عندما تُمرَّر
  // imageQuality (كما يفعل التطبيق)، فوصوله هنا نادر. إن وصل نرفض مبكراً
  // برسالة واضحة بدل permission-denied غامضة من الخادم.
  if (detected == 'image/heic') {
    throw FirebaseException(
      plugin: 'firebase_storage',
      code: 'unsupported-format',
      message: 'صيغة HEIC غير مدعومة — أعد اختيار الصورة',
    );
  }
  if (detected == null) {
    throw FirebaseException(
      plugin: 'firebase_storage',
      code: 'not-an-image',
      message: 'الملف ليس صورة صالحة',
    );
  }

  // نضمن أن امتداد المسار يطابق النوع الحقيقي (للتوافق مع أي قراءة لاحقة)
  final ext = detected.split('/').last == 'jpeg' ? 'jpg' : detected.split('/').last;
  final fixedPath = path.contains('.') ? path : '$path.$ext';

  final storageRef = FirebaseStorage.instance.ref().child(fixedPath);
  final metadata = SettableMetadata(contentType: detected);

  debugPrint('uploadData → $fixedPath ($detected, ${data.length} bytes)');
  final result = await storageRef.putData(data, metadata);
  return result.state == TaskState.success ? result.ref.getDownloadURL() : null;
}
