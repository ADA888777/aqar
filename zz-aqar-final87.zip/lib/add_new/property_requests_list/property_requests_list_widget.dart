import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/index.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class PropertyRequestsListWidget extends StatefulWidget {
  const PropertyRequestsListWidget({super.key});

  static String routeName = 'PropertyRequestsList';
  static String routePath = '/propertyRequestsList';

  @override
  State<PropertyRequestsListWidget> createState() =>
      _PropertyRequestsListWidgetState();
}

class _PropertyRequestsListWidgetState
    extends State<PropertyRequestsListWidget> {
  final scaffoldKey = GlobalKey<ScaffoldState>();
  bool onlyMine = false;

  /// فلتر بسيط: نوع الطلب + المحافظة (يُطبَّق على الاستعلام نفسه)
  String? filterType;
  String? filterGov;

  Widget _chip(String text, {bool gold = false}) => Container(
        padding: EdgeInsets.symmetric(horizontal: 10.0, vertical: 4.0),
        decoration: BoxDecoration(
          color: gold
              ? FlutterFlowTheme.of(context).secondary
              : FlutterFlowTheme.of(context).accent1,
          borderRadius: BorderRadius.circular(8.0),
        ),
        child: Text(
          text,
          style: FlutterFlowTheme.of(context).bodySmall.override(
                font: GoogleFonts.cairo(fontWeight: FontWeight.w600),
                color: gold
                    ? Colors.white
                    : FlutterFlowTheme.of(context).primaryText,
                letterSpacing: 0.0,
              ),
        ),
      );

  Widget _requestCard(PropertyRequestsRecord r) {
    final isMine = r.userRef == currentUserReference;
    return Padding(
      padding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 12.0),
      child: Container(
        decoration: BoxDecoration(
          color: FlutterFlowTheme.of(context).secondaryBackground,
          borderRadius: BorderRadius.circular(14.0),
          border: Border.all(
            color: FlutterFlowTheme.of(context).alternate,
            width: 1.0,
          ),
        ),
        padding: EdgeInsets.all(14.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Wrap(
                    spacing: 6.0,
                    runSpacing: 6.0,
                    children: [
                      _chip(r.requestType, gold: true),
                      _chip(r.propertyType),
                      if (r.area.isNotEmpty) _chip(r.area),
                      if (r.area.isNotEmpty) _chip(r.area),
                    ],
                  ),
                ),
                if (isMine)
                  IconButton(
                    tooltip: 'حذف الطلب',
                    icon: Icon(
                      Icons.delete_outline_rounded,
                      color: FlutterFlowTheme.of(context).error,
                      size: 22.0,
                    ),
                    onPressed: () async {
                      final ok = await showDialog<bool>(
                        context: context,
                        builder: (c) => AlertDialog(
                          title: Text('حذف الطلب'),
                          content: Text('هل تريد حذف هذا الطلب نهائياً؟'),
                          actions: [
                            TextButton(
                              onPressed: () => Navigator.pop(c, false),
                              child: Text('إلغاء'),
                            ),
                            TextButton(
                              onPressed: () => Navigator.pop(c, true),
                              child: Text('حذف'),
                            ),
                          ],
                        ),
                      );
                      if (ok == true) {
                        await r.reference.delete();
                      }
                    },
                  ),
              ],
            ),
            if (r.budget.isNotEmpty)
              Padding(
                padding: EdgeInsetsDirectional.fromSTEB(0.0, 10.0, 0.0, 0.0),
                child: Row(
                  children: [
                    Icon(
                      Icons.account_balance_wallet_outlined,
                      size: 17.0,
                      color: FlutterFlowTheme.of(context).secondary,
                    ),
                    SizedBox(width: 6.0),
                    Expanded(
                      child: Text(
                        'الميزانية: ${r.budget} د.ك',
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: FlutterFlowTheme.of(context).bodyMedium.override(
                              font: GoogleFonts.cairo(
                                  fontWeight: FontWeight.w600),
                              letterSpacing: 0.0,
                            ),
                      ),
                    ),
                  ],
                ),
              ),
            if (r.details.isNotEmpty)
              Padding(
                padding: EdgeInsetsDirectional.fromSTEB(0.0, 8.0, 0.0, 0.0),
                child: Text(
                  r.details,
                  style: FlutterFlowTheme.of(context).bodySmall.override(
                        font: GoogleFonts.cairo(),
                        color: FlutterFlowTheme.of(context).secondaryText,
                        letterSpacing: 0.0,
                      ),
                ),
              ),
            Padding(
              padding: EdgeInsetsDirectional.fromSTEB(0.0, 10.0, 0.0, 0.0),
              child: Row(
                children: [
                  Icon(
                    Icons.phone_outlined,
                    size: 17.0,
                    color: FlutterFlowTheme.of(context).secondary,
                  ),
                  SizedBox(width: 6.0),
                  Expanded(
                    child: Text(
                      r.phone,
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            font: GoogleFonts.cairo(),
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                  if (r.createdAt != null)
                    Text(
                      dateTimeFormat('relative', r.createdAt!,
                          locale:
                              FFLocalizations.of(context).languageCode),
                      style: FlutterFlowTheme.of(context).bodySmall.override(
                            font: GoogleFonts.cairo(),
                            color: FlutterFlowTheme.of(context).secondaryText,
                            letterSpacing: 0.0,
                          ),
                    ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    context.watch<FFAppState>();

    return Scaffold(
      key: scaffoldKey,
      backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
      appBar: AppBar(
        backgroundColor: FlutterFlowTheme.of(context).secondaryBackground,
        automaticallyImplyLeading: false,
        leading: InkWell(
          onTap: () => context.safePop(),
          child: Icon(
            Icons.arrow_back_rounded,
            color: FlutterFlowTheme.of(context).primaryText,
            size: 24.0,
          ),
        ),
        title: Text(
          'طلبات العقارات',
          style: FlutterFlowTheme.of(context).titleMedium.override(
                font: GoogleFonts.cairo(fontWeight: FontWeight.w600),
                letterSpacing: 0.0,
              ),
        ),
        centerTitle: true,
        elevation: 0.0,
      ),
      floatingActionButton: FloatingActionButton.extended(
        backgroundColor: FlutterFlowTheme.of(context).primary,
        onPressed: () => context.pushNamed(PropertyRequestWidget.routeName),
        icon: Icon(Icons.add_rounded, color: Colors.white, size: 22.0),
        label: Text(
          'اعرض طلبك',
          style: FlutterFlowTheme.of(context).titleSmall.override(
                font: GoogleFonts.cairo(fontWeight: FontWeight.w600),
                color: Colors.white,
                letterSpacing: 0.0,
              ),
        ),
      ),
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: EdgeInsetsDirectional.fromSTEB(15.0, 12.0, 15.0, 8.0),
              child: Row(
                children: [
                  Expanded(
                    child: InkWell(
                      onTap: () => safeSetState(() => onlyMine = false),
                      child: Container(
                        padding: EdgeInsets.symmetric(vertical: 10.0),
                        decoration: BoxDecoration(
                          color: !onlyMine
                              ? FlutterFlowTheme.of(context).primary
                              : FlutterFlowTheme.of(context)
                                  .secondaryBackground,
                          borderRadius: BorderRadius.circular(10.0),
                          border: Border.all(
                            color: FlutterFlowTheme.of(context).alternate,
                          ),
                        ),
                        alignment: Alignment.center,
                        child: Text(
                          'كل الطلبات',
                          style: FlutterFlowTheme.of(context)
                              .bodyMedium
                              .override(
                                font: GoogleFonts.cairo(
                                    fontWeight: FontWeight.w600),
                                color: !onlyMine
                                    ? Colors.white
                                    : FlutterFlowTheme.of(context).primaryText,
                                letterSpacing: 0.0,
                              ),
                        ),
                      ),
                    ),
                  ),
                  SizedBox(width: 10.0),
                  Expanded(
                    child: InkWell(
                      onTap: () => safeSetState(() => onlyMine = true),
                      child: Container(
                        padding: EdgeInsets.symmetric(vertical: 10.0),
                        decoration: BoxDecoration(
                          color: onlyMine
                              ? FlutterFlowTheme.of(context).primary
                              : FlutterFlowTheme.of(context)
                                  .secondaryBackground,
                          borderRadius: BorderRadius.circular(10.0),
                          border: Border.all(
                            color: FlutterFlowTheme.of(context).alternate,
                          ),
                        ),
                        alignment: Alignment.center,
                        child: Text(
                          'طلباتي',
                          style: FlutterFlowTheme.of(context)
                              .bodyMedium
                              .override(
                                font: GoogleFonts.cairo(
                                    fontWeight: FontWeight.w600),
                                color: onlyMine
                                    ? Colors.white
                                    : FlutterFlowTheme.of(context).primaryText,
                                letterSpacing: 0.0,
                              ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            // ===== فلتر بسيط: نوع الطلب + المحافظة =====
            Padding(
              padding: EdgeInsetsDirectional.fromSTEB(15.0, 4.0, 15.0, 8.0),
              child: Row(
                children: [
                  Expanded(
                    child: DropdownButtonFormField<String>(
                      value: filterType,
                      isExpanded: true,
                      decoration: InputDecoration(
                        isDense: true,
                        hintText: 'نوع الطلب',
                        contentPadding: EdgeInsets.symmetric(
                            horizontal: 12.0, vertical: 10.0),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10.0),
                        ),
                      ),
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            font: GoogleFonts.cairo(),
                            letterSpacing: 0.0,
                          ),
                      items: [
                        DropdownMenuItem(value: null, child: Text('كل الأنواع')),
                        ...FFAppConstants.RequestTypes.map(
                          (t) => DropdownMenuItem(value: t, child: Text(t)),
                        ),
                      ],
                      onChanged: (v) => safeSetState(() => filterType = v),
                    ),
                  ),
                  SizedBox(width: 10.0),
                  Expanded(
                    child: DropdownButtonFormField<String>(
                      value: filterGov,
                      isExpanded: true,
                      decoration: InputDecoration(
                        isDense: true,
                        hintText: 'المنطقة',
                        contentPadding: EdgeInsets.symmetric(
                            horizontal: 12.0, vertical: 10.0),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10.0),
                        ),
                      ),
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            font: GoogleFonts.cairo(),
                            letterSpacing: 0.0,
                          ),
                      items: [
                        DropdownMenuItem(
                            value: null, child: Text('كل المناطق')),
                        // مناطق الكويت — قائمة واحدة بلا محافظات
                        ...FFAppConstants.KuwaitAreas.map(
                          (a) => DropdownMenuItem(value: a, child: Text(a)),
                        ),
                      ],
                      onChanged: (v) => safeSetState(() => filterGov = v),
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: StreamBuilder<List<PropertyRequestsRecord>>(
                stream: queryPropertyRequestsRecord(
                  // الفلترة على الاستعلام نفسه (Firestore) لا داخل التطبيق
                  queryBuilder: (q) {
                    Query out = q;
                    if (onlyMine) {
                      out = out.where('user_ref',
                          isEqualTo: currentUserReference);
                    }
                    if ((filterType ?? '').isNotEmpty) {
                      out = out.where('request_type', isEqualTo: filterType);
                    }
                    if ((filterGov ?? '').isNotEmpty) {
                      // الفلترة بالمنطقة على الخادم — بدل المحافظة
                      out = out.where('area', isEqualTo: filterGov);
                    }
                    return out;
                  },
                ),
                builder: (context, snapshot) {
                  if (!snapshot.hasData) {
                    return Center(
                      child: SizedBox(
                        width: 25.0,
                        height: 25.0,
                        child: CircularProgressIndicator(
                          valueColor: AlwaysStoppedAnimation<Color>(
                            FlutterFlowTheme.of(context).primary,
                          ),
                        ),
                      ),
                    );
                  }
                  final list = snapshot.data!.sortedList(
                    keyOf: (e) => e.createdAt ?? DateTime(2000),
                    desc: true,
                  );
                  if (list.isEmpty) {
                    return Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(24.0, 40.0, 24.0, 0.0),
                      child: Text(
                        onlyMine
                            ? 'لم تنشر أي طلب بعد — اضغط "اعرض طلبك" للبدء'
                            : 'لا توجد طلبات منشورة حالياً',
                        textAlign: TextAlign.center,
                        style: FlutterFlowTheme.of(context).bodyMedium.override(
                              font: GoogleFonts.cairo(),
                              color: FlutterFlowTheme.of(context).secondaryText,
                              letterSpacing: 0.0,
                            ),
                      ),
                    );
                  }
                  return ListView.builder(
                    padding: EdgeInsets.fromLTRB(15.0, 6.0, 15.0, 90.0),
                    itemCount: list.length,
                    itemBuilder: (context, i) => _requestCard(list[i]),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
