import '/flutter_flow/flutter_flow_util.dart';
import 'property_request_widget.dart' show PropertyRequestWidget;
import 'package:flutter/material.dart';

class PropertyRequestModel extends FlutterFlowModel<PropertyRequestWidget> {
  final formKey = GlobalKey<FormState>();

  String? requestType;
  String? propertyType;
  String? governorate;
  String? area;
  bool isSaving = false;

  FocusNode? budgetFocusNode;
  TextEditingController? budgetController;

  FocusNode? detailsFocusNode;
  TextEditingController? detailsController;

  FocusNode? phoneFocusNode;
  TextEditingController? phoneController;

  @override
  void initState(BuildContext context) {
    budgetController = TextEditingController();
    detailsController = TextEditingController();
    phoneController = TextEditingController();
  }

  @override
  void dispose() {
    budgetFocusNode?.dispose();
    budgetController?.dispose();
    detailsFocusNode?.dispose();
    detailsController?.dispose();
    phoneFocusNode?.dispose();
    phoneController?.dispose();
  }
}
