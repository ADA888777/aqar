import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/flutter_flow/error_messages_ar.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'property_request_model.dart';
export 'property_request_model.dart';

class PropertyRequestWidget extends StatefulWidget {
  const PropertyRequestWidget({
    super.key,
    this.governorate,
  });

  final String? governorate;

  static String routeName = 'PropertyRequest';
  static String routePath = '/propertyRequest';

  @override
  State<PropertyRequestWidget> createState() => _PropertyRequestWidgetState();
}

class _PropertyRequestWidgetState extends State<PropertyRequestWidget> {
  late PropertyRequestModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => PropertyRequestModel());
    _model.governorate = widget.governorate;
    _model.requestType = FFAppConstants.RequestTypes.first;
  }

  @override
  void dispose() {
    _model.dispose();
    super.dispose();
  }

  Widget _label(String text) => Padding(
        padding: EdgeInsetsDirectional.fromSTEB(4.0, 0.0, 0.0, 6.0),
        child: Text(
          text,
          style: FlutterFlowTheme.of(context).bodySmall.override(
                font: GoogleFonts.cairo(),
                color: FlutterFlowTheme.of(context).secondaryText,
                letterSpacing: 0.0,
              ),
        ),
      );

  InputDecoration _fieldDecoration(String hint) => InputDecoration(
        isDense: true,
        hintText: hint,
        hintStyle: FlutterFlowTheme.of(context).bodyMedium.override(
              font: GoogleFonts.cairo(),
              color: FlutterFlowTheme.of(context).secondaryText,
              letterSpacing: 0.0,
            ),
        filled: true,
        fillColor: FlutterFlowTheme.of(context).secondaryBackground,
        contentPadding: EdgeInsets.symmetric(horizontal: 16.0, vertical: 14.0),
        enabledBorder: OutlineInputBorder(
          borderSide: BorderSide(
            color: FlutterFlowTheme.of(context).alternate,
            width: 1.0,
          ),
          borderRadius: BorderRadius.circular(12.0),
        ),
        focusedBorder: OutlineInputBorder(
          borderSide: BorderSide(
            color: FlutterFlowTheme.of(context).primary,
            width: 1.5,
          ),
          borderRadius: BorderRadius.circular(12.0),
        ),
        errorBorder: OutlineInputBorder(
          borderSide: BorderSide(
            color: FlutterFlowTheme.of(context).error,
            width: 1.0,
          ),
          borderRadius: BorderRadius.circular(12.0),
        ),
        focusedErrorBorder: OutlineInputBorder(
          borderSide: BorderSide(
            color: FlutterFlowTheme.of(context).error,
            width: 1.5,
          ),
          borderRadius: BorderRadius.circular(12.0),
        ),
      );

  Widget _textField({
    required String label,
    required String hint,
    required TextEditingController? controller,
    FocusNode? focusNode,
    TextInputType keyboard = TextInputType.text,
    int maxLines = 1,
    String? Function(String?)? validator,
  }) =>
      Padding(
        padding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 14.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _label(label),
            TextFormField(
              controller: controller,
              focusNode: focusNode,
              keyboardType: keyboard,
              maxLines: maxLines,
              decoration: _fieldDecoration(hint),
              style: FlutterFlowTheme.of(context).bodyMedium.override(
                    font: GoogleFonts.cairo(),
                    letterSpacing: 0.0,
                  ),
              validator: validator,
            ),
          ],
        ),
      );

  Widget _dropdown({
    required String label,
    required String hint,
    required String? value,
    required List<String> options,
    required void Function(String?) onChanged,
    bool required = true,
  }) =>
      Padding(
        padding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 14.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _label(label),
            DropdownButtonFormField<String>(
              value: value,
              isExpanded: true,
              decoration: _fieldDecoration(hint),
              icon: Icon(
                Icons.keyboard_arrow_down_rounded,
                color: FlutterFlowTheme.of(context).secondaryText,
              ),
              dropdownColor: FlutterFlowTheme.of(context).secondaryBackground,
              borderRadius: BorderRadius.circular(12.0),
              style: FlutterFlowTheme.of(context).bodyMedium.override(
                    font: GoogleFonts.cairo(),
                    letterSpacing: 0.0,
                  ),
              items: options
                  .where((e) => e.trim().isNotEmpty)
                  .map((e) => DropdownMenuItem<String>(
                        value: e,
                        child: Text(
                          e,
                          overflow: TextOverflow.ellipsis,
                          style:
                              FlutterFlowTheme.of(context).bodyMedium.override(
                                    font: GoogleFonts.cairo(),
                                    letterSpacing: 0.0,
                                  ),
                        ),
                      ))
                  .toList(),
              onChanged: onChanged,
              validator: (v) => (required && (v == null || v.isEmpty))
                  ? 'هذا الحقل مطلوب'
                  : null,
            ),
          ],
        ),
      );

  Widget _chips({
    required String title,
    required List<String> options,
    required String? selected,
    required void Function(String) onSelect,
  }) =>
      Padding(
        padding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 14.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _label(title),
            Wrap(
              spacing: 8.0,
              runSpacing: 8.0,
              children: options.map((o) {
                final isSel = selected == o;
                return InkWell(
                  onTap: () => safeSetState(() => onSelect(o)),
                  child: Container(
                    padding: EdgeInsets.symmetric(
                        horizontal: 18.0, vertical: 10.0),
                    decoration: BoxDecoration(
                      color: isSel
                          ? FlutterFlowTheme.of(context).primary
                          : FlutterFlowTheme.of(context).secondaryBackground,
                      borderRadius: BorderRadius.circular(10.0),
                      border: Border.all(
                        color: isSel
                            ? FlutterFlowTheme.of(context).primary
                            : FlutterFlowTheme.of(context).alternate,
                        width: 1.0,
                      ),
                    ),
                    child: Text(
                      o,
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            font: GoogleFonts.cairo(
                                fontWeight:
                                    isSel ? FontWeight.w600 : FontWeight.normal),
                            color: isSel
                                ? Colors.white
                                : FlutterFlowTheme.of(context).primaryText,
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                );
              }).toList(),
            ),
          ],
        ),
      );

  Future<void> _submit() async {
    if (currentUserReference == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('سجّل دخولك لنشر طلبك'),
          backgroundColor: FlutterFlowTheme.of(context).error,
        ),
      );
      return;
    }
    if (_model.requestType == null || _model.propertyType == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('الرجاء اختيار نوع الطلب ونوع العقار'),
          backgroundColor: FlutterFlowTheme.of(context).error,
        ),
      );
      return;
    }
    if (!(_model.formKey.currentState?.validate() ?? false)) {
      return;
    }

    safeSetState(() => _model.isSaving = true);
    try {
      await PropertyRequestsRecord.collection
          .doc()
          .set(createPropertyRequestsRecordData(
            requestType: _model.requestType,
            propertyType: _model.propertyType,
            // تُشتق من المنطقة للتوافق — لا تُختار يدوياً
            governorate: FFAppConstants.governorateOfArea(_model.area) ?? '',
            area: _model.area ?? '',
            budget: _model.budgetController.text.trim(),
            details: _model.detailsController.text.trim(),
            phone: _model.phoneController.text.trim(),
            userRef: currentUserReference,
            createdAt: DateTime.now(),
          ));
    } catch (e) {
      safeSetState(() => _model.isSaving = false);
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            duration: Duration(seconds: 6),
            content: Text('تعذر نشر الطلب — ${firebaseErrorAr(e)}'),
            backgroundColor: FlutterFlowTheme.of(context).error,
          ),
        );
      }
      return;
    }

    safeSetState(() => _model.isSaving = false);
    if (!context.mounted) {
      return;
    }
    await showDialog(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: Text(
          'تم نشر طلبك بنجاح',
          style: FlutterFlowTheme.of(context).titleMedium.override(
                font: GoogleFonts.cairo(fontWeight: FontWeight.w600),
                letterSpacing: 0.0,
              ),
        ),
        content: Text(
          'سيتواصل معك الوسطاء وأصحاب العقارات المطابقة لطلبك قريباً.',
          style: FlutterFlowTheme.of(context).bodyMedium.override(
                font: GoogleFonts.cairo(),
                letterSpacing: 0.0,
              ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext),
            child: Text(
              'حسناً',
              style: FlutterFlowTheme.of(context).bodyMedium.override(
                    font: GoogleFonts.cairo(fontWeight: FontWeight.w600),
                    color: FlutterFlowTheme.of(context).primary,
                    letterSpacing: 0.0,
                  ),
            ),
          ),
        ],
      ),
    );
    if (context.mounted) {
      context.safePop();
    }
  }

  @override
  Widget build(BuildContext context) {
    context.watch<FFAppState>();

    return GestureDetector(
      onTap: () {
        FocusScope.of(context).unfocus();
        FocusManager.instance.primaryFocus?.unfocus();
      },
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
        appBar: AppBar(
          backgroundColor: FlutterFlowTheme.of(context).secondaryBackground,
          automaticallyImplyLeading: false,
          leading: InkWell(
            onTap: () => context.safePop(),
            child: Icon(
              Icons.arrow_back_rounded,
              color: FlutterFlowTheme.of(context).primaryText,
              size: 24.0,
            ),
          ),
          title: Text(
            'طلب عقار',
            style: FlutterFlowTheme.of(context).titleMedium.override(
                  font: GoogleFonts.cairo(fontWeight: FontWeight.w600),
                  letterSpacing: 0.0,
                ),
          ),
          centerTitle: true,
          elevation: 0.0,
        ),
        body: SafeArea(
          child: Form(
            key: _model.formKey,
            autovalidateMode: AutovalidateMode.disabled,
            child: SingleChildScrollView(
              padding: EdgeInsets.fromLTRB(16.0, 16.0, 16.0, 24.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'اكتب ما تبحث عنه وسيصلك من يوفّره',
                    style: FlutterFlowTheme.of(context).bodySmall.override(
                          font: GoogleFonts.cairo(),
                          color: FlutterFlowTheme.of(context).secondaryText,
                          letterSpacing: 0.0,
                        ),
                  ),
                  SizedBox(height: 16.0),
                  _chips(
                    title: 'نوع الطلب',
                    options: FFAppConstants.RequestTypes,
                    selected: _model.requestType,
                    onSelect: (v) => _model.requestType = v,
                  ),
                  _chips(
                    title: 'نوع العقار',
                    options: FFAppConstants.RequestPropertyTypes,
                    selected: _model.propertyType,
                    onSelect: (v) => _model.propertyType = v,
                  ),
                  // مناطق الكويت: قائمة واحدة اختيارية، بلا محافظات
                  _dropdown(
                    label: 'مناطق الكويت (اختياري)',
                    hint: 'اختر المنطقة أو اتركها فارغة',
                    value: _model.area,
                    options: FFAppConstants.KuwaitAreas,
                    onChanged: (v) => safeSetState(() => _model.area = v),
                    required: false,
                  ),
                  _textField(
                    label: 'الميزانية (د.ك)',
                    hint: 'مثال: 120,000 أو 400 شهرياً',
                    controller: _model.budgetController,
                    focusNode: _model.budgetFocusNode,
                    validator: (v) => (v == null || v.trim().isEmpty)
                        ? 'الرجاء إدخال الميزانية'
                        : null,
                  ),
                  _textField(
                    label: 'تفاصيل إضافية',
                    hint:
                        'مثال: أبحث عن بيت بمساحة 500م² قريب من المدارس، دورين ومدخلين...',
                    controller: _model.detailsController,
                    focusNode: _model.detailsFocusNode,
                    maxLines: 4,
                  ),
                  _textField(
                    label: 'رقم الهاتف',
                    hint: 'مثال: 9xxxxxxx',
                    controller: _model.phoneController,
                    focusNode: _model.phoneFocusNode,
                    keyboard: TextInputType.phone,
                    validator: (v) => (v == null || v.trim().length < 8)
                        ? 'الرجاء إدخال رقم هاتف صحيح'
                        : null,
                  ),
                  SizedBox(height: 6.0),
                  FFButtonWidget(
                    onPressed: _model.isSaving ? null : () => _submit(),
                    text: 'نشر الطلب',
                    options: FFButtonOptions(
                      width: double.infinity,
                      height: 52.0,
                      padding: EdgeInsets.zero,
                      iconPadding: EdgeInsets.zero,
                      color: FlutterFlowTheme.of(context).primary,
                      textStyle:
                          FlutterFlowTheme.of(context).titleSmall.override(
                                font: GoogleFonts.cairo(
                                    fontWeight: FontWeight.w600),
                                color: Colors.white,
                                fontSize: 16.0,
                                letterSpacing: 0.0,
                              ),
                      elevation: 0.0,
                      borderRadius: BorderRadius.circular(14.0),
                    ),
                    showLoadingIndicator: false,
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
