import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/backend/firebase_storage/storage.dart';
import '/flutter_flow/error_messages_ar.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/upload_data.dart';
import '/index.dart';
import 'package:flutter/material.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'add_new_model.dart';
export 'add_new_model.dart';

class AddNewWidget extends StatefulWidget {
  const AddNewWidget({
    super.key,
    this.property,
  });

  /// عند تمرير عقار، تعمل الصفحة في وضع التعديل بدل الإضافة
  final PropertyDataRecord? property;

  static String routeName = 'AddNew';
  static String routePath = '/addNew';

  @override
  State<AddNewWidget> createState() => _AddNewWidgetState();
}

class _AddNewWidgetState extends State<AddNewWidget> {
  late AddNewModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => AddNewModel());
    final p = widget.property;
    if (p == null && currentUserReference != null) {
      // إعلان جديد: نعبّئ رقم المستخدم من ملفه الشخصي إن وُجد (قابل للتعديل)
      UsersRecord.getDocumentOnce(currentUserReference!).then((u) {
        if (mounted && (_model.phoneController?.text ?? '').isEmpty) {
          safeSetState(() => _model.phoneController?.text = u.phoneNumber);
        }
      }).catchError((_) {});
    }
    if (p != null) {
      _model.listingType = p.listingTypy.isNotEmpty ? p.listingTypy : 'rent';
      _model.propertyType = FFAppConstants.PropertyCategories
              .contains(p.category)
          ? p.category
          : null;
      // المنطقة من القائمة المسطحة (لا تقسيم بالمحافظات).
      // المحافظة تُشتق داخلياً من المنطقة ولا تظهر للمستخدم.
      _model.area =
          FFAppConstants.KuwaitAreas.contains(p.area) ? p.area : null;
      _model.governorate = FFAppConstants.governorateOfArea(_model.area);
      _model.masterRooms = p.masterRooms;
      _model.rooms = p.rooms;
      _model.halls = p.halls;
      _model.kitchens = p.kitchens;
      _model.diwaniyas = p.diwaniyas;
      _model.maidRoom = p.maidRoom;
      _model.bathrooms = p.bathrooms;
      _model.laundryRoom = p.laundryRoom;
      _model.existingImages = p.propertyImages.toList();
      _model.selectedFeatures = p.features.toList();
      _model.units = p.units;
      _model.floors = p.floors;

      WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {
            _model.blockController?.text = p.block;
            _model.streetController?.text = p.street;
            _model.numberController?.text = p.propertyNumber;
            _model.sizeController?.text = p.size;
            _model.priceController?.text =
                p.price > 0 ? p.price.toStringAsFixed(0) : '';
            _model.depositController?.text =
                p.deposit > 0 ? p.deposit.toStringAsFixed(0) : '';
            _model.phoneController?.text = p.contactPhone;
            _model.frontageController?.text = p.frontage;
            _model.whatsappController?.text = p.whatsappPhone;
            _model.descController?.text = p.description;
          }));
    }
  }

  @override
  void dispose() {
    _model.dispose();
    super.dispose();
  }

  // ===== أدوات التنسيق =====

  /// حقول التصنيف المختار حالياً — تحدد أي بيانات تُعرض وتُحفظ.
  /// (محل تجاري لا يحفظ دواوين، شاليه لا يحفظ غرف ماستر... إلخ)
  List<String> get _catFields =>
      FFAppConstants.FieldsByCategory[_model.propertyType ?? ''] ??
      const <String>[];

  Widget _sectionTitle(String title) => Padding(
        padding: EdgeInsetsDirectional.fromSTEB(0.0, 20.0, 0.0, 10.0),
        child: Text(
          title,
          style: FlutterFlowTheme.of(context).titleMedium.override(
                font: GoogleFonts.cairo(fontWeight: FontWeight.w600),
                letterSpacing: 0.0,
              ),
        ),
      );

  InputDecoration _fieldDecoration(String hint) => InputDecoration(
        isDense: true,
        hintText: hint,
        hintStyle: FlutterFlowTheme.of(context).bodyMedium.override(
              font: GoogleFonts.cairo(),
              color: FlutterFlowTheme.of(context).secondaryText,
              letterSpacing: 0.0,
            ),
        filled: true,
        fillColor: FlutterFlowTheme.of(context).secondaryBackground,
        contentPadding: EdgeInsets.symmetric(horizontal: 16.0, vertical: 14.0),
        enabledBorder: OutlineInputBorder(
          borderSide: BorderSide(
            color: FlutterFlowTheme.of(context).alternate,
            width: 1.0,
          ),
          borderRadius: BorderRadius.circular(12.0),
        ),
        focusedBorder: OutlineInputBorder(
          borderSide: BorderSide(
            color: FlutterFlowTheme.of(context).primary,
            width: 1.5,
          ),
          borderRadius: BorderRadius.circular(12.0),
        ),
        errorBorder: OutlineInputBorder(
          borderSide: BorderSide(
            color: FlutterFlowTheme.of(context).error,
            width: 1.0,
          ),
          borderRadius: BorderRadius.circular(12.0),
        ),
        focusedErrorBorder: OutlineInputBorder(
          borderSide: BorderSide(
            color: FlutterFlowTheme.of(context).error,
            width: 1.5,
          ),
          borderRadius: BorderRadius.circular(12.0),
        ),
      );

  Widget _label(String text, {bool required = false}) => Padding(
        padding: EdgeInsetsDirectional.fromSTEB(4.0, 0.0, 0.0, 6.0),
        child: Text.rich(
          TextSpan(
            text: text,
            children: [
              // نجمة حمراء تُميّز الإلزامي عن الاختياري
              if (required)
                TextSpan(
                    text: ' *',
                    style: TextStyle(
                        color: FlutterFlowTheme.of(context).error,
                        fontWeight: FontWeight.bold)),
            ],
          ),
          style: FlutterFlowTheme.of(context).bodySmall.override(
                font: GoogleFonts.cairo(),
                color: FlutterFlowTheme.of(context).secondaryText,
                letterSpacing: 0.0,
              ),
        ),
      );

  /// مفاتيح الحقول الإلزامية بترتيب ظهورها في الشاشة —
  /// تُستخدم للتمرير إلى أول حقل ناقص عند فشل التحقق.
  final List<GlobalKey<FormFieldState<dynamic>>> _requiredKeys = [];
  bool _submitted = false;

  /// يمرّر الشاشة إلى أول حقل إلزامي فيه خطأ ويعيد عدد الأخطاء.
  /// كل الحقول الناقصة تظهر حمراء (Form.validate يعلّمها جميعاً)،
  /// والتمرير إلى الأول منها فقط.
  Future<int> _scrollToFirstError() async {
    var count = 0;
    BuildContext? first;
    for (final k in _requiredKeys) {
      final st = k.currentState;
      if (st == null) continue;
      if (st.hasError) {
        count++;
        first ??= k.currentContext;
      }
    }
    if (first != null) {
      await Scrollable.ensureVisible(
        first,
        alignment: 0.15,
        duration: const Duration(milliseconds: 350),
        curve: Curves.easeInOut,
      );
    }
    return count;
  }
  final Map<String, GlobalKey<FormFieldState<String>>> _dropdownKeys = {};
  final Map<String, GlobalKey<FormFieldState<String>>> _fieldKeys = {};
  // مرساتان للتمرير إلى قسمين يُفحصان خارج Form: الصور والتصنيف
  final GlobalKey _imagesAnchor = GlobalKey();
  final GlobalKey _categoryAnchor = GlobalKey();

  Future<void> _scrollTo(GlobalKey k) async {
    final c = k.currentContext;
    if (c == null) return;
    await Scrollable.ensureVisible(c,
        alignment: 0.1,
        duration: const Duration(milliseconds: 350),
        curve: Curves.easeInOut);
  }
  GlobalKey<FormFieldState<String>> _dropdownKey(String label) {
    final k = _dropdownKeys.putIfAbsent(
        label, () => GlobalKey<FormFieldState<String>>());
    if (!_requiredKeys.contains(k)) _requiredKeys.add(k);
    return k;
  }

  /// الحقل النصي. required=true يُنتج رسالة «<label> مطلوب» تلقائياً
  /// إن لم يُمرَّر validator مخصص، ويُسجَّل للتمرير التلقائي.
  Widget _textField({
    required String label,
    required String hint,
    required TextEditingController? controller,
    FocusNode? focusNode,
    TextInputType keyboard = TextInputType.text,
    int maxLines = 1,
    String? Function(String?)? validator,
    bool required = false,
  }) {
    // مفتاح ثابت (من الخريطة) — مفتاح جديد في كل build يُفقد النص المكتوب
    GlobalKey<FormFieldState<String>>? key;
    if (required || validator != null) {
      key = _fieldKeys.putIfAbsent(
          label, () => GlobalKey<FormFieldState<String>>());
      if (!_requiredKeys.contains(key)) _requiredKeys.add(key);
    }
    final effectiveValidator = validator ??
        (required
            ? (String? v) =>
                (v == null || v.trim().isEmpty) ? '$label مطلوب' : null
            : null);
    return Padding(
        padding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 14.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _label(label, required: required), // النجمة للإلزامي فقط
            TextFormField(
              key: key,
              controller: controller,
              focusNode: focusNode,
              keyboardType: keyboard,
              maxLines: maxLines,
              textInputAction:
                  maxLines > 1 ? TextInputAction.newline : TextInputAction.next,
              decoration: _fieldDecoration(hint),
              style: FlutterFlowTheme.of(context).bodyMedium.override(
                    font: GoogleFonts.cairo(),
                    letterSpacing: 0.0,
                  ),
              validator: effectiveValidator,
            ),
          ],
        ),
      );
  }

  Widget _dropdown({
    required String label,
    required String hint,
    required String? value,
    required List<String> options,
    required void Function(String?) onChanged,
    bool required = true,
    /// لعرض اسم مختلف عن القيمة المخزّنة (مثل: 'بدل أراضي' → 'أراضي')
    String Function(String)? labelBuilder,
  }) =>
      Padding(
        padding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 14.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _label(label, required: required),
            DropdownButtonFormField<String>(
              key: required ? _dropdownKey(label) : null,
              value: value,
              isExpanded: true,
              decoration: _fieldDecoration(hint),
              icon: Icon(
                Icons.keyboard_arrow_down_rounded,
                color: FlutterFlowTheme.of(context).secondaryText,
              ),
              dropdownColor: FlutterFlowTheme.of(context).secondaryBackground,
              borderRadius: BorderRadius.circular(12.0),
              style: FlutterFlowTheme.of(context).bodyMedium.override(
                    font: GoogleFonts.cairo(),
                    letterSpacing: 0.0,
                  ),
              items: options
                  .where((e) => e.trim().isNotEmpty)
                  .map((e) => DropdownMenuItem<String>(
                        value: e,
                        child: Text(
                          labelBuilder != null ? labelBuilder(e) : e,
                          overflow: TextOverflow.ellipsis,
                          style:
                              FlutterFlowTheme.of(context).bodyMedium.override(
                                    font: GoogleFonts.cairo(),
                                    letterSpacing: 0.0,
                                  ),
                        ),
                      ))
                  .toList(),
              onChanged: onChanged,
              // الاختياري لا يُعتبر ناقصاً أبداً (البند 6)
              validator: !required
                  ? null
                  : (v) => (v == null || v.isEmpty) ? '$label مطلوب' : null,
            ),
          ],
        ),
      );

  Widget _counter({
    required String label,
    required int value,
    required void Function(int) onChanged,
  }) =>
      Padding(
        padding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 12.0),
        child: Container(
          decoration: BoxDecoration(
            color: FlutterFlowTheme.of(context).secondaryBackground,
            borderRadius: BorderRadius.circular(12.0),
            border: Border.all(
              color: FlutterFlowTheme.of(context).alternate,
              width: 1.0,
            ),
          ),
          padding: EdgeInsets.symmetric(horizontal: 14.0, vertical: 8.0),
          child: Row(
            children: [
              Expanded(
                child: Text(
                  label,
                  style: FlutterFlowTheme.of(context).bodyMedium.override(
                        font: GoogleFonts.cairo(),
                        letterSpacing: 0.0,
                      ),
                ),
              ),
              IconButton(
                onPressed: value > 0 ? () => onChanged(value - 1) : null,
                icon: Icon(
                  Icons.remove_circle_outline_rounded,
                  color: value > 0
                      ? FlutterFlowTheme.of(context).primary
                      : FlutterFlowTheme.of(context).alternate,
                  size: 26.0,
                ),
              ),
              Container(
                width: 34.0,
                alignment: Alignment.center,
                child: Text(
                  value.toString(),
                  style: FlutterFlowTheme.of(context).titleSmall.override(
                        font: GoogleFonts.cairo(fontWeight: FontWeight.w600),
                        letterSpacing: 0.0,
                      ),
                ),
              ),
              IconButton(
                onPressed: value < 20 ? () => onChanged(value + 1) : null,
                icon: Icon(
                  Icons.add_circle_outline_rounded,
                  color: FlutterFlowTheme.of(context).primary,
                  size: 26.0,
                ),
              ),
            ],
          ),
        ),
      );

  Widget _switchTile({
    required String label,
    required bool value,
    required void Function(bool) onChanged,
  }) =>
      Padding(
        padding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 12.0),
        child: Container(
          decoration: BoxDecoration(
            color: FlutterFlowTheme.of(context).secondaryBackground,
            borderRadius: BorderRadius.circular(12.0),
            border: Border.all(
              color: FlutterFlowTheme.of(context).alternate,
              width: 1.0,
            ),
          ),
          padding: EdgeInsets.symmetric(horizontal: 14.0, vertical: 4.0),
          child: Row(
            children: [
              Expanded(
                child: Text(
                  label,
                  style: FlutterFlowTheme.of(context).bodyMedium.override(
                        font: GoogleFonts.cairo(),
                        letterSpacing: 0.0,
                      ),
                ),
              ),
              Switch.adaptive(
                value: value,
                onChanged: (v) => onChanged(v),
                activeColor: FlutterFlowTheme.of(context).primary,
              ),
            ],
          ),
        ),
      );

  // ===== قسم الصور =====

  Future<void> _pickImages() async {
    final selected = await selectMediaWithSourceBottomSheet(
      context: context,
      allowPhoto: true,
      // ضغط صور العقار: عرض 1280 يكفي لعرض عالي الوضوح على الجوال
      // وجودة 78 توازن بين الحجم والوضوح (تقليل ~85% من الحجم الأصلي).
      maxWidth: 1280.0,
      maxHeight: 1280.0,
      imageQuality: 78,
      pickerFontFamily: 'Cairo',
    );
    if (selected == null || selected.isEmpty) {
      return;
    }
    safeSetState(() {
      for (final f in selected) {
        if (_model.images.length + _model.existingImages.length >= 6) break;
        _model.images.add(FFUploadedFile(
          name: f.storagePath.split('/').last,
          bytes: f.bytes,
          originalFilename: f.originalFilename,
        ));
      }
    });
  }

  Widget _photosSection() {
    final tiles = <Widget>[];
    // الصور المحفوظة سابقاً (وضع التعديل)
    for (var i = 0; i < _model.existingImages.length; i++) {
      final url = _model.existingImages[i];
      tiles.add(Stack(
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(12.0),
            child: Image.network(
              url,
              width: 100.0,
              height: 100.0,
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => Container(
                width: 100.0,
                height: 100.0,
                color: FlutterFlowTheme.of(context).alternate,
              ),
            ),
          ),
          Positioned(
            top: 2.0,
            right: 2.0,
            child: InkWell(
              onTap: () =>
                  safeSetState(() => _model.existingImages.removeAt(i)),
              child: Container(
                decoration: BoxDecoration(
                  color: FlutterFlowTheme.of(context).error,
                  shape: BoxShape.circle,
                ),
                padding: EdgeInsets.all(3.0),
                child:
                    Icon(Icons.close_rounded, color: Colors.white, size: 15.0),
              ),
            ),
          ),
        ],
      ));
    }
    for (var i = 0; i < _model.images.length; i++) {
      final img = _model.images[i];
      tiles.add(Stack(
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(12.0),
            child: Image.memory(
              img.bytes ?? Uint8List.fromList([]),
              width: 100.0,
              height: 100.0,
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => Container(
                width: 100.0,
                height: 100.0,
                color: FlutterFlowTheme.of(context).alternate,
              ),
            ),
          ),
          Positioned(
            top: 2.0,
            right: 2.0,
            child: InkWell(
              onTap: () => safeSetState(() => _model.images.removeAt(i)),
              child: Container(
                decoration: BoxDecoration(
                  color: FlutterFlowTheme.of(context).error,
                  shape: BoxShape.circle,
                ),
                padding: EdgeInsets.all(3.0),
                child:
                    Icon(Icons.close_rounded, color: Colors.white, size: 15.0),
              ),
            ),
          ),
          if (i == 0)
            Positioned(
              bottom: 4.0,
              left: 4.0,
              child: Container(
                decoration: BoxDecoration(
                  color: FlutterFlowTheme.of(context).primary,
                  borderRadius: BorderRadius.circular(6.0),
                ),
                padding: EdgeInsets.symmetric(horizontal: 6.0, vertical: 2.0),
                child: Text(
                  'الرئيسية',
                  style: FlutterFlowTheme.of(context).bodySmall.override(
                        font: GoogleFonts.cairo(),
                        color: Colors.white,
                        fontSize: 10.0,
                        letterSpacing: 0.0,
                      ),
                ),
              ),
            ),
        ],
      ));
    }
    if (_model.images.length + _model.existingImages.length < 6) {
      tiles.add(InkWell(
        onTap: _pickImages,
        child: Container(
          width: 100.0,
          height: 100.0,
          decoration: BoxDecoration(
            color: FlutterFlowTheme.of(context).secondaryBackground,
            borderRadius: BorderRadius.circular(12.0),
            border: Border.all(
              color: FlutterFlowTheme.of(context).primary,
              width: 1.2,
            ),
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                Icons.add_a_photo_outlined,
                color: FlutterFlowTheme.of(context).primary,
                size: 26.0,
              ),
              SizedBox(height: 6.0),
              Text(
                'إضافة صورة',
                style: FlutterFlowTheme.of(context).bodySmall.override(
                      font: GoogleFonts.cairo(),
                      color: FlutterFlowTheme.of(context).primary,
                      fontSize: 11.0,
                      letterSpacing: 0.0,
                    ),
              ),
            ],
          ),
        ),
      ));
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        KeyedSubtree(key: _imagesAnchor, child: _sectionTitle('صور العقار')),
        Text(
          'أضف حتى 6 صور واضحة — الصورة الأولى هي صورة الإعلان الرئيسية',
          style: FlutterFlowTheme.of(context).bodySmall.override(
                font: GoogleFonts.cairo(),
                color: FlutterFlowTheme.of(context).secondaryText,
                letterSpacing: 0.0,
              ),
        ),
        SizedBox(height: 12.0),
        Wrap(spacing: 10.0, runSpacing: 10.0, children: tiles),
      ],
    );
  }

  // ===== مفتاح إيجار / بيع =====

  Widget _listingTypeSwitch() {
    Widget option(String value, String label, IconData icon) {
      final selected = _model.listingType == value;
      return Expanded(
        child: InkWell(
          onTap: () => safeSetState(() => _model.listingType = value),
          child: Container(
            padding: EdgeInsets.symmetric(vertical: 14.0),
            decoration: BoxDecoration(
              color: selected
                  ? FlutterFlowTheme.of(context).primary
                  : FlutterFlowTheme.of(context).secondaryBackground,
              borderRadius: BorderRadius.circular(12.0),
              border: Border.all(
                color: selected
                    ? FlutterFlowTheme.of(context).primary
                    : FlutterFlowTheme.of(context).alternate,
                width: 1.0,
              ),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(
                  icon,
                  size: 20.0,
                  color: selected
                      ? Colors.white
                      : FlutterFlowTheme.of(context).secondaryText,
                ),
                SizedBox(width: 8.0),
                Text(
                  label,
                  style: FlutterFlowTheme.of(context).titleSmall.override(
                        font: GoogleFonts.cairo(fontWeight: FontWeight.w600),
                        color: selected
                            ? Colors.white
                            : FlutterFlowTheme.of(context).primaryText,
                        fontSize: 15.0,
                        letterSpacing: 0.0,
                      ),
                ),
              ],
            ),
          ),
        ),
      );
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _sectionTitle('جهة الإعلان'),
        Row(
          children: [
            // أنواع العرض المسموحة تتبع التصنيف المختار
            // (الأراضي: بيع وبدل فقط — لا إيجار)
            ...(() {
              final allowed = FFAppConstants
                      .ListingTypesByCategory[_model.propertyType ?? ''] ??
                  const ['sale', 'rent', 'exchange'];
              const icons = {
                'sale': Icons.sell_outlined,
                'rent': Icons.vpn_key_outlined,
                'exchange': Icons.swap_horiz_rounded,
              };
              final out = <Widget>[];
              for (var i = 0; i < allowed.length; i++) {
                if (i > 0) {
                  out.add(SizedBox(width: 8.0));
                }
                final t = allowed[i];
                out.add(option(t, FFAppConstants.ListingTypeLabels[t] ?? t,
                    icons[t] ?? Icons.sell_outlined));
              }
              return out;
            })(),
          ],
        ),
      ],
    );
  }

  // ===== النشر =====

  Future<void> _publish() async {
    if (currentUserReference == null) {
      context.pushNamed(LoginWidget.routeName);
      return;
    }
    if (_model.images.isEmpty && _model.existingImages.isEmpty) {
      await _scrollTo(_imagesAnchor);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('الرجاء إضافة صورة واحدة على الأقل للعقار'),
          backgroundColor: FlutterFlowTheme.of(context).error,
        ),
      );
      return;
    }
    if (_model.propertyType == null || _model.propertyType!.trim().isEmpty) {
      await _scrollTo(_categoryAnchor);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('الرجاء اختيار تصنيف العقار'),
          backgroundColor: FlutterFlowTheme.of(context).error,
        ),
      );
      return;
    }
    // يفعّل التحقق الفوري لبقية الجلسة
    if (!_submitted) safeSetState(() => _submitted = true);
    if (!(_model.formKey.currentState?.validate() ?? false)) {
      // كل الحقول الناقصة صارت حمراء الآن — نمرّر إلى أولها
      final missing = await _scrollToFirstError();
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(missing <= 1
              ? 'يوجد حقل إلزامي ناقص — تم تحديده بالأحمر'
              : 'يوجد $missing حقول إلزامية ناقصة — تم تحديدها بالأحمر'),
          backgroundColor: FlutterFlowTheme.of(context).error,
        ),
      );
      return;
    }

    final price =
        double.tryParse(_model.priceController.text.replaceAll(',', '').trim());
    if (price == null || price <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('الرجاء إدخال سعر صحيح'),
          backgroundColor: FlutterFlowTheme.of(context).error,
        ),
      );
      return;
    }

    safeSetState(() => _model.isUploading = true);
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => Center(child: CircularProgressIndicator()),
    );

    try {
      final imageUrls = <String>[];
      var i = 0;
      // حارس: UID فارغ = جلسة منتهية → المسار users//… وترفضه القاعدة
      // بـ permission-denied مضلّلة. نفشل هنا برسالة صحيحة.
      if (currentUserUid.isEmpty) {
        throw FirebaseException(
          plugin: 'firebase_storage',
          code: 'unauthenticated',
          message: 'انتهت الجلسة — سجّل الدخول ثم أعد المحاولة',
        );
      }
      for (final f in _model.images) {
        if (f.bytes != null && f.bytes!.isNotEmpty) {
          final name =
              f.originalFilename.isEmpty ? 'image_$i.jpg' : f.originalFilename;
          final url = await uploadData(
            'users/$currentUserUid/properties/${DateTime.now().millisecondsSinceEpoch}_$name',
            f.bytes!,
          );
          if (url != null) imageUrls.add(url);
        }
        i++;
      }

      final type = _model.propertyType ?? '';
      final areaName = _model.area ?? '';
      final deposit = double.tryParse(
          _model.depositController.text.replaceAll(',', '').trim());
      final size = _model.sizeController.text.trim();
      final typeLabel = _model.listingType == 'rent'
          ? 'للإيجار'
          : _model.listingType == 'exchange'
              ? 'للبدل'
              : 'للبيع';

      final allImages = [..._model.existingImages, ...imageUrls];
      // لا نحفظ حقول لا تخص هذا التصنيف (مثل الدواوين في محل تجاري)
      int _f(String key, int v) => _catFields.contains(key) ? v : 0;
      bool _b(String key, bool v) => _catFields.contains(key) && v;

      final data = {
        ...createPropertyDataRecordData(
          title: areaName.isEmpty
              ? '$type $typeLabel'
              : '$type $typeLabel - $areaName',
          price: price,
          listingTypy: _model.listingType,
          category: type,
          area: areaName,
          block: _model.blockController.text.trim(),
          street: _model.streetController.text.trim(),
          propertyNumber: _model.numberController.text.trim(),
          rooms: _f('rooms', _model.rooms),
          bathrooms: _f('bathrooms', _model.bathrooms),
          masterRooms: _f('masterRooms', _model.masterRooms),
          kitchens: _f('kitchens', _model.kitchens),
          diwaniyas: _f('diwaniyas', _model.diwaniyas),
          maidRoom: _b('maidRoom', _model.maidRoom),
          laundryRoom: _b('laundryRoom', _model.laundryRoom),
          // تُشتق من المنطقة للتوافق مع الإعلانات القديمة — لا تُختار يدوياً
          governorate: FFAppConstants.governorateOfArea(_model.area) ?? '',
          contactPhone: _model.phoneController.text.trim(),
          // حقول خاصة بأنواع معينة — تُحفظ فقط إن كانت ضمن حقول التصنيف
          units: _catFields.contains('units') ? _model.units : null,
          // عدد الأدوار: يُحفظ إن كان التصنيف يدعمه (كحقل أو كعدّاد)
          floors: (_catFields.contains('floors') ||
                  FFAppConstants.CategoriesWithFloor
                      .contains(_model.propertyType ?? ''))
              ? _model.floors
              : null,
          frontage: _catFields.contains('frontage')
              ? _model.frontageController.text.trim()
              : null,
          // إن تُرك فارغاً نستخدم رقم الهاتف نفسه للواتساب
          whatsappPhone: _model.whatsappController.text.trim().isNotEmpty
              ? _model.whatsappController.text.trim()
              : _model.phoneController.text.trim(),
          // إحداثيات تقريبية من محافظة المنطقة المختارة؛
          // وإن لم تُختر منطقة فمركز الكويت — لا موقع خارج البلد أبداً
          location: () {
            final gov = FFAppConstants.governorateOfArea(_model.area);
            final c = (gov == null ? null : FFAppConstants.GovernorateLatLng[gov]) ??
                FFAppConstants.KuwaitCenter;
            return LatLng(c[0], c[1]);
          }(),
          // النشر مباشر بلا مراجعة إدارية (قرار العميل).
          // الحقل يبقى في القاعدة لأن الاستعلامات وشاشة "إعلاناتي" تستخدمه.
          isApproved: true,
          // دورة حياة الإعلان: 30 يوماً من النشر.
          // expires_at لا يُكتب من العميل — Cloud Function تحسبه من
          // published_at (والقاعدة ترفض كتابته من هنا).
          publishedAt: DateTime.now(),
          isArchived: false,

          ownerRef: currentUserReference,
          description: _model.descController.text.trim(),
          deposit: deposit,
          createdAt: DateTime.now(),
        ),
        'features': _model.selectedFeatures,
        'halls': _f('halls', _model.halls),
        'size': size,
        'images': allImages,
        'propertyImages': allImages,
      };

      try {
        if (widget.property != null) {
          await widget.property!.reference.update(data);
        } else {
          await PropertyDataRecord.collection.doc().set(data);
        }
      } catch (e) {
        // فشل حفظ الإعلان بعد رفع الصور → نحذف الصور المرفوعة للتوّ
        // حتى لا تبقى يتيمة في Storage (كانت تتراكم بلا إعلان).
        for (final url in imageUrls) {
          try {
            await FirebaseStorage.instance.refFromURL(url).delete();
          } catch (_) {}
        }
        rethrow;
      }

      if (context.mounted) {
        Navigator.of(context).pop();
      }
    } catch (e) {
      if (context.mounted) {
        Navigator.of(context).pop();
        final reason = uploadErrorAr(e);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            duration: Duration(seconds: 6),
            content: Text('تعذر نشر العقار — $reason'),
            backgroundColor: FlutterFlowTheme.of(context).error,
          ),
        );
      }
      safeSetState(() => _model.isUploading = false);
      return;
    }

    safeSetState(() => _model.isUploading = false);
    if (!context.mounted) {
      return;
    }
    if (widget.property != null) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('تم حفظ التعديلات بنجاح'),
          backgroundColor: FlutterFlowTheme.of(context).primary,
        ),
      );
      context.safePop();
      return;
    }
    context.pushNamed(AddNewPublishedWidget.routeName);
  }

  @override
  Widget build(BuildContext context) {
    // ترتيب الحقول قد يتغير مع التصنيف — نعيد بناءه في كل build
    _requiredKeys.clear();
    context.watch<FFAppState>();

    return GestureDetector(
      onTap: () {
        FocusScope.of(context).unfocus();
        FocusManager.instance.primaryFocus?.unfocus();
      },
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
        appBar: AppBar(
          backgroundColor: FlutterFlowTheme.of(context).secondaryBackground,
          automaticallyImplyLeading: false,
          leading: InkWell(
            onTap: () => context.safePop(),
            child: Icon(
              Icons.arrow_back_rounded,
              color: FlutterFlowTheme.of(context).primaryText,
              size: 24.0,
            ),
          ),
          title: Text(
            widget.property == null ? 'نشر إعلان عقاري' : 'تعديل الإعلان',
            style: FlutterFlowTheme.of(context).titleMedium.override(
                  font: GoogleFonts.cairo(fontWeight: FontWeight.w600),
                  letterSpacing: 0.0,
                ),
          ),
          centerTitle: true,
          elevation: 0.0,
        ),
        body: SafeArea(
          child: Form(
            key: _model.formKey,
            // بعد أول محاولة نشر فاشلة يتحول التحقق إلى فوري:
            // يختفي التنبيه الأحمر لحظة تعبئة الحقل (البند 5)
            autovalidateMode: _submitted
                ? AutovalidateMode.onUserInteraction
                : AutovalidateMode.disabled,
            child: SingleChildScrollView(
              padding: EdgeInsets.fromLTRB(16.0, 0.0, 16.0, 24.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _photosSection(),
                  _listingTypeSwitch(),
                  _sectionTitle('بيانات العقار'),
                  KeyedSubtree(
                    key: _categoryAnchor,
                    child: _dropdown(
                    label: 'تصنيف العقار',
                    hint: 'اختر تصنيف العقار (إلزامي)',
                    value: _model.propertyType,
                    options: FFAppConstants.PropertyCategories,
                    // القيمة المخزّنة تبقى كما هي؛ الاسم الظاهر يُترجم
                    labelBuilder: FFAppConstants.categoryLabel,
                    onChanged: (v) =>
                        safeSetState(() => _model.propertyType = v),
                  ),
                  ),
                  // مناطق الكويت: قائمة واحدة مسطحة، اختيارية.
                  // لا محافظات — المعلن يقدر يكتب المنطقة في الوصف إن أراد.
                  _dropdown(
                    label: 'مناطق الكويت (اختياري)',
                    hint: 'اختر المنطقة أو اتركها فارغة',
                    value: _model.area,
                    options: FFAppConstants.KuwaitAreas,
                    onChanged: (v) => safeSetState(() => _model.area = v),
                    required: false,
                  ),
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Expanded(
                        child: _textField(
                          label: 'القطعة',
                          hint: 'مثال: 5',
                          controller: _model.blockController,
                          focusNode: _model.blockFocusNode,
                        ),
                      ),
                      SizedBox(width: 10.0),
                      Expanded(
                        child: _textField(
                          label: 'الشارع',
                          hint: 'اسم أو رقم الشارع',
                          controller: _model.streetController,
                          focusNode: _model.streetFocusNode,
                        ),
                      ),
                    ],
                  ),
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Expanded(
                        child: _textField(
                          label: 'رقم العقار',
                          hint: 'اختياري',
                          controller: _model.numberController,
                          focusNode: _model.numberFocusNode,
                        ),
                      ),
                      SizedBox(width: 10.0),
                      Expanded(
                        child: _textField(
                          label: 'المساحة (م²)',
                          hint: 'مثال: 300',
                          controller: _model.sizeController,
                          focusNode: _model.sizeFocusNode,
                          keyboard: TextInputType.number,
                        ),
                      ),
                    ],
                  ),
                  // الحقول تتبع التصنيف المختار — لا تظهر حقول الفلل في
                  // إعلان محل تجاري ولا حقول الأراضي في شاليه.
                  Builder(
                    builder: (context) {
                      final cat = _model.propertyType ?? '';
                      final fields = FFAppConstants.FieldsByCategory[cat] ??
                          const <String>[];
                      if (fields.isEmpty) {
                        return SizedBox.shrink();
                      }
                      return Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          _sectionTitle('تفاصيل العقار'),
                          if (fields.contains('units'))
                            _counter(
                              label: 'عدد الوحدات',
                              value: _model.units,
                              onChanged: (v) => safeSetState(() => _model.units = v),
                            ),
                          if (fields.contains('floors'))
                            _counter(
                              label: 'عدد الأدوار',
                              value: _model.floors,
                              onChanged: (v) => safeSetState(() => _model.floors = v),
                            ),
                          if (fields.contains('masterRooms'))
                            _counter(
                              label: 'عدد غرف الماستر',
                              value: _model.masterRooms,
                              onChanged: (v) =>
                                  safeSetState(() => _model.masterRooms = v),
                            ),
                          if (fields.contains('rooms'))
                            _counter(
                              label: 'عدد الغرف',
                              value: _model.rooms,
                              onChanged: (v) => safeSetState(() => _model.rooms = v),
                            ),
                          if (fields.contains('halls'))
                            _counter(
                              label: 'عدد الصالات',
                              value: _model.halls,
                              onChanged: (v) => safeSetState(() => _model.halls = v),
                            ),
                          if (fields.contains('kitchens'))
                            _counter(
                              label: 'عدد المطابخ',
                              value: _model.kitchens,
                              onChanged: (v) => safeSetState(() => _model.kitchens = v),
                            ),
                          if (fields.contains('diwaniyas'))
                            _counter(
                              label: 'عدد الدواوين',
                              value: _model.diwaniyas,
                              onChanged: (v) => safeSetState(() => _model.diwaniyas = v),
                            ),
                          if (fields.contains('bathrooms'))
                            _counter(
                              label: 'عدد الحمامات',
                              value: _model.bathrooms,
                              onChanged: (v) => safeSetState(() => _model.bathrooms = v),
                            ),
                          if (fields.contains('maidRoom'))
                            _switchTile(
                              label: 'غرفة عاملة منزلية',
                              value: _model.maidRoom,
                              onChanged: (v) => safeSetState(() => _model.maidRoom = v),
                            ),
                          if (fields.contains('laundryRoom'))
                            _switchTile(
                              label: 'غرفة غسيل',
                              value: _model.laundryRoom,
                              onChanged: (v) =>
                                  safeSetState(() => _model.laundryRoom = v),
                            ),
                        if (fields.contains('frontage'))
                            _textField(
                              label: 'عرض الواجهة (متر)',
                              hint: 'مثال: 8',
                              controller: _model.frontageController,
                              focusNode: _model.frontageFocusNode,
                              keyboard: TextInputType.number,
                            ),
                        ],
                      );
                    },
                  ),
                  _sectionTitle('السعر'),
                  _textField(
                    label: _model.listingType == 'rent'
                        ? 'الإيجار الشهري (د.ك)'
                        : _model.listingType == 'exchange'
                            ? 'القيمة التقديرية (د.ك)'
                            : 'سعر البيع (د.ك)',
                    hint: 'مثال: 350',
                    controller: _model.priceController,
                    required: true,
                    focusNode: _model.priceFocusNode,
                    keyboard: TextInputType.number,
                    validator: (v) => (v == null || v.trim().isEmpty)
                        ? 'السعر مطلوب'
                        : null,
                  ),
                  if (_model.listingType == 'rent')
                    _textField(
                      label: 'مبلغ التأمين (د.ك) — اختياري',
                      hint: 'اتركه فارغاً إن لم يوجد',
                      controller: _model.depositController,
                      focusNode: _model.depositFocusNode,
                      keyboard: TextInputType.number,
                    ),
                  _sectionTitle('رقم التواصل'),
                  _textField(
                    label: 'رقم الهاتف للتواصل',
                    required: true,
                    hint: 'مثال: 9xxxxxxx',
                    controller: _model.phoneController,
                    focusNode: _model.phoneFocusNode,
                    keyboard: TextInputType.phone,
                    validator: (v) => (v == null || v.trim().length < 8)
                        ? 'الرجاء إدخال رقم هاتف صحيح للتواصل'
                        : null,
                  ),
                  _textField(
                    label: 'رقم الواتساب (اختياري)',
                    hint: 'اتركه فارغاً لاستخدام رقم الهاتف نفسه',
                    controller: _model.whatsappController,
                    focusNode: _model.whatsappFocusNode,
                    keyboard: TextInputType.phone,
                    validator: (v) {
                      final t = (v ?? '').trim();
                      if (t.isEmpty) return null; // اختياري
                      return t.length < 8 ? 'رقم واتساب غير صحيح' : null;
                    },
                  ),
                  _sectionTitle('مميزات العقار (اختياري)'),
                  Padding(
                    padding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 14.0),
                    child: Wrap(
                      spacing: 8.0,
                      runSpacing: 8.0,
                      children: ((FFAppConstants
                                  .FeaturesByCategory[_model.propertyType ?? ''] ??
                              FFAppConstants.PropertyFeatures))
                          .map((f) {
                        final sel = _model.selectedFeatures.contains(f);
                        return InkWell(
                          splashColor: Colors.transparent,
                          focusColor: Colors.transparent,
                          hoverColor: Colors.transparent,
                          highlightColor: Colors.transparent,
                          onTap: () => safeSetState(() {
                            if (sel) {
                              _model.selectedFeatures.remove(f);
                            } else {
                              _model.selectedFeatures.add(f);
                            }
                          }),
                          child: Container(
                            padding: EdgeInsets.symmetric(
                                horizontal: 14.0, vertical: 9.0),
                            decoration: BoxDecoration(
                              color: sel
                                  ? FlutterFlowTheme.of(context).primary
                                  : FlutterFlowTheme.of(context)
                                      .secondaryBackground,
                              borderRadius: BorderRadius.circular(10.0),
                              border: Border.all(
                                color: sel
                                    ? FlutterFlowTheme.of(context).primary
                                    : FlutterFlowTheme.of(context).alternate,
                              ),
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Icon(
                                  sel
                                      ? Icons.check_circle_rounded
                                      : Icons.add_circle_outline_rounded,
                                  size: 16.0,
                                  color: sel
                                      ? Colors.white
                                      : FlutterFlowTheme.of(context)
                                          .secondaryText,
                                ),
                                SizedBox(width: 6.0),
                                Text(
                                  f,
                                  style: FlutterFlowTheme.of(context)
                                      .bodyMedium
                                      .override(
                                        font: GoogleFonts.cairo(
                                            fontWeight: sel
                                                ? FontWeight.w600
                                                : FontWeight.normal),
                                        color: sel
                                            ? Colors.white
                                            : FlutterFlowTheme.of(context)
                                                .primaryText,
                                        letterSpacing: 0.0,
                                      ),
                                ),
                              ],
                            ),
                          ),
                        );
                      }).toList(),
                    ),
                  ),
                  _sectionTitle('وصف العقار'),
                  _textField(
                    label: 'اكتب وصفاً واضحاً يساعد الباحثين',
                    required: true,
                    hint:
                        'مثال: شقة مجددة بالكامل، قريبة من الخدمات والمدارس، مدخل مستقل...',
                    controller: _model.descController,
                    focusNode: _model.descFocusNode,
                    maxLines: 5,
                    validator: (v) => (v == null || v.trim().length < 10)
                        ? 'الرجاء كتابة وصف لا يقل عن 10 أحرف'
                        : null,
                  ),
                  SizedBox(height: 10.0),
                  FFButtonWidget(
                    onPressed: _model.isUploading ? null : () => _publish(),
                    text: widget.property == null
                        ? 'نشر الإعلان'
                        : 'حفظ التعديلات',
                    options: FFButtonOptions(
                      width: double.infinity,
                      height: 52.0,
                      padding: EdgeInsets.zero,
                      iconPadding: EdgeInsets.zero,
                      color: FlutterFlowTheme.of(context).primary,
                      textStyle: FlutterFlowTheme.of(context)
                          .titleSmall
                          .override(
                            font: GoogleFonts.cairo(fontWeight: FontWeight.w600),
                            color: Colors.white,
                            fontSize: 16.0,
                            letterSpacing: 0.0,
                          ),
                      elevation: 0.0,
                      borderRadius: BorderRadius.circular(14.0),
                    ),
                    showLoadingIndicator: false,
                  ),
                  SizedBox(height: 10.0),
                  Text(
                    widget.property == null
                        ? 'سيظهر إعلانك مباشرة في قائمة الإعلانات'
                        : 'ستظهر التعديلات مباشرة للمستخدمين',
                    textAlign: TextAlign.center,
                    style: FlutterFlowTheme.of(context).bodySmall.override(
                          font: GoogleFonts.cairo(),
                          color: FlutterFlowTheme.of(context).secondaryText,
                          letterSpacing: 0.0,
                        ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
