import 'dart:async';

import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:page_transition/page_transition.dart';
import 'package:provider/provider.dart';
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';

import '/auth/base_auth_user_provider.dart';

import '/main.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/lat_lng.dart';
import '/flutter_flow/place.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'serialization_util.dart';

import '/index.dart';

export 'package:go_router/go_router.dart';
export 'serialization_util.dart';

const kTransitionInfoKey = '__transition_info__';

GlobalKey<NavigatorState> appNavigatorKey = GlobalKey<NavigatorState>();

class AppStateNotifier extends ChangeNotifier {
  AppStateNotifier._();

  static AppStateNotifier? _instance;
  static AppStateNotifier get instance => _instance ??= AppStateNotifier._();

  BaseAuthUser? initialUser;
  BaseAuthUser? user;
  bool showSplashImage = true;
  String? _redirectLocation;

  /// Determines whether the app will refresh and build again when a sign
  /// in or sign out happens. This is useful when the app is launched or
  /// on an unexpected logout. However, this must be turned off when we
  /// intend to sign in/out and then navigate or perform any actions after.
  /// Otherwise, this will trigger a refresh and interrupt the action(s).
  bool notifyOnAuthChange = true;

  bool get loading => user == null || showSplashImage;
  bool get loggedIn => user?.loggedIn ?? false;
  bool get initiallyLoggedIn => initialUser?.loggedIn ?? false;
  bool get shouldRedirect => loggedIn && _redirectLocation != null;

  String getRedirectLocation() => _redirectLocation!;
  bool hasRedirect() => _redirectLocation != null;
  void setRedirectLocationIfUnset(String loc) => _redirectLocation ??= loc;
  void clearRedirectLocation() => _redirectLocation = null;

  /// Mark as not needing to notify on a sign in / out when we intend
  /// to perform subsequent actions (such as navigation) afterwards.
  void updateNotifyOnAuthChange(bool notify) => notifyOnAuthChange = notify;

  void update(BaseAuthUser newUser) {
    final shouldUpdate =
        user?.uid == null || newUser.uid == null || user?.uid != newUser.uid;
    initialUser ??= newUser;
    user = newUser;
    // Refresh the app on auth change unless explicitly marked otherwise.
    // No need to update unless the user has changed.
    if (notifyOnAuthChange && shouldUpdate) {
      notifyListeners();
    }
    // Once again mark the notifier as needing to update on auth change
    // (in order to catch sign in / out events).
    updateNotifyOnAuthChange(true);
  }

  void stopShowingSplashImage() {
    showSplashImage = false;
    notifyListeners();
  }
}

GoRouter createRouter(AppStateNotifier appStateNotifier) => GoRouter(
      initialLocation: '/',
      debugLogDiagnostics: true,
      refreshListenable: appStateNotifier,
      navigatorKey: appNavigatorKey,
      errorBuilder: (context, state) => HomeWidget(),
      routes: [
        FFRoute(
          name: '_initialize',
          path: '/',
          builder: (context, _) => HomeWidget(),
        ),
        FFRoute(
          name: HomeWidget.routeName,
          path: HomeWidget.routePath,
          builder: (context, params) => HomeWidget(
            fromRegister: params.getParam(
              'fromRegister',
              ParamType.bool,
            ),
          ),
        ),
        FFRoute(
          name: MessagesWidget.routeName,
          path: MessagesWidget.routePath,
          requireAuth: true,
          builder: (context, params) => MessagesWidget(),
        ),
        FFRoute(
          name: BlogWidget.routeName,
          path: BlogWidget.routePath,
          builder: (context, params) => BlogWidget(),
        ),
        FFRoute(
          name: AAProfileWidget.routeName,
          path: AAProfileWidget.routePath,
          requireAuth: true,
          builder: (context, params) => AAProfileWidget(),
        ),
        FFRoute(
          name: LoginWidget.routeName,
          path: LoginWidget.routePath,
          builder: (context, params) => LoginWidget(),
        ),
        FFRoute(
          name: HelpCenterWidget.routeName,
          path: HelpCenterWidget.routePath,
          builder: (context, params) => HelpCenterWidget(),
        ),
        FFRoute(
          name: HelpCenterFAQWidget.routeName,
          path: HelpCenterFAQWidget.routePath,
          builder: (context, params) => HelpCenterFAQWidget(),
        ),
        FFRoute(
          name: HelpCenterSupportWidget.routeName,
          path: HelpCenterSupportWidget.routePath,
          builder: (context, params) => HelpCenterSupportWidget(),
        ),
        FFRoute(
          name: HelpCenterPrivacyWidget.routeName,
          path: HelpCenterPrivacyWidget.routePath,
          builder: (context, params) => HelpCenterPrivacyWidget(),
        ),
        FFRoute(
          name: HelpCenterTermsWidget.routeName,
          path: HelpCenterTermsWidget.routePath,
          builder: (context, params) => HelpCenterTermsWidget(),
        ),
        FFRoute(
          name: NotificationsWidget.routeName,
          path: NotificationsWidget.routePath,
          requireAuth: true,
          builder: (context, params) => NotificationsWidget(),
        ),
        FFRoute(
          name: LanguagesWidget.routeName,
          path: LanguagesWidget.routePath,
          builder: (context, params) => LanguagesWidget(),
        ),
        FFRoute(
          name: PaymentWidget.routeName,
          path: PaymentWidget.routePath,
          builder: (context, params) => PaymentWidget(),
        ),
        FFRoute(
          name: SecurityWidget.routeName,
          path: SecurityWidget.routePath,
          requireAuth: true,
          builder: (context, params) => SecurityWidget(),
        ),
        FFRoute(
          name: VAppearanceWidget.routeName,
          path: VAppearanceWidget.routePath,
          builder: (context, params) => VAppearanceWidget(),
        ),
        FFRoute(
          name: AboutHouzyWidget.routeName,
          path: AboutHouzyWidget.routePath,
          builder: (context, params) => AboutHouzyWidget(),
        ),
        FFRoute(
          name: InviteFriendsWidget.routeName,
          path: InviteFriendsWidget.routePath,
          builder: (context, params) => InviteFriendsWidget(),
        ),
        FFRoute(
          name: AccountInformationWidget.routeName,
          path: AccountInformationWidget.routePath,
          requireAuth: true,
          builder: (context, params) => AccountInformationWidget(),
        ),
        FFRoute(
          name: LoginEmailWidget.routeName,
          path: LoginEmailWidget.routePath,
          builder: (context, params) => LoginEmailWidget(),
        ),
        FFRoute(
          name: RegisterWidget.routeName,
          path: RegisterWidget.routePath,
          builder: (context, params) => RegisterWidget(),
        ),
        FFRoute(
          name: ForgotPasswordWidget.routeName,
          path: ForgotPasswordWidget.routePath,
          builder: (context, params) => ForgotPasswordWidget(),
        ),
        FFRoute(
          name: ForgotPassword2Widget.routeName,
          path: ForgotPassword2Widget.routePath,
          builder: (context, params) => ForgotPassword2Widget(),
        ),
        FFRoute(
          name: ForgotPassword3Widget.routeName,
          path: ForgotPassword3Widget.routePath,
          builder: (context, params) => ForgotPassword3Widget(),
        ),
        FFRoute(
          name: PropertyRequestsListWidget.routeName,
          path: PropertyRequestsListWidget.routePath,
          requireAuth: true,
          builder: (context, params) => PropertyRequestsListWidget(),
        ),
        FFRoute(
          name: PropertyRequestWidget.routeName,
          path: PropertyRequestWidget.routePath,
          requireAuth: true,
          builder: (context, params) => PropertyRequestWidget(
            governorate: params.getParam(
              'governorate',
              ParamType.String,
            ),
          ),
        ),
        FFRoute(
          name: AddNewWidget.routeName,
          path: AddNewWidget.routePath,
          requireAuth: true,
          asyncParams: {
            'property':
                getDoc(['PropertyData'], PropertyDataRecord.fromSnapshot),
          },
          builder: (context, params) => AddNewWidget(
            property: params.getParam(
              'property',
              ParamType.Document,
            ),
          ),
        ),
        FFRoute(
          name: SingleBlogWidget.routeName,
          path: SingleBlogWidget.routePath,
          builder: (context, params) => SingleBlogWidget(
            data: params.getParam(
              'data',
              ParamType.DataStruct,
              isList: false,
              structBuilder: ArticlesStruct.fromSerializableMap,
            ),
          ),
        ),
        FFRoute(
          name: BlogsAllWidget.routeName,
          path: BlogsAllWidget.routePath,
          builder: (context, params) => BlogsAllWidget(),
        ),
        FFRoute(
          name: SingleMessageWidget.routeName,
          path: SingleMessageWidget.routePath,
          requireAuth: true,
          builder: (context, params) => SingleMessageWidget(
            data: params.getParam(
              'data',
              ParamType.DataStruct,
              isList: false,
              structBuilder: UsersStruct.fromSerializableMap,
            ),
            chatRef: params.getParam(
              'chatRef',
              ParamType.DocumentReference,
              isList: false,
              collectionNamePath: ['chats'],
            ),
          ),
        ),
        FFRoute(
          name: MessageSearchWidget.routeName,
          path: MessageSearchWidget.routePath,
          requireAuth: true,
          builder: (context, params) => MessageSearchWidget(),
        ),
        FFRoute(
          name: SavedMessagesWidget.routeName,
          path: SavedMessagesWidget.routePath,
          requireAuth: true,
          builder: (context, params) => SavedMessagesWidget(),
        ),
        FFRoute(
          name: NotificatiosWidget.routeName,
          path: NotificatiosWidget.routePath,
          builder: (context, params) => NotificatiosWidget(),
        ),
        FFRoute(
          name: SimpleCalendarWidget.routeName,
          path: SimpleCalendarWidget.routePath,
          builder: (context, params) => SimpleCalendarWidget(),
        ),
        FFRoute(
          name: ReasonForBlockWidget.routeName,
          path: ReasonForBlockWidget.routePath,
          builder: (context, params) => ReasonForBlockWidget(),
        ),
        FFRoute(
          name: UserReviewWidget.routeName,
          path: UserReviewWidget.routePath,
          builder: (context, params) => UserReviewWidget(),
        ),
        FFRoute(
          name: SingleApartmentWidget.routeName,
          path: SingleApartmentWidget.routePath,
          asyncParams: {
            'data': getDoc(['PropertyData'], PropertyDataRecord.fromSnapshot),
          },
          builder: (context, params) => SingleApartmentWidget(
            data: params.getParam(
              'data',
              ParamType.Document,
            ),
          ),
        ),
        FFRoute(
          name: SearchArchiveWidget.routeName,
          path: SearchArchiveWidget.routePath,
          builder: (context, params) => SearchArchiveWidget(
            category: params.getParam(
              'category',
              ParamType.String,
            ),
          ),
        ),
        FFRoute(
          name: SingleApartment4Widget.routeName,
          path: SingleApartment4Widget.routePath,
          builder: (context, params) => SingleApartment4Widget(),
        ),
        FFRoute(
          name: BlogSearchWidget.routeName,
          path: BlogSearchWidget.routePath,
          builder: (context, params) => BlogSearchWidget(),
        ),
        FFRoute(
          name: PaymentAddCardWidget.routeName,
          path: PaymentAddCardWidget.routePath,
          builder: (context, params) => PaymentAddCardWidget(),
        ),
        FFRoute(
          name: QuestionsAnswersWidget.routeName,
          path: QuestionsAnswersWidget.routePath,
          builder: (context, params) => QuestionsAnswersWidget(),
        ),
        FFRoute(
          name: SingleGuidesWidget.routeName,
          path: SingleGuidesWidget.routePath,
          builder: (context, params) => SingleGuidesWidget(),
        ),
        FFRoute(
          name: VBlockedUsersWidget.routeName,
          path: VBlockedUsersWidget.routePath,
          builder: (context, params) => VBlockedUsersWidget(),
        ),
        FFRoute(
          name: FavoritesWidget.routeName,
          path: FavoritesWidget.routePath,
          requireAuth: true,
          builder: (context, params) => FavoritesWidget(),
        ),
        FFRoute(
          name: SingleApartment2Widget.routeName,
          path: SingleApartment2Widget.routePath,
          builder: (context, params) => SingleApartment2Widget(),
        ),
        FFRoute(
          name: SingleApartment3Widget.routeName,
          path: SingleApartment3Widget.routePath,
          builder: (context, params) => SingleApartment3Widget(),
        ),
        FFRoute(
          name: ReportApartmentWidget.routeName,
          path: ReportApartmentWidget.routePath,
          builder: (context, params) => ReportApartmentWidget(),
        ),
        FFRoute(
          name: SingleApartment5Widget.routeName,
          path: SingleApartment5Widget.routePath,
          builder: (context, params) => SingleApartment5Widget(),
        ),
        FFRoute(
          name: SingleApartment6Widget.routeName,
          path: SingleApartment6Widget.routePath,
          builder: (context, params) => SingleApartment6Widget(),
        ),
        FFRoute(
          name: SearchArchiveFilterWidget.routeName,
          path: SearchArchiveFilterWidget.routePath,
          builder: (context, params) => SearchArchiveFilterWidget(),
        ),
        FFRoute(
          name: RealtorsWidget.routeName,
          path: RealtorsWidget.routePath,
          builder: (context, params) => RealtorsWidget(),
        ),
        FFRoute(
          name: RealtorsSearchWidget.routeName,
          path: RealtorsSearchWidget.routePath,
          builder: (context, params) => RealtorsSearchWidget(),
        ),
        FFRoute(
          name: RealtorsSingleWidget.routeName,
          path: RealtorsSingleWidget.routePath,
          asyncParams: {
            'data': getDoc(['Realtors'], RealtorsRecord.fromSnapshot),
          },
          builder: (context, params) => RealtorsSingleWidget(
            data: params.getParam(
              'data',
              ParamType.Document,
            ),
          ),
        ),
        FFRoute(
          name: RealtorsSingleReviewsWidget.routeName,
          path: RealtorsSingleReviewsWidget.routePath,
          builder: (context, params) => RealtorsSingleReviewsWidget(),
        ),
        FFRoute(
          name: RealtorsSingleCerteficatesWidget.routeName,
          path: RealtorsSingleCerteficatesWidget.routePath,
          builder: (context, params) => RealtorsSingleCerteficatesWidget(),
        ),
        FFRoute(
          name: VContactAgentWidget.routeName,
          path: VContactAgentWidget.routePath,
          requireAuth: true,
          builder: (context, params) => VContactAgentWidget(
            realtorRef: params.getParam(
              'realtorRef',
              ParamType.DocumentReference,
              isList: false,
              collectionNamePath: ['Realtors'],
            ),
          ),
        ),
        FFRoute(
          name: MessageWithAgentWidget.routeName,
          path: MessageWithAgentWidget.routePath,
          asyncParams: {
            'realtor': getDoc(['Realtors'], RealtorsRecord.fromSnapshot),
          },
          builder: (context, params) => MessageWithAgentWidget(
            realtor: params.getParam(
              'realtor',
              ParamType.Document,
            ),
          ),
        ),
        FFRoute(
          name: AddNewPublishedWidget.routeName,
          path: AddNewPublishedWidget.routePath,
          requireAuth: true,
          builder: (context, params) => AddNewPublishedWidget(),
        ),
        FFRoute(
          name: AllPropertiesWidget.routeName,
          path: AllPropertiesWidget.routePath,
          requireAuth: true,
          builder: (context, params) => AllPropertiesWidget(
            fromAddNew: params.getParam(
              'fromAddNew',
              ParamType.bool,
            ),
          ),
        ),
        FFRoute(
          name: AccountInformation2Widget.routeName,
          path: AccountInformation2Widget.routePath,
          requireAuth: true,
          builder: (context, params) => AccountInformation2Widget(),
        ),
        FFRoute(
          name: ReportRealtorWidget.routeName,
          path: ReportRealtorWidget.routePath,
          builder: (context, params) => ReportRealtorWidget(),
        )
      ].map((r) => r.toRoute(appStateNotifier)).toList(),
    );

extension NavParamExtensions on Map<String, String?> {
  Map<String, String> get withoutNulls => Map.fromEntries(
        entries
            .where((e) => e.value != null)
            .map((e) => MapEntry(e.key, e.value!)),
      );
}

extension NavigationExtensions on BuildContext {
  void goNamedAuth(
    String name,
    bool mounted, {
    Map<String, String> pathParameters = const <String, String>{},
    Map<String, String> queryParameters = const <String, String>{},
    Object? extra,
    bool ignoreRedirect = false,
  }) =>
      !mounted || GoRouter.of(this).shouldRedirect(ignoreRedirect)
          ? null
          : goNamed(
              name,
              pathParameters: pathParameters,
              queryParameters: queryParameters,
              extra: extra,
            );

  void pushNamedAuth(
    String name,
    bool mounted, {
    Map<String, String> pathParameters = const <String, String>{},
    Map<String, String> queryParameters = const <String, String>{},
    Object? extra,
    bool ignoreRedirect = false,
  }) =>
      !mounted || GoRouter.of(this).shouldRedirect(ignoreRedirect)
          ? null
          : pushNamed(
              name,
              pathParameters: pathParameters,
              queryParameters: queryParameters,
              extra: extra,
            );

  void safePop() {
    // If there is only one route on the stack, navigate to the initial
    // page instead of popping.
    if (canPop()) {
      pop();
    } else {
      go('/');
    }
  }
}

extension GoRouterExtensions on GoRouter {
  AppStateNotifier get appState => AppStateNotifier.instance;
  void prepareAuthEvent([bool ignoreRedirect = false]) =>
      appState.hasRedirect() && !ignoreRedirect
          ? null
          : appState.updateNotifyOnAuthChange(false);
  bool shouldRedirect(bool ignoreRedirect) =>
      !ignoreRedirect && appState.hasRedirect();
  void clearRedirectLocation() => appState.clearRedirectLocation();
  void setRedirectLocationIfUnset(String location) =>
      appState.updateNotifyOnAuthChange(false);
}

extension _GoRouterStateExtensions on GoRouterState {
  Map<String, dynamic> get extraMap =>
      extra != null ? extra as Map<String, dynamic> : {};
  Map<String, dynamic> get allParams => <String, dynamic>{}
    ..addAll(pathParameters)
    ..addAll(uri.queryParameters)
    ..addAll(extraMap);
  TransitionInfo get transitionInfo => extraMap.containsKey(kTransitionInfoKey)
      ? extraMap[kTransitionInfoKey] as TransitionInfo
      : TransitionInfo.appDefault();
}

class FFParameters {
  FFParameters(this.state, [this.asyncParams = const {}]);

  final GoRouterState state;
  final Map<String, Future<dynamic> Function(String)> asyncParams;

  Map<String, dynamic> futureParamValues = {};

  // Parameters are empty if the params map is empty or if the only parameter
  // present is the special extra parameter reserved for the transition info.
  bool get isEmpty =>
      state.allParams.isEmpty ||
      (state.allParams.length == 1 &&
          state.extraMap.containsKey(kTransitionInfoKey));
  bool isAsyncParam(MapEntry<String, dynamic> param) =>
      asyncParams.containsKey(param.key) && param.value is String;
  bool get hasFutures => state.allParams.entries.any(isAsyncParam);
  Future<bool> completeFutures() => Future.wait(
        state.allParams.entries.where(isAsyncParam).map(
          (param) async {
            final doc = await asyncParams[param.key]!(param.value)
                .onError((_, __) => null);
            if (doc != null) {
              futureParamValues[param.key] = doc;
              return true;
            }
            return false;
          },
        ),
      ).onError((_, __) => [false]).then((v) => v.every((e) => e));

  dynamic getParam<T>(
    String paramName,
    ParamType type, {
    bool isList = false,
    List<String>? collectionNamePath,
    StructBuilder<T>? structBuilder,
  }) {
    if (futureParamValues.containsKey(paramName)) {
      return futureParamValues[paramName];
    }
    if (!state.allParams.containsKey(paramName)) {
      return null;
    }
    final param = state.allParams[paramName];
    // Got parameter from `extras`, so just directly return it.
    if (param is! String) {
      return param;
    }
    // Return serialized value.
    return deserializeParam<T>(
      param,
      type,
      isList,
      collectionNamePath: collectionNamePath,
      structBuilder: structBuilder,
    );
  }
}

class FFRoute {
  const FFRoute({
    required this.name,
    required this.path,
    required this.builder,
    this.requireAuth = false,
    this.asyncParams = const {},
    this.routes = const [],
  });

  final String name;
  final String path;
  final bool requireAuth;
  final Map<String, Future<dynamic> Function(String)> asyncParams;
  final Widget Function(BuildContext, FFParameters) builder;
  final List<GoRoute> routes;

  GoRoute toRoute(AppStateNotifier appStateNotifier) => GoRoute(
        name: name,
        path: path,
        redirect: (context, state) {
          if (appStateNotifier.shouldRedirect) {
            final redirectLocation = appStateNotifier.getRedirectLocation();
            appStateNotifier.clearRedirectLocation();
            return redirectLocation;
          }

          if (requireAuth && !appStateNotifier.loggedIn) {
            appStateNotifier.setRedirectLocationIfUnset(state.uri.toString());
            return LoginWidget.routePath;
          }
          return null;
        },
        pageBuilder: (context, state) {
          fixStatusBarOniOS16AndBelow(context);
          final ffParams = FFParameters(state, asyncParams);
          final page = ffParams.hasFutures
              ? FutureBuilder(
                  future: ffParams.completeFutures(),
                  builder: (context, _) => builder(context, ffParams),
                )
              : builder(context, ffParams);
          final child = appStateNotifier.loading
              ? Builder(
                  builder: (context) {
                    // افتتاحية التطبيق: التصميم الكامل يغطي الشاشة.
                    //
                    // BoxFit.cover يملأ الشاشة بلا تمديد ولا تشويه — يقتطع
                    // الفائض فقط. لون الخلفية مطابق لأعلى الصميم (#EADED0)
                    // فلا يظهر أي إطار أبيض في أي لحظة.
                    //
                    // المحاذاة مرفوعة قليلاً لأعلى (-0.3): على الجوالات
                    // (نسبة ~0.46) الصورة تنطبق تقريباً تماماً، وعلى الشاشات
                    // العريضة (تابلت) يُقتطع الأسفل بدل أن يُقص الشعار.
                    return Container(
                      color: const Color(0xFFEADED0),
                      child: SizedBox.expand(
                        child: Image.asset(
                          'assets/images/splash_bg.png',
                          fit: BoxFit.cover,
                          alignment: const Alignment(0.0, -0.3),
                          filterQuality: FilterQuality.medium,
                        ),
                      ),
                    );
                  },
                )
              : page;

          final transitionInfo = state.transitionInfo;
          return transitionInfo.hasTransition
              ? CustomTransitionPage(
                  key: state.pageKey,
                  name: state.name,
                  child: child,
                  transitionDuration: transitionInfo.duration,
                  transitionsBuilder:
                      (context, animation, secondaryAnimation, child) =>
                          PageTransition(
                    type: transitionInfo.transitionType,
                    duration: transitionInfo.duration,
                    reverseDuration: transitionInfo.duration,
                    alignment: transitionInfo.alignment,
                    child: child,
                  ).buildTransitions(
                    context,
                    animation,
                    secondaryAnimation,
                    child,
                  ),
                )
              : MaterialPage(
                  key: state.pageKey, name: state.name, child: child);
        },
        routes: routes,
      );
}

class TransitionInfo {
  const TransitionInfo({
    required this.hasTransition,
    this.transitionType = PageTransitionType.fade,
    this.duration = const Duration(milliseconds: 300),
    this.alignment,
  });

  final bool hasTransition;
  final PageTransitionType transitionType;
  final Duration duration;
  final Alignment? alignment;

  static TransitionInfo appDefault() => TransitionInfo(hasTransition: false);
}

class RootPageContext {
  const RootPageContext(this.isRootPage, [this.errorRoute]);
  final bool isRootPage;
  final String? errorRoute;

  static bool isInactiveRootPage(BuildContext context) {
    final rootPageContext = context.read<RootPageContext?>();
    final isRootPage = rootPageContext?.isRootPage ?? false;
    final location = GoRouterState.of(context).uri.toString();
    return isRootPage &&
        location != '/' &&
        location != rootPageContext?.errorRoute;
  }

  static Widget wrap(Widget child, {String? errorRoute}) => Provider.value(
        value: RootPageContext(true, errorRoute),
        child: child,
      );
}

extension GoRouterLocationExtension on GoRouter {
  String getCurrentLocation() {
    final RouteMatch lastMatch = routerDelegate.currentConfiguration.last;
    final RouteMatchList matchList = lastMatch is ImperativeRouteMatch
        ? lastMatch.matches
        : routerDelegate.currentConfiguration;
    return matchList.uri.toString();
  }
}
