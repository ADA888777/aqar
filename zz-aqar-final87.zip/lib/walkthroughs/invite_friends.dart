import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:tutorial_coach_mark/tutorial_coach_mark.dart';

import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';

final buttonB1gbgg8h = GlobalKey();

Widget _tipCard(BuildContext context, String text) => Container(
      margin: EdgeInsets.symmetric(horizontal: 24.0, vertical: 12.0),
      padding: EdgeInsets.all(16.0),
      decoration: BoxDecoration(
        color: FlutterFlowTheme.of(context).secondaryBackground,
        borderRadius: BorderRadius.circular(14.0),
      ),
      child: Text(
        text,
        textAlign: TextAlign.center,
        style: FlutterFlowTheme.of(context).bodyMedium.override(
              font: GoogleFonts.cairo(),
              letterSpacing: 0.0,
            ),
      ),
    );

List<TargetFocus> createWalkthroughTargets(BuildContext context) => [
      TargetFocus(
        keyTarget: buttonB1gbgg8h,
        enableOverlayTab: true,
        alignSkip: Alignment.bottomRight,
        shape: ShapeLightFocus.Circle,
        color: Colors.black,
        contents: [
          TargetContent(
            align: ContentAlign.bottom,
            builder: (context, __) =>
                _tipCard(context, 'اضغط هنا لنسخ رابط التطبيق ومشاركته مع أصدقائك'),
          ),
        ],
      ),
    ];
