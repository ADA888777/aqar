import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'dialog_delete_from_search_widget.dart'
    show DialogDeleteFromSearchWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class DialogDeleteFromSearchModel
    extends FlutterFlowModel<DialogDeleteFromSearchWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
