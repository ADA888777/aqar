import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'empty_list1_widget.dart' show EmptyList1Widget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:lottie/lottie.dart';
import 'package:provider/provider.dart';

class EmptyList1Model extends FlutterFlowModel<EmptyList1Widget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
