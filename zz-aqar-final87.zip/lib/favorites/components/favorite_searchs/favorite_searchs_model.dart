import '/favorites/components/dialog_delete_from_search/dialog_delete_from_search_widget.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'favorite_searchs_widget.dart' show FavoriteSearchsWidget;
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class FavoriteSearchsModel extends FlutterFlowModel<FavoriteSearchsWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
