import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'empty_list_realtors_widget.dart' show EmptyListRealtorsWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:lottie/lottie.dart';
import 'package:provider/provider.dart';

class EmptyListRealtorsModel extends FlutterFlowModel<EmptyListRealtorsWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
