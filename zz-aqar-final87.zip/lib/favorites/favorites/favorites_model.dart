import '/backend/backend.dart';
import '/favorites/components/empty_list1/empty_list1_widget.dart';
import '/favorites/components/favorite_searchs/favorite_searchs_widget.dart';
import '/favorites/components/favorites_options/favorites_options_widget.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/home/components/property_card/property_card_widget.dart';
import '/realtors/components/realtor_card/realtor_card_widget.dart';
import 'dart:ui';
import '/index.dart';
import 'favorites_widget.dart' show FavoritesWidget;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class FavoritesModel extends FlutterFlowModel<FavoritesWidget> {
  ///  State fields for stateful widgets in this page.

  // Models for PropertyCard dynamic component.
  late FlutterFlowDynamicModels<PropertyCardModel> propertyCardModels;
  // Models for FavoriteSearchs dynamic component.
  late FlutterFlowDynamicModels<FavoriteSearchsModel> favoriteSearchsModels;
  // Models for RealtorCard dynamic component.
  late FlutterFlowDynamicModels<RealtorCardModel> realtorCardModels;

  @override
  void initState(BuildContext context) {
    propertyCardModels = FlutterFlowDynamicModels(() => PropertyCardModel());
    favoriteSearchsModels =
        FlutterFlowDynamicModels(() => FavoriteSearchsModel());
    realtorCardModels = FlutterFlowDynamicModels(() => RealtorCardModel());
  }

  @override
  void dispose() {
    propertyCardModels.dispose();
    favoriteSearchsModels.dispose();
    realtorCardModels.dispose();
  }
}
