import '/backend/schema/structs/index.dart';
import '/blog/components/card1/card1_widget.dart';
import '/blog/components/card2/card2_widget.dart';
import '/blog/components/categories_blog/categories_blog_widget.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import '/index.dart';
import 'blog_widget.dart' show BlogWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class BlogModel extends FlutterFlowModel<BlogWidget> {
  ///  State fields for stateful widgets in this page.

  // Models for Card1 dynamic component.
  late FlutterFlowDynamicModels<Card1Model> card1Models;
  // Model for CategoriesBlog component.
  late CategoriesBlogModel categoriesBlogModel;
  // Models for Card2 dynamic component.
  late FlutterFlowDynamicModels<Card2Model> card2Models;

  @override
  void initState(BuildContext context) {
    card1Models = FlutterFlowDynamicModels(() => Card1Model());
    categoriesBlogModel = createModel(context, () => CategoriesBlogModel());
    card2Models = FlutterFlowDynamicModels(() => Card2Model());
  }

  @override
  void dispose() {
    card1Models.dispose();
    categoriesBlogModel.dispose();
    card2Models.dispose();
  }
}
