import '/backend/schema/structs/index.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'questions_answers_widget.dart' show QuestionsAnswersWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class QuestionsAnswersModel extends FlutterFlowModel<QuestionsAnswersWidget> {
  ///  Local state fields for this page.

  int selected = 0;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
