import '/backend/schema/structs/index.dart';
import '/blog/components/card2/card2_widget.dart';
import '/blog/components/categories_blog/categories_blog_widget.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import '/index.dart';
import 'blogs_all_widget.dart' show BlogsAllWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class BlogsAllModel extends FlutterFlowModel<BlogsAllWidget> {
  ///  State fields for stateful widgets in this page.

  // Model for CategoriesBlog component.
  late CategoriesBlogModel categoriesBlogModel;
  // Models for Card2 dynamic component.
  late FlutterFlowDynamicModels<Card2Model> card2Models;

  @override
  void initState(BuildContext context) {
    categoriesBlogModel = createModel(context, () => CategoriesBlogModel());
    card2Models = FlutterFlowDynamicModels(() => Card2Model());
  }

  @override
  void dispose() {
    categoriesBlogModel.dispose();
    card2Models.dispose();
  }
}
