import '/backend/schema/structs/index.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'categories_blog_widget.dart' show CategoriesBlogWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class CategoriesBlogModel extends FlutterFlowModel<CategoriesBlogWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
