import '/backend/schema/structs/index.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'categories_blog_model.dart';
export 'categories_blog_model.dart';

class CategoriesBlogWidget extends StatefulWidget {
  const CategoriesBlogWidget({
    super.key,
    this.data,
  });

  final ArticlesStruct? data;

  @override
  State<CategoriesBlogWidget> createState() => _CategoriesBlogWidgetState();
}

class _CategoriesBlogWidgetState extends State<CategoriesBlogWidget> {
  late CategoriesBlogModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => CategoriesBlogModel());
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    context.watch<FFAppState>();

    return Container(
      width: double.infinity,
      height: 37.0,
      decoration: BoxDecoration(
        color: FlutterFlowTheme.of(context).accent4,
      ),
      child: Builder(
        builder: (context) {
          final categories = FFAppConstants.articleCategories.toList();

          return ListView.separated(
            padding: EdgeInsets.fromLTRB(
              15.0,
              0,
              15.0,
              0,
            ),
            primary: false,
            shrinkWrap: true,
            scrollDirection: Axis.horizontal,
            itemCount: categories.length,
            separatorBuilder: (_, __) => SizedBox(width: 12.0),
            itemBuilder: (context, categoriesIndex) {
              final categoriesItem = categories[categoriesIndex];
              return InkWell(
                splashColor: Colors.transparent,
                focusColor: Colors.transparent,
                hoverColor: Colors.transparent,
                highlightColor: Colors.transparent,
                onTap: () async {
                  FFAppState().SelectedCategoryArtickle = categoriesItem;
                  safeSetState(() {});
                },
                child: Container(
                  height: double.infinity,
                  decoration: BoxDecoration(
                    color:
                        FFAppState().SelectedCategoryArtickle == categoriesItem
                            ? FlutterFlowTheme.of(context).tertiary
                            : FlutterFlowTheme.of(context).accent2,
                    borderRadius: BorderRadius.circular(8.0),
                  ),
                  child: Align(
                    alignment: AlignmentDirectional(0.0, 0.0),
                    child: Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(18.0, 0.0, 18.0, 0.0),
                      child: Text(
                        categoriesItem,
                        style: FlutterFlowTheme.of(context).titleSmall.override(
                              font: GoogleFonts.cairo(
                                fontWeight: FontWeight.w500,
                                fontStyle: FlutterFlowTheme.of(context)
                                    .titleSmall
                                    .fontStyle,
                              ),
                              color: FFAppState().SelectedCategoryArtickle ==
                                      categoriesItem
                                  ? FlutterFlowTheme.of(context).info
                                  : FlutterFlowTheme.of(context).primaryText,
                              letterSpacing: 0.0,
                              fontWeight: FontWeight.w500,
                              fontStyle: FlutterFlowTheme.of(context)
                                  .titleSmall
                                  .fontStyle,
                            ),
                      ),
                    ),
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
