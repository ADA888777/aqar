import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'single_options_widget.dart' show SingleOptionsWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class SingleOptionsModel extends FlutterFlowModel<SingleOptionsWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
