import '/backend/schema/structs/index.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'card2_widget.dart' show Card2Widget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class Card2Model extends FlutterFlowModel<Card2Widget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
