import '/blog/components/single_options/single_options_widget.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'single_guides_widget.dart' show SingleGuidesWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class SingleGuidesModel extends FlutterFlowModel<SingleGuidesWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
