import '/backend/schema/structs/index.dart';
import '/blog/components/single_options/single_options_widget.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'single_blog_widget.dart' show SingleBlogWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class SingleBlogModel extends FlutterFlowModel<SingleBlogWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
