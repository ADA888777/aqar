import 'package:flutter/material.dart';
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'flutter_flow/flutter_flow_util.dart';

class FFAppState extends ChangeNotifier {
  static FFAppState _instance = FFAppState._internal();

  factory FFAppState() {
    return _instance;
  }

  FFAppState._internal();

  static void reset() {
    _instance = FFAppState._internal();
  }

  Future initializePersistedState() async {
    prefs = await SharedPreferences.getInstance();
    _safeInit(() {
      _SelectedLang = prefs.getString('ff_SelectedLang') ?? _SelectedLang;
    });
  }

  void update(VoidCallback callback) {
    callback();
    notifyListeners();
  }

  late SharedPreferences prefs;

  List<UsersStruct> _UserListReal = [];
  List<UsersStruct> get UserListReal => _UserListReal;
  set UserListReal(List<UsersStruct> value) {
    _UserListReal = value;
  }

  void addToUserListReal(UsersStruct value) {
    UserListReal.add(value);
  }

  void removeFromUserListReal(UsersStruct value) {
    UserListReal.remove(value);
  }

  void removeAtIndexFromUserListReal(int index) {
    UserListReal.removeAt(index);
  }

  void updateUserListRealAtIndex(
    int index,
    UsersStruct Function(UsersStruct) updateFn,
  ) {
    UserListReal[index] = updateFn(_UserListReal[index]);
  }

  void insertAtIndexInUserListReal(int index, UsersStruct value) {
    UserListReal.insert(index, value);
  }

  List<FaqStruct> _faqList = [
    FaqStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"كيف أنشر عقاري على المنصة؟\",\"answer\":\"سجّل حسابك ثم اضغط زر الإضافة، عبّئ تفاصيل العقار وأضف الصور والسعر، وسيظهر إعلانك مباشرة في قائمة الإعلانات.\"}')),
    FaqStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"هل توجد رسوم لنشر العقارات؟\",\"answer\":\"النشر الأساسي مجاني تماماً في الوقت الحالي.\"}')),
    FaqStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"هل يمكنني التواصل مع المعلن مباشرة؟\",\"answer\":\"نعم، من صفحة العقار اضغط زر مراسلة المالك لبدء محادثة مباشرة داخل التطبيق.\"}')),
    FaqStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"هل يمكنني حفظ العقارات لمشاهدتها لاحقاً؟\",\"answer\":\"نعم، اضغط أيقونة القلب على أي عقار وسيُحفظ في قائمة المفضلة الخاصة بك.\"}')),
    FaqStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"كيف أفلتر العقارات حسب احتياجي؟\",\"answer\":\"استخدم خانة البحث والفلاتر لتحديد السعر والمنطقة وعدد الغرف وغيرها للوصول لنتائج أدق.\"}')),
    FaqStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"كيف أجد وسيطاً عقارياً موثوقاً؟\",\"answer\":\"تصفح قسم الوسطاء واطلع على تقييمات المستخدمين وتخصص كل وسيط قبل التواصل.\"}')),
    FaqStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"كيف أعرف أن العقار ما زال متاحاً؟\",\"answer\":\"الإعلانات المعروضة نشطة، وللتأكد راسل المالك مباشرة من صفحة العقار.\"}')),
    FaqStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"كيف أحجز موعد معاينة للعقار؟\",\"answer\":\"من صفحة العقار اضغط طلب معاينة وسيصل طلبك للمالك لتنسيق الموعد معك عبر المحادثة.\"}')),
    FaqStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"كم يجب أن أدخر للدفعة الأولى؟\",\"answer\":\"يُنصح عادة بتجهيز 10-20% من قيمة العقار كدفعة أولى، وتختلف حسب جهة التمويل وشروطها.\"}')),
    FaqStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"الإيجار أم الشراء أيهما أفضل؟\",\"answer\":\"يعتمد على استقرارك ومدة بقائك المتوقعة وسيولتك؛ الإيجار أكثر مرونة والشراء استثمار طويل الأمد.\"}'))
  ];
  List<FaqStruct> get faqList => _faqList;
  set faqList(List<FaqStruct> value) {
    _faqList = value;
  }

  void addToFaqList(FaqStruct value) {
    faqList.add(value);
  }

  void removeFromFaqList(FaqStruct value) {
    faqList.remove(value);
  }

  void removeAtIndexFromFaqList(int index) {
    faqList.removeAt(index);
  }

  void updateFaqListAtIndex(
    int index,
    FaqStruct Function(FaqStruct) updateFn,
  ) {
    faqList[index] = updateFn(_faqList[index]);
  }

  void insertAtIndexInFaqList(int index, FaqStruct value) {
    faqList.insert(index, value);
  }

  List<ArticlesStruct> _BlogList = [
    ArticlesStruct(
      title: 'دليلك لشراء أول عقار في الكويت',
      description:
          'قبل شراء أول عقار لك، حدد ميزانيتك بدقة واحسب كل التكاليف الجانبية من رسوم التسجيل والوساطة. قارن الأسعار بين المناطق المتشابهة، وافحص العقار على الطبيعة أكثر من مرة وفي أوقات مختلفة من اليوم. تأكد من سلامة الأوراق وخلو العقار من أي التزامات قبل التوقيع، ولا تتردد في الاستعانة بمقيّم عقاري مستقل لمعرفة القيمة العادلة.',
      date: DateTime(2026, 6, 1),
      tag: 'نصائح',
      img: 'assets/images/app_logo.png',
    ),
    ArticlesStruct(
      title: 'الإيجار أم التملك؟ كيف تتخذ القرار الصحيح',
      description:
          'القرار بين الإيجار والتملك يعتمد على استقرارك الوظيفي ومدة بقائك المتوقعة في المنطقة وسيولتك المتاحة. الإيجار يمنحك مرونة الانتقال وقلة الالتزامات، بينما التملك استثمار طويل الأمد يحميك من ارتفاع الإيجارات. قاعدة عملية: إذا كنت ستبقى أكثر من سبع سنوات في نفس المكان وتملك دفعة أولى مريحة، فالتملك غالباً أوفر على المدى البعيد.',
      date: DateTime(2026, 5, 15),
      tag: 'مقارنات',
      img: 'assets/images/app_logo.png',
    ),
    ArticlesStruct(
      title: 'كيف تجهّز عقارك للإيجار بأفضل سعر',
      description:
          'العقار المجهز جيداً يؤجَّر أسرع وبسعر أعلى. ابدأ بصيانة شاملة للتكييف والسباكة والكهرباء، وطلاء جديد بألوان محايدة. الصور الاحترافية بإضاءة نهارية تضاعف اهتمام الباحثين، فصوّر كل الغرف من زوايا واسعة. اكتب وصفاً صادقاً ودقيقاً يذكر المساحة والمزايا القريبة مثل المدارس والخدمات، وحدّد سعراً منافساً بمقارنة إعلانات منطقتك.',
      date: DateTime(2026, 4, 20),
      tag: 'ملّاك',
      img: 'assets/images/app_logo.png',
    ),
  ];
  List<ArticlesStruct> get BlogList => _BlogList;
  set BlogList(List<ArticlesStruct> value) {
    _BlogList = value;
  }

  void addToBlogList(ArticlesStruct value) {
    BlogList.add(value);
  }

  void removeFromBlogList(ArticlesStruct value) {
    BlogList.remove(value);
  }

  void removeAtIndexFromBlogList(int index) {
    BlogList.removeAt(index);
  }

  void updateBlogListAtIndex(
    int index,
    ArticlesStruct Function(ArticlesStruct) updateFn,
  ) {
    BlogList[index] = updateFn(_BlogList[index]);
  }

  void insertAtIndexInBlogList(int index, ArticlesStruct value) {
    BlogList.insert(index, value);
  }

  List<String> _MessagesList = [];
  List<String> get MessagesList => _MessagesList;
  set MessagesList(List<String> value) {
    _MessagesList = value;
  }

  void addToMessagesList(String value) {
    MessagesList.add(value);
  }

  void removeFromMessagesList(String value) {
    MessagesList.remove(value);
  }

  void removeAtIndexFromMessagesList(int index) {
    MessagesList.removeAt(index);
  }

  void updateMessagesListAtIndex(
    int index,
    String Function(String) updateFn,
  ) {
    MessagesList[index] = updateFn(_MessagesList[index]);
  }

  void insertAtIndexInMessagesList(int index, String value) {
    MessagesList.insert(index, value);
  }

  List<FaqStruct> _QAList = [
    FaqStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"هل يمكن شراء عقار استثماري بدخل عادي؟\",\"answer\":\"نعم مع تخطيط مالي جيد وتمويل مناسب، ويُنصح باستشارة مختص تمويل عقاري.\"}')),
    FaqStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"ما القوانين المهمة قبل شراء عقار؟\",\"answer\":\"تأكد من سلامة سند الملكية وخلو العقار من الرهون والالتزامات، وراجع اشتراطات التسجيل العقاري في بلدك.\"}')),
    FaqStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"ما التكاليف التي يدفعها المشتري دون المستأجر؟\",\"answer\":\"رسوم التسجيل والوساطة والصيانة الدورية والتأمين، إضافة لأقساط التمويل إن وجد.\"}')),
    FaqStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"ما خطوات شراء العقار؟\",\"answer\":\"حدد ميزانيتك، ابحث وقارن، عاين العقار، تحقق من الأوراق، اتفق على السعر، ثم وثّق العقد وسجّل الملكية.\"}')),
    FaqStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"ما المستندات المطلوبة للإيجار أو الشراء؟\",\"answer\":\"إثبات الهوية، وإثبات الدخل عند التمويل، وسند الملكية من البائع، وعقد موثق بين الطرفين.\"}')),
    FaqStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"ما أفضل طريقة لبدء البحث عن عقار؟\",\"answer\":\"حدد ميزانيتك والمنطقة المفضلة أولاً، ثم استخدم البحث والفلاتر وقارن بين عدة خيارات قبل القرار.\"}')),
    FaqStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"ما الفرق بين سند الملكية والعقد؟\",\"answer\":\"العقد اتفاق البيع بين الطرفين، بينما سند الملكية هو الوثيقة الرسمية المسجلة التي تثبت انتقال الملكية.\"}')),
    FaqStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"ماذا أسأل عند مقابلة وسيط عقاري؟\",\"answer\":\"اسأل عن خبرته بالمنطقة، وصفقاته الأخيرة، وطريقة عمله وعمولته، وتقييمات عملائه السابقين.\"}')),
    FaqStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"ماذا أفعل لو شككت أن إعلاناً احتيالي؟\",\"answer\":\"لا تدفع أي مبلغ قبل المعاينة والتحقق من الأوراق، وأبلغنا عن الإعلان فوراً من خيار الإبلاغ.\"}')),
    FaqStruct.fromSerializableMap(jsonDecode(
        '{\"question\":\"ماذا أراعي في العقار الاستثماري؟\",\"answer\":\"الموقع والطلب الإيجاري في المنطقة، وحالة العقار وتكاليف صيانته، والعائد المتوقع مقارنة بسعره.\"}'))
  ];
  List<FaqStruct> get QAList => _QAList;
  set QAList(List<FaqStruct> value) {
    _QAList = value;
  }

  void addToQAList(FaqStruct value) {
    QAList.add(value);
  }

  void removeFromQAList(FaqStruct value) {
    QAList.remove(value);
  }

  void removeAtIndexFromQAList(int index) {
    QAList.removeAt(index);
  }

  void updateQAListAtIndex(
    int index,
    FaqStruct Function(FaqStruct) updateFn,
  ) {
    QAList[index] = updateFn(_QAList[index]);
  }

  void insertAtIndexInQAList(int index, FaqStruct value) {
    QAList.insert(index, value);
  }

  int _messagesTab = 0;
  int get messagesTab => _messagesTab;
  set messagesTab(int value) {
    _messagesTab = value;
  }

  String _SelectedExport = '';
  String get SelectedExport => _SelectedExport;
  set SelectedExport(String value) {
    _SelectedExport = value;
  }

  String _SelectedReasonBlock = '';
  String get SelectedReasonBlock => _SelectedReasonBlock;
  set SelectedReasonBlock(String value) {
    _SelectedReasonBlock = value;
  }

  List<LanguagesStruct> _languages = [
    LanguagesStruct.fromSerializableMap(jsonDecode(
        '{\"title\":\"العربية\",\"image\":\"assets/images/kuwait_flag.png\"}'))
  ];
  List<LanguagesStruct> get languages => _languages;
  set languages(List<LanguagesStruct> value) {
    _languages = value;
  }

  void addToLanguages(LanguagesStruct value) {
    languages.add(value);
  }

  void removeFromLanguages(LanguagesStruct value) {
    languages.remove(value);
  }

  void removeAtIndexFromLanguages(int index) {
    languages.removeAt(index);
  }

  void updateLanguagesAtIndex(
    int index,
    LanguagesStruct Function(LanguagesStruct) updateFn,
  ) {
    languages[index] = updateFn(_languages[index]);
  }

  void insertAtIndexInLanguages(int index, LanguagesStruct value) {
    languages.insert(index, value);
  }

  String _SelectedLang = 'الإنجليزية';
  String get SelectedLang => _SelectedLang;
  set SelectedLang(String value) {
    _SelectedLang = value;
    prefs.setString('ff_SelectedLang', value);
  }

  String _SelectedCountry = '';
  String get SelectedCountry => _SelectedCountry;
  set SelectedCountry(String value) {
    _SelectedCountry = value;
  }

  DateTime? _SelectedTourDate1 =
      DateTime.fromMillisecondsSinceEpoch(1736955060000);
  DateTime? get SelectedTourDate1 => _SelectedTourDate1;
  set SelectedTourDate1(DateTime? value) {
    _SelectedTourDate1 = value;
  }

  int _SelectedTourDate2 = 10;
  int get SelectedTourDate2 => _SelectedTourDate2;
  set SelectedTourDate2(int value) {
    _SelectedTourDate2 = value;
  }

  bool _updater = false;
  bool get updater => _updater;
  set updater(bool value) {
    _updater = value;
  }

  String _SelectedCategoryArtickle = 'الأحدث';
  String get SelectedCategoryArtickle => _SelectedCategoryArtickle;
  set SelectedCategoryArtickle(String value) {
    _SelectedCategoryArtickle = value;
  }

  String _SelectedReschedule = 'لدي تعارض في المواعيد';
  String get SelectedReschedule => _SelectedReschedule;
  set SelectedReschedule(String value) {
    _SelectedReschedule = value;
  }

  DateTime? _SelectedDate = DateTime.fromMillisecondsSinceEpoch(1731232320000);
  DateTime? get SelectedDate => _SelectedDate;
  set SelectedDate(DateTime? value) {
    _SelectedDate = value;
  }

  String _SelectedReasonCancel = 'أريد الإلغاء فقط';
  String get SelectedReasonCancel => _SelectedReasonCancel;
  set SelectedReasonCancel(String value) {
    _SelectedReasonCancel = value;
  }

  String _SelectedGender = '';
  String get SelectedGender => _SelectedGender;
  set SelectedGender(String value) {
    _SelectedGender = value;
  }

  String _SelectedLanguageFilter = '';
  String get SelectedLanguageFilter => _SelectedLanguageFilter;
  set SelectedLanguageFilter(String value) {
    _SelectedLanguageFilter = value;
  }

  String _SelectedSortBy = 'افتراضي';
  String get SelectedSortBy => _SelectedSortBy;
  set SelectedSortBy(String value) {
    _SelectedSortBy = value;
  }

  bool _SingleApartmentTab = false;
  bool get SingleApartmentTab => _SingleApartmentTab;
  set SingleApartmentTab(bool value) {
    _SingleApartmentTab = value;
  }

  String _SelectedReportApartment = '';
  String get SelectedReportApartment => _SelectedReportApartment;
  set SelectedReportApartment(String value) {
    _SelectedReportApartment = value;
  }

  String _SelectedPriceFilter1 = '';
  String get SelectedPriceFilter1 => _SelectedPriceFilter1;
  set SelectedPriceFilter1(String value) {
    _SelectedPriceFilter1 = value;
  }

  String _SelectedPriceFilter2 = '';
  String get SelectedPriceFilter2 => _SelectedPriceFilter2;
  set SelectedPriceFilter2(String value) {
    _SelectedPriceFilter2 = value;
  }

  int _filterCounter1 = 0;
  int get filterCounter1 => _filterCounter1;
  set filterCounter1(int value) {
    _filterCounter1 = value;
  }

  int _filterCounter2 = 0;
  int get filterCounter2 => _filterCounter2;
  set filterCounter2(int value) {
    _filterCounter2 = value;
  }

  int _filterCounter3 = 0;
  int get filterCounter3 => _filterCounter3;
  set filterCounter3(int value) {
    _filterCounter3 = value;
  }

  String _SelectedHomeType = '';
  String get SelectedHomeType => _SelectedHomeType;
  set SelectedHomeType(String value) {
    _SelectedHomeType = value;
  }

  String _SelectedAmenities = '';
  String get SelectedAmenities => _SelectedAmenities;
  set SelectedAmenities(String value) {
    _SelectedAmenities = value;
  }

  String _SelectedView = '';
  String get SelectedView => _SelectedView;
  set SelectedView(String value) {
    _SelectedView = value;
  }

  String _SelectedOrientation = '';
  String get SelectedOrientation => _SelectedOrientation;
  set SelectedOrientation(String value) {
    _SelectedOrientation = value;
  }

  int _AreaMin = 0;
  int get AreaMin => _AreaMin;
  set AreaMin(int value) {
    _AreaMin = value;
  }

  int _AreaMax = 0;
  int get AreaMax => _AreaMax;
  set AreaMax(int value) {
    _AreaMax = value;
  }

  bool _FromRegisterHome = false;
  bool get FromRegisterHome => _FromRegisterHome;
  set FromRegisterHome(bool value) {
    _FromRegisterHome = value;
  }

  String _SelectedSpeciality = '';
  String get SelectedSpeciality => _SelectedSpeciality;
  set SelectedSpeciality(String value) {
    _SelectedSpeciality = value;
  }

  String _SelectedFilterLanguage = '';
  String get SelectedFilterLanguage => _SelectedFilterLanguage;
  set SelectedFilterLanguage(String value) {
    _SelectedFilterLanguage = value;
  }

  String _SelectedSortFilter = '';
  String get SelectedSortFilter => _SelectedSortFilter;
  set SelectedSortFilter(String value) {
    _SelectedSortFilter = value;
  }

  String _SelectedPropertyType = '';
  String get SelectedPropertyType => _SelectedPropertyType;
  set SelectedPropertyType(String value) {
    _SelectedPropertyType = value;
  }

  String _SelectedLaundry = '';
  String get SelectedLaundry => _SelectedLaundry;
  set SelectedLaundry(String value) {
    _SelectedLaundry = value;
  }

  String _SelectedCooling = '';
  String get SelectedCooling => _SelectedCooling;
  set SelectedCooling(String value) {
    _SelectedCooling = value;
  }

  String _SelectedHeating = '';
  String get SelectedHeating => _SelectedHeating;
  set SelectedHeating(String value) {
    _SelectedHeating = value;
  }

  String _SelectedAppliances = '';
  String get SelectedAppliances => _SelectedAppliances;
  set SelectedAppliances(String value) {
    _SelectedAppliances = value;
  }

  String _SelectedFlooring = '';
  String get SelectedFlooring => _SelectedFlooring;
  set SelectedFlooring(String value) {
    _SelectedFlooring = value;
  }

  String _SelectedParking = '';
  String get SelectedParking => _SelectedParking;
  set SelectedParking(String value) {
    _SelectedParking = value;
  }

  String _SelectedOutdooramenities = '';
  String get SelectedOutdooramenities => _SelectedOutdooramenities;
  set SelectedOutdooramenities(String value) {
    _SelectedOutdooramenities = value;
  }

  String _SelectedAccessibility = '';
  String get SelectedAccessibility => _SelectedAccessibility;
  set SelectedAccessibility(String value) {
    _SelectedAccessibility = value;
  }

  String _SelectedOtherAmeneties = '';
  String get SelectedOtherAmeneties => _SelectedOtherAmeneties;
  set SelectedOtherAmeneties(String value) {
    _SelectedOtherAmeneties = value;
  }

  String _SelectedListedBy = '';
  String get SelectedListedBy => _SelectedListedBy;
  set SelectedListedBy(String value) {
    _SelectedListedBy = value;
  }

  List<String> _CoolingList = [];
  List<String> get CoolingList => _CoolingList;
  set CoolingList(List<String> value) {
    _CoolingList = value;
  }

  void addToCoolingList(String value) {
    CoolingList.add(value);
  }

  void removeFromCoolingList(String value) {
    CoolingList.remove(value);
  }

  void removeAtIndexFromCoolingList(int index) {
    CoolingList.removeAt(index);
  }

  void updateCoolingListAtIndex(
    int index,
    String Function(String) updateFn,
  ) {
    CoolingList[index] = updateFn(_CoolingList[index]);
  }

  void insertAtIndexInCoolingList(int index, String value) {
    CoolingList.insert(index, value);
  }

  List<String> _HeatingList = [];
  List<String> get HeatingList => _HeatingList;
  set HeatingList(List<String> value) {
    _HeatingList = value;
  }

  void addToHeatingList(String value) {
    HeatingList.add(value);
  }

  void removeFromHeatingList(String value) {
    HeatingList.remove(value);
  }

  void removeAtIndexFromHeatingList(int index) {
    HeatingList.removeAt(index);
  }

  void updateHeatingListAtIndex(
    int index,
    String Function(String) updateFn,
  ) {
    HeatingList[index] = updateFn(_HeatingList[index]);
  }

  void insertAtIndexInHeatingList(int index, String value) {
    HeatingList.insert(index, value);
  }

  List<String> _AppliancesList = [];
  List<String> get AppliancesList => _AppliancesList;
  set AppliancesList(List<String> value) {
    _AppliancesList = value;
  }

  void addToAppliancesList(String value) {
    AppliancesList.add(value);
  }

  void removeFromAppliancesList(String value) {
    AppliancesList.remove(value);
  }

  void removeAtIndexFromAppliancesList(int index) {
    AppliancesList.removeAt(index);
  }

  void updateAppliancesListAtIndex(
    int index,
    String Function(String) updateFn,
  ) {
    AppliancesList[index] = updateFn(_AppliancesList[index]);
  }

  void insertAtIndexInAppliancesList(int index, String value) {
    AppliancesList.insert(index, value);
  }

  List<String> _FlooringList = [];
  List<String> get FlooringList => _FlooringList;
  set FlooringList(List<String> value) {
    _FlooringList = value;
  }

  void addToFlooringList(String value) {
    FlooringList.add(value);
  }

  void removeFromFlooringList(String value) {
    FlooringList.remove(value);
  }

  void removeAtIndexFromFlooringList(int index) {
    FlooringList.removeAt(index);
  }

  void updateFlooringListAtIndex(
    int index,
    String Function(String) updateFn,
  ) {
    FlooringList[index] = updateFn(_FlooringList[index]);
  }

  void insertAtIndexInFlooringList(int index, String value) {
    FlooringList.insert(index, value);
  }

  List<String> _SelectedDays = [];
  List<String> get SelectedDays => _SelectedDays;
  set SelectedDays(List<String> value) {
    _SelectedDays = value;
  }

  void addToSelectedDays(String value) {
    SelectedDays.add(value);
  }

  void removeFromSelectedDays(String value) {
    SelectedDays.remove(value);
  }

  void removeAtIndexFromSelectedDays(int index) {
    SelectedDays.removeAt(index);
  }

  void updateSelectedDaysAtIndex(
    int index,
    String Function(String) updateFn,
  ) {
    SelectedDays[index] = updateFn(_SelectedDays[index]);
  }

  void insertAtIndexInSelectedDays(int index, String value) {
    SelectedDays.insert(index, value);
  }

  List<String> _ParkingList = [];
  List<String> get ParkingList => _ParkingList;
  set ParkingList(List<String> value) {
    _ParkingList = value;
  }

  void addToParkingList(String value) {
    ParkingList.add(value);
  }

  void removeFromParkingList(String value) {
    ParkingList.remove(value);
  }

  void removeAtIndexFromParkingList(int index) {
    ParkingList.removeAt(index);
  }

  void updateParkingListAtIndex(
    int index,
    String Function(String) updateFn,
  ) {
    ParkingList[index] = updateFn(_ParkingList[index]);
  }

  void insertAtIndexInParkingList(int index, String value) {
    ParkingList.insert(index, value);
  }

  List<String> _OutdoorList = [];
  List<String> get OutdoorList => _OutdoorList;
  set OutdoorList(List<String> value) {
    _OutdoorList = value;
  }

  void addToOutdoorList(String value) {
    OutdoorList.add(value);
  }

  void removeFromOutdoorList(String value) {
    OutdoorList.remove(value);
  }

  void removeAtIndexFromOutdoorList(int index) {
    OutdoorList.removeAt(index);
  }

  void updateOutdoorListAtIndex(
    int index,
    String Function(String) updateFn,
  ) {
    OutdoorList[index] = updateFn(_OutdoorList[index]);
  }

  void insertAtIndexInOutdoorList(int index, String value) {
    OutdoorList.insert(index, value);
  }

  List<String> _AccessibilitiesList = [];
  List<String> get AccessibilitiesList => _AccessibilitiesList;
  set AccessibilitiesList(List<String> value) {
    _AccessibilitiesList = value;
  }

  void addToAccessibilitiesList(String value) {
    AccessibilitiesList.add(value);
  }

  void removeFromAccessibilitiesList(String value) {
    AccessibilitiesList.remove(value);
  }

  void removeAtIndexFromAccessibilitiesList(int index) {
    AccessibilitiesList.removeAt(index);
  }

  void updateAccessibilitiesListAtIndex(
    int index,
    String Function(String) updateFn,
  ) {
    AccessibilitiesList[index] = updateFn(_AccessibilitiesList[index]);
  }

  void insertAtIndexInAccessibilitiesList(int index, String value) {
    AccessibilitiesList.insert(index, value);
  }

  List<String> _OtherList = [];
  List<String> get OtherList => _OtherList;
  set OtherList(List<String> value) {
    _OtherList = value;
  }

  void addToOtherList(String value) {
    OtherList.add(value);
  }

  void removeFromOtherList(String value) {
    OtherList.remove(value);
  }

  void removeAtIndexFromOtherList(int index) {
    OtherList.removeAt(index);
  }

  void updateOtherListAtIndex(
    int index,
    String Function(String) updateFn,
  ) {
    OtherList[index] = updateFn(_OtherList[index]);
  }

  void insertAtIndexInOtherList(int index, String value) {
    OtherList.insert(index, value);
  }

  List<String> _HomeTypeList = [];
  List<String> get HomeTypeList => _HomeTypeList;
  set HomeTypeList(List<String> value) {
    _HomeTypeList = value;
  }

  void addToHomeTypeList(String value) {
    HomeTypeList.add(value);
  }

  void removeFromHomeTypeList(String value) {
    HomeTypeList.remove(value);
  }

  void removeAtIndexFromHomeTypeList(int index) {
    HomeTypeList.removeAt(index);
  }

  void updateHomeTypeListAtIndex(
    int index,
    String Function(String) updateFn,
  ) {
    HomeTypeList[index] = updateFn(_HomeTypeList[index]);
  }

  void insertAtIndexInHomeTypeList(int index, String value) {
    HomeTypeList.insert(index, value);
  }

  int _HomeSearchTAB = 0;
  int get HomeSearchTAB => _HomeSearchTAB;
  set HomeSearchTAB(int value) {
    _HomeSearchTAB = value;
  }

  String _SelectedCity = '';
  String get SelectedCity => _SelectedCity;
  set SelectedCity(String value) {
    _SelectedCity = value;
  }

  bool _slideSearch = false;
  bool get slideSearch => _slideSearch;
  set slideSearch(bool value) {
    _slideSearch = value;
  }

  bool _fromRegister = false;
  bool get fromRegister => _fromRegister;
  set fromRegister(bool value) {
    _fromRegister = value;
  }

  int _navbar = 0;
  int get navbar => _navbar;
  set navbar(int value) {
    _navbar = value;
  }

  String _SelectedReportRieltor = '';
  String get SelectedReportRieltor => _SelectedReportRieltor;
  set SelectedReportRieltor(String value) {
    _SelectedReportRieltor = value;
  }

  List<DocumentReference> _favoritesList = [];
  List<DocumentReference> get favoritesList => _favoritesList;
  set favoritesList(List<DocumentReference> value) {
    _favoritesList = value;
  }

  void addToFavoritesList(DocumentReference value) {
    favoritesList.add(value);
  }

  void removeFromFavoritesList(DocumentReference value) {
    favoritesList.remove(value);
  }

  void removeAtIndexFromFavoritesList(int index) {
    favoritesList.removeAt(index);
  }

  void updateFavoritesListAtIndex(
    int index,
    DocumentReference Function(DocumentReference) updateFn,
  ) {
    favoritesList[index] = updateFn(_favoritesList[index]);
  }

  void insertAtIndexInFavoritesList(int index, DocumentReference value) {
    favoritesList.insert(index, value);
  }
}

void _safeInit(Function() initializeField) {
  try {
    initializeField();
  } catch (_) {}
}

Future _safeInitAsync(Function() initializeField) async {
  try {
    await initializeField();
  } catch (_) {}
}
