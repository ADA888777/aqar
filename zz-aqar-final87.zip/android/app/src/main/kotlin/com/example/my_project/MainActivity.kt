package com.kuwait.realestate

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
