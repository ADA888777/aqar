/**
 * وظائف العقار — مُصمَّمة لأقل تكلفة ممكنة على Blaze.
 *
 * وظيفة مجدولة واحدة فقط (كما طُلب) + مشغّل كتابة واحد خفيف.
 * التقدير: أقل من 100 استدعاء يومياً — ضمن الطبقة المجانية عملياً.
 */
const { onSchedule } = require('firebase-functions/v2/scheduler');
const { onDocumentWritten, onDocumentCreated, onDocumentUpdated } = require('firebase-functions/v2/firestore');
const { setGlobalOptions } = require('firebase-functions/v2');
const admin = require('firebase-admin');

admin.initializeApp();
const db = admin.firestore();

// سقف صارم للنسخ المتزامنة — يمنع أي انفجار في التكلفة
// nam5 = الولايات المتحدة المتعددة. الوظيفة يجب أن تكون في نفس القارة،
// وإلا عبرت كل قراءة الأطلسي (زمن أطول + رسوم خروج بيانات).
setGlobalOptions({ region: 'us-central1', maxInstances: 3 });

const MS_PER_DAY = 24 * 60 * 60 * 1000;
const LISTING_DAYS = 30;

/* ─────────────────────────────────────────────────────────
   توليد الكلمات المفتاحية للبحث العربي
   ───────────────────────────────────────────────────────── */

/**
 * تطبيع النص العربي — ضروري ليجد المستخدم "شاليه" وهو كتب "شالية".
 *  • توحيد الألف: أ إ آ ← ا
 *  • توحيد التاء المربوطة: ة ← ه
 *  • توحيد الياء: ى ← ي
 *  • حذف التشكيل والتطويل
 */
function normalizeArabic(text) {
  return String(text || '')
    .replace(/[\u064B-\u065F\u0670]/g, '') // التشكيل
    .replace(/\u0640/g, '')                // التطويل ـ
    .replace(/[أإآٱ]/g, 'ا')
    .replace(/ة/g, 'ه')
    .replace(/ى/g, 'ي')
    .replace(/[ؤئ]/g, 'ء')
    .toLowerCase()
    .trim();
}

/**
 * يبني مصفوفة الكلمات المفتاحية من البيانات الفعلية للإعلان فقط.
 * لا قيم افتراضية ولا بيانات وهمية — الحقل الفارغ يُتجاهل.
 *
 * يولّد: الكلمات الكاملة + البادئات (3 أحرف فأكثر) ليعمل البحث الجزئي.
 * مثال: "شاليه" ← شا، شال، شالي، شاليه
 */
function buildSearchKeywords(data) {
  const sources = [
    data.title,
    data.area,
    data.governorate,
    data.street,
    data.block,
    data.category,
    data.ListingTypy,
    data.description,
  ];

  const keywords = new Set();

  for (const src of sources) {
    if (!src || typeof src !== 'string') continue;
    const norm = normalizeArabic(src);
    // تقسيم على المسافات وعلامات الترقيم
    const words = norm.split(/[\s،,.\-_/\\()]+/).filter((w) => w.length >= 2);

    for (const w of words) {
      keywords.add(w);
      // بادئات للبحث الجزئي — نبدأ من 3 أحرف لتقليل حجم المصفوفة
      for (let i = 3; i < w.length; i++) {
        keywords.add(w.slice(0, i));
      }
    }
  }

  // حد Firestore العملي: نُبقي المصفوفة معقولة الحجم
  return Array.from(keywords).slice(0, 400);
}

/**
 * يحسب is_live من منطق الإعلان الحقيقي — المصدر الوحيد للحقيقة.
 * الإعلان حيّ إذا: معتمد، وغير مؤرشف، وغير محذوف، ولم تنتهِ مدته.
 */
function computeIsLive(data) {
  if (data.isApproved !== true) return false;
  if (data.is_archived === true) return false;
  if (data.is_deleted === true) return false;

  const expires = data.expires_at;
  if (expires && typeof expires.toMillis === 'function') {
    if (expires.toMillis() <= Date.now()) return false;
  }
  return true;
}

/* ─────────────────────────────────────────────────────────
   1) مشغّل الكتابة: يحافظ على is_live و search_keywords
   ───────────────────────────────────────────────────────── */
exports.onPropertyWrite = onDocumentWritten(
  'PropertyData/{propertyId}',
  async (event) => {
    const after = event.data?.after;
    if (!after || !after.exists) return null; // حُذف الإعلان

    const data = after.data();

    // expires_at = published_at + 30 يوماً — يُحسب هنا فقط (لا من العميل).
    // إعادة النشر تغيّر published_at فيُعاد الحساب تلقائياً.
    const patch = {};
    const base = data.published_at?.toMillis?.()
      ?? data.created_at?.toMillis?.()
      ?? Date.now();
    const wanted = base + LISTING_DAYS * MS_PER_DAY;
    const current = data.expires_at?.toMillis?.();
    if (current !== wanted) {
      patch.expires_at = admin.firestore.Timestamp.fromMillis(wanted);
    }

    const desiredLive = computeIsLive({ ...data, ...patch });
    if (data.is_live !== desiredLive) patch.is_live = desiredLive;

    const desiredKw = buildSearchKeywords(data);
    const currentKw = Array.isArray(data.search_keywords) ? data.search_keywords : [];
    const kwChanged =
      desiredKw.length !== currentKw.length ||
      desiredKw.some((k, i) => k !== currentKw[i]);
    if (kwChanged) patch.search_keywords = desiredKw;

    // لا كتابة إن لم يتغيّر شيء — يمنع حلقة تشغيل لا نهائية ويوفّر التكلفة
    if (Object.keys(patch).length === 0) return null;

    await after.ref.update(patch);
    return null;
  }
);

/* ─────────────────────────────────────────────────────────
   2) الوظيفة المجدولة الوحيدة: إطفاء الإعلانات المنتهية
   ───────────────────────────────────────────────────────── */
exports.expireListings = onSchedule(
  {
    schedule: 'every day 03:00',
    timeZone: 'Asia/Kuwait',
    retryCount: 1,
  },
  async () => {
    const now = admin.firestore.Timestamp.now();
    let processed = 0;

    // استعلام مُوجَّه: الإعلانات الحيّة التي انتهت مدتها فقط.
    // لا يمسح المجموعة كاملة — التكلفة تتناسب مع المنتهي فقط.
    while (true) {
      const snap = await db
        .collection('PropertyData')
        .where('is_live', '==', true)
        .where('expires_at', '<=', now)
        .limit(400)
        .get();

      if (snap.empty) break;

      const batch = db.batch();
      snap.docs.forEach((d) => batch.update(d.ref, { is_live: false }));
      await batch.commit();
      // إشعار «انتهى» — معرّف بدورة النشر فلا يتكرر
      for (const d of snap.docs) {
        const p = d.data();
        await notify({
          id: `listing_expired_${d.id}_${p.expires_at && p.expires_at.toMillis ? p.expires_at.toMillis() : 0}`,
          userRef: p.ownerRef, type: 'listing_expired',
          title: 'انتهت مدة إعلانك',
          body: `«${shortTitle(p.title)}» لم يعد ظاهراً. أعد نشره من «إعلاناتي».`,
          targetRef: d.ref, targetType: 'property',
        });
      }

      processed += snap.size;
      if (snap.size < 400) break;
    }

    console.log(`expireListings: أُطفئ ${processed} إعلاناً منتهياً`);

    // «قارب على الانتهاء» — الحيّة التي تنتهي خلال 3 أيام، مرة لكل دورة نشر
    const in3d = admin.firestore.Timestamp.fromMillis(Date.now() + 3 * MS_PER_DAY);
    const soon = await db.collection('PropertyData')
      .where('is_live', '==', true)
      .where('expires_at', '<=', in3d)
      .limit(400).get();
    for (const d of soon.docs) {
      const p = d.data();
      const exp = p.expires_at && p.expires_at.toMillis ? p.expires_at.toMillis() : 0;
      const days = Math.max(0, Math.ceil((exp - Date.now()) / MS_PER_DAY));
      await notify({
        id: `listing_expiring_${d.id}_${exp}`,
        userRef: p.ownerRef, type: 'listing_expiring',
        title: days <= 0 ? 'ينتهي إعلانك اليوم' : `ينتهي إعلانك خلال ${days} ${days === 1 ? 'يوم' : 'أيام'}`,
        body: `«${shortTitle(p.title)}» — أعد نشره ليبقى ظاهراً.`,
        targetRef: d.ref, targetType: 'property',
      });
    }
    return null;
  }
);

/* ═══════════════════════════════════════════════════════════
   الإشعارات — مبنية على أحداث حقيقية، تُنشأ من الخادم فقط
   ═══════════════════════════════════════════════════════════

   notifications/{id}:
     user_ref     ← المستلم
     type         ← listing_published | listing_updated | listing_republished
                    | listing_expiring | listing_expired | listing_disabled
                    | message | offer | favorite | request_published
     title, body
     target_ref   ← الإعلان / المحادثة / الطلب
     target_type  ← 'property' | 'chat' | 'request'
     created_at, is_read

   المعرّف حتمي (type + target + user) → لا تكرار مهما أعيد التشغيل.
   .create() يفشل إن وُجد المعرّف — نبتلع الفشل بصمت.
*/

const NOTIF_SETTING_FOR_TYPE = {
  listing_published: 'listings', listing_updated: 'listings',
  listing_republished: 'listings', listing_expiring: 'listings',
  listing_expired: 'listings', listing_disabled: 'listings',
  message: 'messages', offer: 'messages',
  favorite: 'listings', request_published: 'requests',
};

/** يحترم إعدادات المستخدم: لو أطفأ الفئة لا يُنشأ الإشعار */
async function userAllows(userRef, type) {
  const key = NOTIF_SETTING_FOR_TYPE[type];
  if (!key) return true;
  try {
    const u = await userRef.get();
    const settings = (u.data() || {}).notification_settings || {};
    return settings[key] !== false;
  } catch (e) { return true; }
}

/** إنشاء إشعار بمعرّف حتمي — آمن من التكرار */
async function notify(n) {
  if (!n.userRef) return;
  if (!(await userAllows(n.userRef, n.type))) return;
  const ref = db.collection('notifications').doc(n.id);
  try {
    await ref.create({
      user_ref: n.userRef, type: n.type, title: n.title, body: n.body || '',
      target_ref: n.targetRef || null, target_type: n.targetType || null,
      created_at: admin.firestore.FieldValue.serverTimestamp(),
      is_read: false,
    });
  } catch (e) {
    if (e.code !== 6 && !String(e.message).includes('ALREADY_EXISTS')) throw e;
  }
}

const shortTitle = (t) => String(t || 'إعلانك').slice(0, 40);

/* ── الإعلانات ─────────────────────────────────────────────── */
exports.onPropertyCreated = onDocumentCreated('PropertyData/{id}', async (event) => {
  const d = event.data && event.data.data();
  if (!d || !d.ownerRef) return;
  await notify({
    id: `listing_published_${event.params.id}`,
    userRef: d.ownerRef, type: 'listing_published',
    title: 'تم نشر إعلانك',
    body: `«${shortTitle(d.title)}» صار ظاهراً للباحثين لمدة 30 يوماً.`,
    targetRef: event.data.ref, targetType: 'property',
  });
});

exports.onPropertyUpdated = onDocumentUpdated('PropertyData/{id}', async (event) => {
  const b = event.data.before.data(), a = event.data.after.data();
  if (!a || !a.ownerRef) return;
  const id = event.params.id;

  if (a.disabled_by_admin === true && b.disabled_by_admin !== true) {
    return notify({
      id: `listing_disabled_${id}_${Date.now()}`,
      userRef: a.ownerRef, type: 'listing_disabled',
      title: 'تم إيقاف إعلانك من الإدارة',
      body: `«${shortTitle(a.title)}» لم يعد ظاهراً. راجع الشروط أو تواصل مع الدعم.`,
      targetRef: event.data.after.ref, targetType: 'property',
    });
  }

  const pb = b.published_at && b.published_at.toMillis ? b.published_at.toMillis() : null;
  const pa = a.published_at && a.published_at.toMillis ? a.published_at.toMillis() : null;
  if (pa && pa !== pb) {
    return notify({
      id: `listing_republished_${id}_${pa}`,
      userRef: a.ownerRef, type: 'listing_republished',
      title: 'تمت إعادة نشر إعلانك',
      body: `«${shortTitle(a.title)}» عاد للظهور لمدة 30 يوماً جديدة.`,
      targetRef: event.data.after.ref, targetType: 'property',
    });
  }

  const contentKeys = ['title', 'price', 'description', 'images', 'category',
    'ListingTypy', 'area', 'rooms', 'bathrooms', 'size', 'contact_phone'];
  const changed = contentKeys.some((k) => JSON.stringify(b[k]) !== JSON.stringify(a[k]));
  if (changed) {
    const minute = Math.floor(Date.now() / 60000);
    return notify({
      id: `listing_updated_${id}_${minute}`,
      userRef: a.ownerRef, type: 'listing_updated',
      title: 'تم حفظ تعديلات إعلانك',
      body: `«${shortTitle(a.title)}» محدَّث.`,
      targetRef: event.data.after.ref, targetType: 'property',
    });
  }
});

/* ── الرسائل وعروض السعر ───────────────────────────────────── */
exports.onMessageCreated = onDocumentCreated('messages/{id}', async (event) => {
  const m = event.data && event.data.data();
  if (!m || !m.receiver_ref || !m.sender_ref) return;
  const isOffer = m.type === 'offer';
  let senderName = 'مستخدم';
  try { senderName = ((await m.sender_ref.get()).data() || {}).display_name || senderName; } catch (e) {}
  await notify({
    id: `${isOffer ? 'offer' : 'msg'}_${event.params.id}`,
    userRef: m.receiver_ref, type: isOffer ? 'offer' : 'message',
    title: isOffer ? `عرض سعر من ${senderName}` : `رسالة من ${senderName}`,
    body: String(m.text || '').slice(0, 80),
    targetRef: m.chat_ref || null, targetType: 'chat',
  });
});

/* ── المفضلة: مرة واحدة لكل (إعلان، مستخدم) ────────────────── */
exports.onUserFavoritesChanged = onDocumentUpdated('users/{uid}', async (event) => {
  const b = (event.data.before.data() || {}).favorites || [];
  const a = (event.data.after.data() || {}).favorites || [];
  const bPaths = new Set(b.map((r) => r.path));
  const added = a.filter((r) => r && r.path && !bPaths.has(r.path));
  if (!added.length) return;
  const favName = (event.data.after.data() || {}).display_name || 'مستخدم';
  for (const propRef of added.slice(0, 5)) {
    try {
      const p = (await propRef.get()).data();
      if (!p || !p.ownerRef || p.ownerRef.path === event.data.after.ref.path) continue;
      await notify({
        id: `fav_${propRef.id}_${event.params.uid}`,
        userRef: p.ownerRef, type: 'favorite',
        title: 'أُضيف إعلانك إلى المفضلة',
        body: `${favName} حفظ «${shortTitle(p.title)}».`,
        targetRef: propRef, targetType: 'property',
      });
    } catch (e) {}
  }
});

/* ── طلبات العقارات ────────────────────────────────────────── */
exports.onRequestCreated = onDocumentCreated('propertyRequests/{id}', async (event) => {
  const r = event.data && event.data.data();
  if (!r || !r.user_ref) return;
  await notify({
    id: `request_published_${event.params.id}`,
    userRef: r.user_ref, type: 'request_published',
    title: 'تم نشر طلبك',
    body: 'طلبك ظاهر الآن للملّاك والمكاتب. سيتواصلون معك مباشرة.',
    targetRef: event.data.ref, targetType: 'request',
  });
});

/* ─────────────────────────────────────────────────────────
   3) Migration لمرة واحدة — يُستدعى يدوياً ثم يُحذف
   ───────────────────────────────────────────────────────── */
exports.backfillListings = require('firebase-functions/v2/https').onRequest(
  { timeoutSeconds: 540, maxInstances: 1 },
  async (req, res) => {
    // حماية: يتطلب مفتاحاً يُمرَّر عبر متغير بيئة
    if (req.query.key !== process.env.BACKFILL_KEY) {
      res.status(403).send('forbidden');
      return;
    }

    let cursor = null;
    let updated = 0;
    let skipped = 0;

    while (true) {
      let q = db.collection('PropertyData').orderBy('__name__').limit(300);
      if (cursor) q = q.startAfter(cursor);
      const snap = await q.get();
      if (snap.empty) break;

      const batch = db.batch();
      let writes = 0;

      for (const doc of snap.docs) {
        const data = doc.data();
        const patch = {};

        // لا نكسر الإعلانات القديمة: نضيف الناقص فقط، ولا نحذف شيئاً
        if (!data.expires_at) {
          const base = data.published_at?.toMillis?.()
            ?? data.created_at?.toMillis?.()
            ?? Date.now();
          patch.expires_at = admin.firestore.Timestamp.fromMillis(
            base + LISTING_DAYS * MS_PER_DAY
          );
        }
        if (!Array.isArray(data.search_keywords) || data.search_keywords.length === 0) {
          patch.search_keywords = buildSearchKeywords(data);
        }
        const live = computeIsLive({ ...data, ...patch });
        if (data.is_live !== live) patch.is_live = live;

        if (Object.keys(patch).length > 0) {
          batch.update(doc.ref, patch);
          writes++;
        } else {
          skipped++;
        }
      }

      if (writes > 0) await batch.commit();
      updated += writes;
      cursor = snap.docs[snap.docs.length - 1];
      if (snap.size < 300) break;
    }

    res.json({ updated, skipped, done: true });
  }
);
