import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import '/flutter_flow/flutter_flow_animations.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_toggle_icon.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/home/components/property_card2/property_card2_widget.dart';
import '/home/components/sent_price_offer/sent_price_offer_widget.dart';
import '/home/components/single_options2/single_options2_widget.dart';
import '/home/components/snack_bar/snack_bar_widget.dart';
import 'dart:math';
import 'dart:ui';
import 'dart:ui' as ui_dir show TextDirection;
import '/index.dart';
import 'package:smooth_page_indicator/smooth_page_indicator.dart'
    as smooth_page_indicator;
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:share_plus/share_plus.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'single_apartment_model.dart';
export 'single_apartment_model.dart';

class SingleApartmentWidget extends StatefulWidget {
  const SingleApartmentWidget({
    super.key,
    this.data,
  });

  final PropertyDataRecord? data;

  static String routeName = 'SingleApartment';
  static String routePath = '/singleApartment';

  @override
  State<SingleApartmentWidget> createState() => _SingleApartmentWidgetState();
}

class _SingleApartmentWidgetState extends State<SingleApartmentWidget>
    with TickerProviderStateMixin {
  late SingleApartmentModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  final animationsMap = <String, AnimationInfo>{};

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => SingleApartmentModel());

    _model.textController ??= TextEditingController();
    _model.textFieldFocusNode ??= FocusNode();

    // تسجيل المشاهدة مرة واحدة عند فتح الصفحة فقط — ليس في build()
    // ولا في StreamBuilder، فلا تتضخم الأرقام بإعادة البناء.
    // يلتقط صلاحية الأدمن إن أُضيفت أثناء الجلسة ويُظهر زر الدرع
    WidgetsBinding.instance.addPostFrameCallback((_) {
      refreshUserClaims().then((_) {
        if (mounted) safeSetState(() {});
      });
    });
    if (widget.data != null) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        recordPropertyView(widget.data!);
      });
    }

    animationsMap.addAll({
      'iconButtonOnPageLoadAnimation': AnimationInfo(
        trigger: AnimationTrigger.onPageLoad,
        effectsBuilder: () => [
          MoveEffect(
            curve: Curves.easeInOut,
            delay: 0.0.ms,
            duration: 400.0.ms,
            begin: Offset(-50.0, 0.0),
            end: Offset(0.0, 0.0),
          ),
        ],
      ),
      'containerOnPageLoadAnimation': AnimationInfo(
        trigger: AnimationTrigger.onPageLoad,
        effectsBuilder: () => [
          MoveEffect(
            curve: Curves.easeInOut,
            delay: 0.0.ms,
            duration: 300.0.ms,
            begin: Offset(0.0, 45.0),
            end: Offset(0.0, 0.0),
          ),
          FadeEffect(
            curve: Curves.easeInOut,
            delay: 0.0.ms,
            duration: 300.0.ms,
            begin: 0.5,
            end: 1.0,
          ),
        ],
      ),
    });
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  /// عارض صور الإعلان — يفتح كل الصور المحفوظة مع تكبير وتنقّل.
  /// عدد الصور من `propertyImages` في سجل الإعلان (لا قيم ثابتة).
  Future<void> _openGallery(int initialIndex) async {
    final imgs = widget.data?.propertyImages.toList() ?? const <String>[];
    if (imgs.isEmpty) {
      return;
    }
    var current = initialIndex.clamp(0, imgs.length - 1);
    final controller = PageController(initialPage: current);
    await showDialog(
      context: context,
      barrierColor: Colors.black,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setDlg) => Scaffold(
          backgroundColor: Colors.black,
          body: SafeArea(
            child: Stack(
              children: [
                PageView.builder(
                  controller: controller,
                  itemCount: imgs.length,
                  onPageChanged: (i) => setDlg(() => current = i),
                  itemBuilder: (context, i) => InteractiveViewer(
                    // تكبير وتصغير بالإصبعين
                    minScale: 1.0,
                    maxScale: 4.0,
                    child: Center(
                      child: Image.network(
                        imgs[i],
                        fit: BoxFit.contain,
                        errorBuilder: (_, __, ___) => Icon(
                          Icons.broken_image_outlined,
                          color: Colors.white54,
                          size: 48.0,
                        ),
                        loadingBuilder: (context, child, progress) =>
                            progress == null
                                ? child
                                : Center(
                                    child: CircularProgressIndicator(
                                      valueColor:
                                          AlwaysStoppedAnimation<Color>(
                                              Colors.white),
                                    ),
                                  ),
                      ),
                    ),
                  ),
                ),
                // زر الإغلاق
                Positioned(
                  top: 8.0,
                  left: 8.0,
                  child: InkWell(
                    onTap: () => Navigator.pop(ctx),
                    child: Container(
                      padding: EdgeInsets.all(8.0),
                      decoration: BoxDecoration(
                        color: Colors.black54,
                        shape: BoxShape.circle,
                      ),
                      child: Icon(Icons.close_rounded,
                          color: Colors.white, size: 24.0),
                    ),
                  ),
                ),
                // عدّاد الصور
                Positioned(
                  bottom: 16.0,
                  left: 0.0,
                  right: 0.0,
                  child: Center(
                    child: Container(
                      padding: EdgeInsets.symmetric(
                          horizontal: 14.0, vertical: 6.0),
                      decoration: BoxDecoration(
                        color: Colors.black54,
                        borderRadius: BorderRadius.circular(20.0),
                      ),
                      child: Text(
                        '${current + 1} / ${imgs.length}',
                        style: TextStyle(color: Colors.white, fontSize: 14.0),
                      ),
                    ),
                  ),
                ),
                // أسهم التنقّل
                if (imgs.length > 1) ...[
                  Align(
                    alignment: AlignmentDirectional(-1.0, 0.0),
                    child: IconButton(
                      onPressed: current > 0
                          ? () => controller.previousPage(
                                duration: Duration(milliseconds: 250),
                                curve: Curves.easeOut,
                              )
                          : null,
                      icon: Icon(Icons.chevron_left_rounded,
                          color: current > 0 ? Colors.white : Colors.white24,
                          size: 38.0),
                    ),
                  ),
                  Align(
                    alignment: AlignmentDirectional(1.0, 0.0),
                    child: IconButton(
                      onPressed: current < imgs.length - 1
                          ? () => controller.nextPage(
                                duration: Duration(milliseconds: 250),
                                curve: Curves.easeOut,
                              )
                          : null,
                      icon: Icon(Icons.chevron_right_rounded,
                          color: current < imgs.length - 1
                              ? Colors.white
                              : Colors.white24,
                          size: 38.0),
                    ),
                  ),
                ],
              ],
            ),
          ),
        ),
      ),
    );
    controller.dispose();
  }

  /// إجراء إداري على إعلان مخالف (يظهر للمدير فقط).
  /// الصلاحية محمية في Firestore Rules — الواجهة مجرد اختصار.
  Future<void> _adminAction() async {
    final d = widget.data;
    if (d == null) return;
    // دفاع مضاعف: نُجدّد الـ claims ونتحقق لحظة التنفيذ، لا عند بناء
    // الواجهة فقط. الخادم يرفض على أي حال — هذه لتجنّب رسالة خطأ غامضة.
    await refreshUserClaims();
    if (!currentUserIsAdmin) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text('هذا الإجراء للإدارة فقط'),
          backgroundColor: FlutterFlowTheme.of(context).error,
        ));
        safeSetState(() {}); // يخفي الدرع إن كان ظاهراً بالخطأ
      }
      return;
    }
    final choice = await showModalBottomSheet<String>(
      context: context,
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Padding(
              padding: EdgeInsets.all(16.0),
              child: Text(
                'إجراء إداري على الإعلان',
                style: FlutterFlowTheme.of(context).titleMedium.override(
                      font: GoogleFonts.cairo(fontWeight: FontWeight.w600),
                      letterSpacing: 0.0,
                    ),
              ),
            ),
            ListTile(
              leading: Icon(Icons.visibility_off_outlined,
                  color: FlutterFlowTheme.of(context).warning),
              title: Text('تعطيل الإعلان (يمكن استرجاعه)',
                  style: GoogleFonts.cairo()),
              onTap: () => Navigator.pop(ctx, 'disable'),
            ),
            ListTile(
              leading: Icon(Icons.delete_forever_outlined,
                  color: FlutterFlowTheme.of(context).error),
              title: Text('حذف نهائي', style: GoogleFonts.cairo()),
              onTap: () => Navigator.pop(ctx, 'delete'),
            ),
            ListTile(
              leading: Icon(Icons.close_rounded),
              title: Text('إلغاء', style: GoogleFonts.cairo()),
              onTap: () => Navigator.pop(ctx),
            ),
          ],
        ),
      ),
    );
    if (choice == null) return;
    try {
      if (choice == 'disable') {
        await adminDisableProperty(d);
      } else {
        await adminDeleteProperty(d);
      }
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(choice == 'disable'
              ? 'تم تعطيل الإعلان'
              : 'تم حذف الإعلان نهائياً'),
          backgroundColor: FlutterFlowTheme.of(context).primary,
        ),
      );
      context.safePop();
    } catch (_) {
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('الصلاحيات ترفض هذه العملية'),
          backgroundColor: FlutterFlowTheme.of(context).error,
        ),
      );
    }
  }

  /// مشاركة الإعلان — يبني نصاً واضحاً بمعلومات العقار ورابط التطبيق
  /// وينسخه للحافظة (المشروع لا يستخدم مكتبة مشاركة، فلا نضيف تبعية جديدة).
  Future<void> _shareProperty() async {
    final d = widget.data;
    if (d == null) {
      return;
    }
    final buf = StringBuffer();
    buf.writeln(d.title);
    if (d.price > 0) {
      final t = d.listingTypy == 'rent' ? 'الإيجار الشهري' : 'السعر';
      buf.writeln('$t: ${d.price.toStringAsFixed(0)} KD');
    }
    final loc = d.area.trim(); // المنطقة فقط — بلا محافظة
    if (loc.isNotEmpty) {
      buf.writeln('الموقع: $loc');
    }
    final rooms = <String>[
      if (d.rooms > 0) '${d.rooms} غرف',
      if (d.bathrooms > 0) '${d.bathrooms} حمامات',
      if (d.halls > 0) '${d.halls} صالات',
    ].join(' | ');
    if (rooms.isNotEmpty) {
      buf.writeln(rooms);
    }
    if (d.contactPhone.trim().isNotEmpty) {
      buf.writeln('للتواصل: ${d.contactPhone.trim()}');
    }
    buf.writeln('');
    buf.writeln('عبر تطبيق العقار:');
    buf.writeln(
        'https://play.google.com/store/apps/details?id=com.kuwait.realestate');

    try {
      // Share Sheet الأصلية: واتساب، الرسائل، البريد... حسب الجهاز
      await Share.share(buf.toString(), subject: d.title);
    } catch (_) {
      // احتياط: نسخ للحافظة إن تعذّر فتح ورقة المشاركة
      await Clipboard.setData(ClipboardData(text: buf.toString()));
      if (!context.mounted) {
        return;
      }
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('تم نسخ تفاصيل الإعلان — الصقها في أي تطبيق'),
          backgroundColor: FlutterFlowTheme.of(context).primary,
        ),
      );
    }
  }

  /// رقم الواتساب: من حقل الإعلان، وإن كان فارغاً نستخدم رقم التواصل،
  /// وللإعلانات القديمة نرجع لهاتف المالك من سجله.
  Future<String> _resolveWhatsapp() async {
    final w = (widget.data?.whatsappPhone ?? '').trim();
    if (w.isNotEmpty) return w;
    return await _resolveContactPhone();
  }

  /// يحوّل الرقم لصيغة دولية يقبلها واتساب (بلا + ولا مسافات).
  /// أرقام الكويت المحلية (8 خانات) تُسبق بمفتاح الدولة 965.
  String _waNumber(String raw) {
    var d = raw.replaceAll(RegExp(r'[^0-9]'), '');
    if (d.startsWith('00')) d = d.substring(2);
    if (d.length == 8) d = '965$d';
    return d;
  }

  /// يفتح واتساب مباشرة على رقم صاحب الإعلان (بلا محادثة داخل التطبيق).
  Future<void> _openWhatsapp(String raw) async {
    final num = _waNumber(raw);
    if (num.isEmpty) return;
    final msg = Uri.encodeComponent(
        'السلام عليكم، بخصوص إعلانكم في تطبيق العقار: ${widget.data?.title ?? ''}');
    await launchURL('https://wa.me/$num?text=$msg');
  }

  /// سطر العنوان الظاهر: المنطقة والقطعة والشارع من بيانات الإعلان.
  String _propertyAddressLine() {
    final d = widget.data;
    final parts = <String>[
      if ((d?.area ?? '').trim().isNotEmpty) d!.area.trim(),
      if ((d?.block ?? '').trim().isNotEmpty) 'قطعة ${d!.block.trim()}',
      if ((d?.street ?? '').trim().isNotEmpty) 'شارع ${d!.street.trim()}',
    ];
    return parts.isEmpty ? 'الموقع غير محدد' : parts.join('، ');
  }

  /// يفتح خرائط جوجل على موقع العقار: الإحداثيات المحفوظة إن وُجدت،
  /// وإلا بحث نصي بالمنطقة داخل الكويت — لا موقع افتراضي خارج البلد.
  Future<void> _openPropertyLocation() async {
    final loc = widget.data?.location;
    if (loc != null) {
      await launchURL(
          'https://www.google.com/maps/search/?api=1&query=${loc.latitude},${loc.longitude}');
      return;
    }
    final area = (widget.data?.area ?? '').trim();
    // المحافظة مشتقة من المنطقة داخلياً لتحسين دقة بحث الخرائط — لا تُعرض
    final gov = FFAppConstants.governorateOfArea(area) ?? '';
    if (area.isNotEmpty) {
      final q = Uri.encodeComponent('$area $gov الكويت'.trim());
      await launchURL('https://www.google.com/maps/search/?api=1&query=$q');
      return;
    }
    final c = FFAppConstants.KuwaitCenter;
    await launchURL(
        'https://www.google.com/maps/search/?api=1&query=${c[0]},${c[1]}');
  }

  /// رقم التواصل: من حقل الإعلان `contact_phone`، وإن كان فارغاً
  /// (إعلانات قديمة أُنشئت قبل إضافة الحقل) نقرأ هاتف المالك من سجله.
  Future<String> _resolveContactPhone() async {
    final direct = widget.data?.contactPhone ?? '';
    if (direct.trim().isNotEmpty) {
      return direct.trim();
    }
    final owner = widget.data?.ownerRef;
    if (owner == null) {
      return '';
    }
    try {
      final u = await UsersRecord.getDocumentOnce(owner);
      return u.phoneNumber.trim();
    } catch (_) {
      return '';
    }
  }

  @override
  Widget build(BuildContext context) {
    context.watch<FFAppState>();

    return GestureDetector(
      onTap: () {
        FocusScope.of(context).unfocus();
        FocusManager.instance.primaryFocus?.unfocus();
      },
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: FlutterFlowTheme.of(context).secondaryBackground,
        body: SafeArea(
         child: Column(
          mainAxisSize: MainAxisSize.max,
          children: [
            Expanded(
              child: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Stack(
                      children: [
                        Stack(
                          alignment: AlignmentDirectional(0.0, 1.0),
                          children: [
                            Container(
                              width: double.infinity,
                              height: (MediaQuery.sizeOf(context).height * 0.32).clamp(200.0, 320.0),
                              child: Stack(
                                children: [
                                  PageView(
                                    controller: _model.pageViewController ??=
                                        PageController(initialPage: 0),
                                    onPageChanged: (_) async {
                                      if (FFAppState().updater) {
                                        FFAppState().updater = false;
                                        safeSetState(() {});
                                      } else {
                                        FFAppState().updater = true;
                                        safeSetState(() {});
                                      }
                                    },
                                    scrollDirection: Axis.horizontal,
                                    children: [
                                      Stack(
                                        alignment:
                                            AlignmentDirectional(0.0, 1.0),
                                        children: [
                                          Container(
                                            width: double.infinity,
                                            height: (MediaQuery.sizeOf(context).height * 0.32).clamp(200.0, 320.0),
                                            decoration: BoxDecoration(
                                              color:
                                                  FlutterFlowTheme.of(context)
                                                      .secondaryBackground,
                                              borderRadius: BorderRadius.only(),
                                            ),
                                            // كل صور الإعلان — الضغط يفتح
                                            // العارض بتكبير وتنقّل
                                            child: Builder(
                                              builder: (context) {
                                                final imgs = widget
                                                        .data?.propertyImages
                                                        .toList() ??
                                                    const <String>[];
                                                if (imgs.isEmpty) {
                                                  return ClipRRect(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            8.0),
                                                    child: Container(
                                                      width: double.infinity,
                                                      height: (MediaQuery
                                                                      .sizeOf(
                                                                          context)
                                                                  .height *
                                                              0.28)
                                                          .clamp(180.0, 260.0),
                                                      color: FlutterFlowTheme
                                                              .of(context)
                                                          .accent1,
                                                      child: Icon(
                                                        Icons
                                                            .home_work_outlined,
                                                        size: 40.0,
                                                        color: FlutterFlowTheme
                                                                .of(context)
                                                            .secondaryText,
                                                      ),
                                                    ),
                                                  );
                                                }
                                                return SizedBox(
                                                  height: (MediaQuery.sizeOf(
                                                                  context)
                                                              .height *
                                                          0.28)
                                                      .clamp(180.0, 260.0),
                                                  child: Stack(
                                                    children: [
                                                      PageView.builder(
                                                        itemCount: imgs.length,
                                                        itemBuilder:
                                                            (context, i) =>
                                                                InkWell(
                                                          onTap: () async {
                                                            await _openGallery(
                                                                i);
                                                          },
                                                          child: ClipRRect(
                                                            borderRadius:
                                                                BorderRadius
                                                                    .circular(
                                                                        8.0),
                                                            child:
                                                                Image.network(
                                                              imgs[i],
                                                              width: double
                                                                  .infinity,
                                                              fit: BoxFit
                                                                  .cover,
                                                              errorBuilder: (_,
                                                                      __,
                                                                      ___) =>
                                                                  Container(
                                                                color: FlutterFlowTheme.of(
                                                                        context)
                                                                    .accent1,
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                      // شارة عدد الصور
                                                      Positioned(
                                                        bottom: 10.0,
                                                        right: 10.0,
                                                        child: Container(
                                                          padding: EdgeInsets
                                                              .symmetric(
                                                                  horizontal:
                                                                      10.0,
                                                                  vertical:
                                                                      5.0),
                                                          decoration:
                                                              BoxDecoration(
                                                            color: Colors
                                                                .black54,
                                                            borderRadius:
                                                                BorderRadius
                                                                    .circular(
                                                                        14.0),
                                                          ),
                                                          child: Row(
                                                            mainAxisSize:
                                                                MainAxisSize
                                                                    .min,
                                                            children: [
                                                              Icon(
                                                                Icons
                                                                    .photo_library_outlined,
                                                                size: 14.0,
                                                                color: Colors
                                                                    .white,
                                                              ),
                                                              SizedBox(
                                                                  width: 5.0),
                                                              Text(
                                                                '${imgs.length}',
                                                                style: TextStyle(
                                                                    color: Colors
                                                                        .white,
                                                                    fontSize:
                                                                        12.0),
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                );
                                              },
                                            ),
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                  Align(
                                    alignment: AlignmentDirectional(0.0, 1.0),
                                    child: Padding(
                                      padding: EdgeInsetsDirectional.fromSTEB(
                                          0.0, 0.0, 0.0, 12.0),
                                      child: smooth_page_indicator
                                          .SmoothPageIndicator(
                                        controller:
                                            _model.pageViewController ??=
                                                PageController(initialPage: 0),
                                        count: 1,
                                        axisDirection: Axis.horizontal,
                                        onDotClicked: (i) async {
                                          await _model.pageViewController!
                                              .animateToPage(
                                            i,
                                            duration:
                                                Duration(milliseconds: 500),
                                            curve: Curves.ease,
                                          );
                                          safeSetState(() {});
                                        },
                                        effect:
                                            smooth_page_indicator.SlideEffect(
                                          spacing: 8.0,
                                          radius: 8.0,
                                          dotWidth: 8.0,
                                          dotHeight: 8.0,
                                          dotColor: Color(0x69FFFFFF),
                                          activeDotColor: Colors.white,
                                          paintStyle: PaintingStyle.fill,
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Padding(
                              padding: EdgeInsetsDirectional.fromSTEB(
                                  0.0, 0.0, 0.0, 7.0),
                              child: Container(
                                width: 100.0,
                                height: 18.0,
                                decoration: BoxDecoration(
                                  color: Color(0x46FFFFFF),
                                  borderRadius: BorderRadius.circular(80.0),
                                ),
                              ),
                            ),
                          ],
                        ),
                        Padding(
                          padding: EdgeInsetsDirectional.fromSTEB(
                              8.0, 15.0, 8.0, 0.0),
                          child: Row(
                            mainAxisSize: MainAxisSize.max,
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              FlutterFlowIconButton(
                                borderColor: Colors.transparent,
                                borderRadius: 50.0,
                                buttonSize: 45.0,
                                fillColor: FlutterFlowTheme.of(context)
                                    .secondaryBackground,
                                icon: Icon(
                                  FFIcons.karrowLeft,
                                  color:
                                      FlutterFlowTheme.of(context).primaryText,
                                  size: 24.0,
                                ),
                                onPressed: () async {
                                  await Future.delayed(
                                    Duration(
                                      milliseconds: 100,
                                    ),
                                  );
                                  context.safePop();
                                },
                              ).animateOnPageLoad(animationsMap[
                                  'iconButtonOnPageLoadAnimation']!),
                              Row(
                                mainAxisSize: MainAxisSize.max,
                                children: [
                                  Container(
                                    width: 45.0,
                                    height: 45.0,
                                    decoration: BoxDecoration(
                                      color: FlutterFlowTheme.of(context)
                                          .secondaryBackground,
                                      shape: BoxShape.circle,
                                    ),
                                    child: Padding(
                                      padding: EdgeInsetsDirectional.fromSTEB(
                                          0.0, 2.0, 0.0, 0.0),
                                      child: ToggleIcon(
                                        onPressed: () async {
                                          final favRef =
                                              widget!.data?.reference;
                                          if (favRef == null ||
                                              currentUserReference == null) {
                                            if (currentUserReference == null) {
  ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(
                              content: Text('سجّل دخولك لحفظ العقارات في المفضلة'),
                            ),
                          );
                          return;
}
return;
                                          }
                                          final wasFav = FFAppState()
                                              .favoritesList
                                              .contains(favRef);
                                          safeSetState(
                                            () => wasFav
                                                ? FFAppState()
                                                    .removeFromFavoritesList(
                                                        favRef)
                                                : FFAppState()
                                                    .addToFavoritesList(
                                                        favRef),
                                          );
                                          await currentUserReference!.update({
                                            'favorites': wasFav
                                                ? FieldValue.arrayRemove(
                                                    [favRef])
                                                : FieldValue.arrayUnion(
                                                    [favRef]),
                                          });
                                          if (FFAppState()
                                              .favoritesList
                                              .contains(
                                                  widget!.data?.reference)) {
                                            await showModalBottomSheet(
                                              isScrollControlled: true,
                                              backgroundColor:
                                                  FlutterFlowTheme.of(context)
                                                      .accent4,
                                              barrierColor:
                                                  FlutterFlowTheme.of(context)
                                                      .accent4,
                                              enableDrag: false,
                                              context: context,
                                              builder: (context) {
                                                return GestureDetector(
                                                  onTap: () {
                                                    FocusScope.of(context)
                                                        .unfocus();
                                                    FocusManager
                                                        .instance.primaryFocus
                                                        ?.unfocus();
                                                  },
                                                  child: Padding(
                                                    padding:
                                                        MediaQuery.viewInsetsOf(
                                                            context),
                                                    child: SnackBarWidget(),
                                                  ),
                                                );
                                              },
                                            ).then(
                                                (value) => safeSetState(() {}));
                                          }
                                        },
                                        value: FFAppState()
                                            .favoritesList
                                            .contains(widget!.data?.reference),
                                        onIcon: Icon(
                                          FFIcons
                                              .kfavorite18dp000000FILL1Wght400GRAD0Opsz201,
                                          color: FlutterFlowTheme.of(context)
                                              .primaryText,
                                          size: 27.0,
                                        ),
                                        offIcon: Icon(
                                          FFIcons
                                              .kfavorite18dp000000FILL0Wght400GRAD0Opsz20,
                                          color: FlutterFlowTheme.of(context)
                                              .primaryText,
                                          size: 27.0,
                                        ),
                                      ),
                                    ),
                                  ),
                                  // زر الإجراء الإداري — للمدير فقط
                                  if (currentUserIsAdmin)
                                    Padding(
                                      padding: EdgeInsetsDirectional.fromSTEB(
                                          10.0, 0.0, 0.0, 0.0),
                                      child: FlutterFlowIconButton(
                                        borderColor: Colors.transparent,
                                        borderRadius: 50.0,
                                        buttonSize: 45.0,
                                        fillColor: FlutterFlowTheme.of(context)
                                            .error,
                                        icon: Icon(
                                          Icons.shield_outlined,
                                          color: Colors.white,
                                          size: 22.0,
                                        ),
                                        onPressed: () async {
                                          await _adminAction();
                                        },
                                      ),
                                    ),
                                  // زر مشاركة الإعلان
                                  Padding(
                                    padding: EdgeInsetsDirectional.fromSTEB(
                                        10.0, 0.0, 0.0, 0.0),
                                    child: FlutterFlowIconButton(
                                      borderColor: Colors.transparent,
                                      borderRadius: 50.0,
                                      buttonSize: 45.0,
                                      fillColor: FlutterFlowTheme.of(context)
                                          .secondaryBackground,
                                      icon: Icon(
                                        FFIcons.kshare,
                                        color: FlutterFlowTheme.of(context)
                                            .primaryText,
                                        size: 22.0,
                                      ),
                                      onPressed: () async {
                                        await _shareProperty();
                                      },
                                    ),
                                  ),
                                  Padding(
                                    padding: EdgeInsetsDirectional.fromSTEB(
                                        10.0, 0.0, 0.0, 0.0),
                                    child: FlutterFlowIconButton(
                                      borderColor: Colors.transparent,
                                      borderRadius: 50.0,
                                      buttonSize: 45.0,
                                      fillColor: FlutterFlowTheme.of(context)
                                          .secondaryBackground,
                                      icon: Icon(
                                        FFIcons.kdots,
                                        color: FlutterFlowTheme.of(context)
                                            .primaryText,
                                        size: 24.0,
                                      ),
                                      onPressed: () async {
                                        await showModalBottomSheet(
                                          isScrollControlled: true,
                                          backgroundColor:
                                              FlutterFlowTheme.of(context)
                                                  .accent4,
                                          barrierColor:
                                              FlutterFlowTheme.of(context)
                                                  .barier,
                                          context: context,
                                          builder: (context) {
                                            return GestureDetector(
                                              onTap: () {
                                                FocusScope.of(context)
                                                    .unfocus();
                                                FocusManager
                                                    .instance.primaryFocus
                                                    ?.unfocus();
                                              },
                                              child: Padding(
                                                padding:
                                                    MediaQuery.viewInsetsOf(
                                                        context),
                                                child: SingleOptions2Widget(
                                                    property: widget.data),
                                              ),
                                            );
                                          },
                                        ).then((value) => safeSetState(() {}));
                                      },
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(0.0, 10.0, 0.0, 0.0),
                      child: SingleChildScrollView(
                        scrollDirection: Axis.horizontal,
                        child: Row(
                          mainAxisSize: MainAxisSize.max,
                          children: [
                            Container(
                              width: 80.0,
                              height: 80.0,
                              decoration: BoxDecoration(
                                color: FlutterFlowTheme.of(context).accent1,
                                borderRadius: BorderRadius.circular(8.0),
                              ),
                            ),
                          ]
                              .divide(SizedBox(width: 10.0))
                              .addToStart(SizedBox(width: 10.0))
                              .addToEnd(SizedBox(width: 10.0)),
                        ),
                      ),
                    ),
                    Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(15.0, 15.0, 15.0, 0.0),
                      child: Text(
                        '',
                        style:
                            FlutterFlowTheme.of(context).headlineLarge.override(
                                  font: GoogleFonts.cairo(
                                    fontWeight: FontWeight.w500,
                                    fontStyle: FlutterFlowTheme.of(context)
                                        .headlineLarge
                                        .fontStyle,
                                  ),
                                  fontSize: 18.0,
                                  letterSpacing: 0.0,
                                  fontWeight: FontWeight.w500,
                                  fontStyle: FlutterFlowTheme.of(context)
                                      .headlineLarge
                                      .fontStyle,
                                ),
                      ),
                    ),
                    Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(15.0, 15.0, 15.0, 0.0),
                      child: Row(
                        mainAxisSize: MainAxisSize.max,
                        children: [
                          Text(
                            // السعر بالدينار الكويتي من سجل الإعلان حصراً
                            (widget!.data?.price ?? 0) > 0
                                ? '${widget!.data!.price.toStringAsFixed(0)} KD'
                                : 'السعر عند الاتصال',
                            style: FlutterFlowTheme.of(context)
                                .headlineMedium
                                .override(
                                  font: GoogleFonts.cairo(
                                    fontWeight: FlutterFlowTheme.of(context)
                                        .headlineMedium
                                        .fontWeight,
                                    fontStyle: FlutterFlowTheme.of(context)
                                        .headlineMedium
                                        .fontStyle,
                                  ),
                                  letterSpacing: 0.0,
                                  fontWeight: FlutterFlowTheme.of(context)
                                      .headlineMedium
                                      .fontWeight,
                                  fontStyle: FlutterFlowTheme.of(context)
                                      .headlineMedium
                                      .fontStyle,
                                ),
                          ),
                        ],
                      ),
                    ),
                    Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(15.0, 12.0, 0.0, 0.0),
                      child: Text(
                        'قدّم عرض سعرك',
                        style: FlutterFlowTheme.of(context)
                            .labelMedium
                            .override(
                              font: GoogleFonts.cairo(
                                fontWeight: FlutterFlowTheme.of(context)
                                    .labelMedium
                                    .fontWeight,
                                fontStyle: FlutterFlowTheme.of(context)
                                    .labelMedium
                                    .fontStyle,
                              ),
                              color: FlutterFlowTheme.of(context).secondaryText,
                              letterSpacing: 0.0,
                              fontWeight: FlutterFlowTheme.of(context)
                                  .labelMedium
                                  .fontWeight,
                              fontStyle: FlutterFlowTheme.of(context)
                                  .labelMedium
                                  .fontStyle,
                            ),
                      ),
                    ),
                    Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(15.0, 10.0, 15.0, 0.0),
                      child: Row(
                        mainAxisSize: MainAxisSize.max,
                        children: [
                          Expanded(
                            child: Form(
                              key: _model.formKey,
                              autovalidateMode: AutovalidateMode.disabled,
                              child: Container(
                                width: 150.0,
                                height: 50.0,
                                decoration: BoxDecoration(
                                  color: FlutterFlowTheme.of(context).accent1,
                                  borderRadius: BorderRadius.circular(10.0),
                                ),
                                child: Container(
                                  width: double.infinity,
                                  child: TextFormField(
                                    controller: _model.textController,
                                    focusNode: _model.textFieldFocusNode,
                                    autofocus: false,
                                    obscureText: false,
                                    decoration: InputDecoration(
                                      isDense: false,
                                      // حقل فارغ تماماً — المستخدم يكتب سعره
                                      hintText: '',
                                      suffixIcon: Padding(
                                        padding:
                                            EdgeInsetsDirectional.fromSTEB(
                                                0.0, 0.0, 12.0, 0.0),
                                        child: Text(
                                          'KD',
                                          style: FlutterFlowTheme.of(context)
                                              .titleSmall
                                              .override(
                                                font: GoogleFonts.cairo(
                                                    fontWeight:
                                                        FontWeight.w600),
                                                color:
                                                    FlutterFlowTheme.of(context)
                                                        .secondary,
                                                letterSpacing: 0.0,
                                              ),
                                        ),
                                      ),
                                      hintStyle: FlutterFlowTheme.of(context)
                                          .titleSmall
                                          .override(
                                            font: GoogleFonts.cairo(
                                              fontWeight:
                                                  FlutterFlowTheme.of(context)
                                                      .titleSmall
                                                      .fontWeight,
                                              fontStyle:
                                                  FlutterFlowTheme.of(context)
                                                      .titleSmall
                                                      .fontStyle,
                                            ),
                                            color: FlutterFlowTheme.of(context)
                                                .secondaryText,
                                            letterSpacing: 0.0,
                                            fontWeight:
                                                FlutterFlowTheme.of(context)
                                                    .titleSmall
                                                    .fontWeight,
                                            fontStyle:
                                                FlutterFlowTheme.of(context)
                                                    .titleSmall
                                                    .fontStyle,
                                          ),
                                      errorStyle: FlutterFlowTheme.of(context)
                                          .labelMedium
                                          .override(
                                            font: GoogleFonts.cairo(
                                              fontWeight:
                                                  FlutterFlowTheme.of(context)
                                                      .labelMedium
                                                      .fontWeight,
                                              fontStyle:
                                                  FlutterFlowTheme.of(context)
                                                      .labelMedium
                                                      .fontStyle,
                                            ),
                                            color: FlutterFlowTheme.of(context)
                                                .error,
                                            fontSize: 0.0,
                                            letterSpacing: 0.0,
                                            fontWeight:
                                                FlutterFlowTheme.of(context)
                                                    .labelMedium
                                                    .fontWeight,
                                            fontStyle:
                                                FlutterFlowTheme.of(context)
                                                    .labelMedium
                                                    .fontStyle,
                                          ),
                                      enabledBorder: OutlineInputBorder(
                                        borderSide: BorderSide(
                                          color: Color(0x00000000),
                                          width: 1.0,
                                        ),
                                        borderRadius:
                                            BorderRadius.circular(10.0),
                                      ),
                                      focusedBorder: OutlineInputBorder(
                                        borderSide: BorderSide(
                                          color: Color(0x00000000),
                                          width: 1.0,
                                        ),
                                        borderRadius:
                                            BorderRadius.circular(10.0),
                                      ),
                                      errorBorder: OutlineInputBorder(
                                        borderSide: BorderSide(
                                          color: FlutterFlowTheme.of(context)
                                              .error,
                                          width: 1.0,
                                        ),
                                        borderRadius:
                                            BorderRadius.circular(10.0),
                                      ),
                                      focusedErrorBorder: OutlineInputBorder(
                                        borderSide: BorderSide(
                                          color: FlutterFlowTheme.of(context)
                                              .error,
                                          width: 1.0,
                                        ),
                                        borderRadius:
                                            BorderRadius.circular(10.0),
                                      ),
                                      contentPadding:
                                          EdgeInsetsDirectional.fromSTEB(
                                              15.0, 0.0, 0.0, 0.0),
                                    ),
                                    style: FlutterFlowTheme.of(context)
                                        .titleSmall
                                        .override(
                                          font: GoogleFonts.cairo(
                                            fontWeight:
                                                FlutterFlowTheme.of(context)
                                                    .titleSmall
                                                    .fontWeight,
                                            fontStyle:
                                                FlutterFlowTheme.of(context)
                                                    .titleSmall
                                                    .fontStyle,
                                          ),
                                          letterSpacing: 0.0,
                                          fontWeight:
                                              FlutterFlowTheme.of(context)
                                                  .titleSmall
                                                  .fontWeight,
                                          fontStyle:
                                              FlutterFlowTheme.of(context)
                                                  .titleSmall
                                                  .fontStyle,
                                        ),
                                    cursorColor: FlutterFlowTheme.of(context)
                                        .primaryText,
                                    validator: _model.textControllerValidator
                                        .asValidator(context),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Builder(
                            builder: (context) => FFButtonWidget(
                              onPressed: () async {
                                if (_model.formKey.currentState == null ||
                                    !_model.formKey.currentState!.validate()) {
                                  return;
                                }
                                final offerText =
                                    _model.textController.text.trim();
                                final offerOwner = widget.data?.ownerRef;
                                if (offerText.isEmpty ||
                                    offerOwner == null ||
                                    offerOwner == currentUserReference) {
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    SnackBar(
                                      content: Text(
                                          'لا يمكن إرسال عرض لهذا الإعلان'),
                                      backgroundColor:
                                          FlutterFlowTheme.of(context).error,
                                    ),
                                  );
                                  return;
                                }
                                final offerChat =
                                    await getOrCreateChat(offerOwner,
                                        propertyRef: widget.data?.reference);
                                final offerMsg =
                                    'عرض سعر على "${widget.data?.title}": $offerText د.ك';
                                await sendChatMessage(
                                  chatRef: offerChat,
                                  text: offerMsg,
                                
                                  type: 'offer',);
                                safeSetState(() {
                                  _model.textController?.clear();
                                });
                                if (!context.mounted) {
                                  return;
                                }
                                await showDialog(
                                  barrierColor:
                                      FlutterFlowTheme.of(context).barier,
                                  context: context,
                                  builder: (dialogContext) {
                                    return Dialog(
                                      elevation: 0,
                                      insetPadding: EdgeInsets.zero,
                                      backgroundColor: Colors.transparent,
                                      alignment: AlignmentDirectional(0.0, 0.0)
                                          .resolve(Directionality.of(context)),
                                      child: GestureDetector(
                                        onTap: () {
                                          FocusScope.of(dialogContext)
                                              .unfocus();
                                          FocusManager.instance.primaryFocus
                                              ?.unfocus();
                                        },
                                        child: SentPriceOfferWidget(),
                                      ),
                                    );
                                  },
                                );
                              },
                              text: '',
                              icon: Icon(
                                FFIcons.karrowRight,
                                size: 25.0,
                              ),
                              options: FFButtonOptions(
                                width: 55.0,
                                height: 48.0,
                                padding: EdgeInsetsDirectional.fromSTEB(
                                    16.0, 0.0, 16.0, 0.0),
                                iconAlignment: IconAlignment.start,
                                iconPadding: EdgeInsetsDirectional.fromSTEB(
                                    0.0, 0.0, 10.0, 0.0),
                                color: FlutterFlowTheme.of(context).primary,
                                textStyle: FlutterFlowTheme.of(context)
                                    .titleSmall
                                    .override(
                                      font: GoogleFonts.cairo(
                                        fontWeight: FontWeight.w500,
                                        fontStyle: FlutterFlowTheme.of(context)
                                            .titleSmall
                                            .fontStyle,
                                      ),
                                      color: Colors.white,
                                      letterSpacing: 0.0,
                                      fontWeight: FontWeight.w500,
                                      fontStyle: FlutterFlowTheme.of(context)
                                          .titleSmall
                                          .fontStyle,
                                    ),
                                elevation: 0.0,
                                borderRadius: BorderRadius.circular(10.0),
                              ),
                              showLoadingIndicator: false,
                            ),
                          ),
                        ].divide(SizedBox(width: 10.0)),
                      ),
                    ),
                    // ===== التقسيم الداخلي الكامل — من سجل الإعلان =====
                    Builder(
                      builder: (context) {
                        final d = widget.data;
                        if (d == null) return SizedBox.shrink();
                        // الحقول المعروضة تتبع تصنيف العقار — لا تظهر
                        // حقول الفلل في محل تجاري ولا في شاليه.
                        final fields =
                            FFAppConstants.FieldsByCategory[d.category] ??
                                const <String>[];
                        final rows = <List<String>>[
                          if (fields.contains('units') && d.units > 0)
                            ['عدد الوحدات', '${d.units}'],
                          if (fields.contains('floors') && d.floors > 0)
                            ['عدد الأدوار', '${d.floors}'],
                          if (fields.contains('masterRooms') &&
                              d.masterRooms > 0)
                            ['غرف الماستر', '${d.masterRooms}'],
                          if (fields.contains('rooms') && d.rooms > 0)
                            ['الغرف', '${d.rooms}'],
                          if (fields.contains('halls') && d.halls > 0)
                            ['الصالات', '${d.halls}'],
                          if (fields.contains('kitchens') && d.kitchens > 0)
                            ['المطابخ', '${d.kitchens}'],
                          if (fields.contains('diwaniyas') && d.diwaniyas > 0)
                            ['الدواوين', '${d.diwaniyas}'],
                          if (fields.contains('bathrooms') && d.bathrooms > 0)
                            ['الحمامات', '${d.bathrooms}'],
                          if (fields.contains('maidRoom'))
                            ['غرفة خادمة', d.maidRoom ? 'نعم' : 'لا'],
                          if (fields.contains('laundryRoom'))
                            ['غرفة غسيل', d.laundryRoom ? 'نعم' : 'لا'],
                          if (fields.contains('frontage') &&
                              d.frontage.trim().isNotEmpty)
                            ['عرض الواجهة', '${d.frontage.trim()} م'],
                          if (d.size.trim().isNotEmpty)
                            ['المساحة', '${d.size.trim()} م²'],
                        ];
                        if (rows.isEmpty) return SizedBox.shrink();
                        return Padding(
                          padding: EdgeInsetsDirectional.fromSTEB(
                              15.0, 20.0, 15.0, 0.0),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Text(
                                'التقسيم الداخلي',
                                style: FlutterFlowTheme.of(context)
                                    .headlineSmall
                                    .override(
                                      font: GoogleFonts.cairo(
                                          fontWeight: FontWeight.w600),
                                      letterSpacing: 0.0,
                                    ),
                              ),
                              SizedBox(height: 10.0),
                              Container(
                                decoration: BoxDecoration(
                                  color: FlutterFlowTheme.of(context).accent1,
                                  borderRadius: BorderRadius.circular(12.0),
                                ),
                                padding: EdgeInsets.symmetric(
                                    horizontal: 14.0, vertical: 6.0),
                                child: Column(
                                  mainAxisSize: MainAxisSize.min,
                                  children: rows
                                      .map((r) => Padding(
                                            padding: EdgeInsets.symmetric(
                                                vertical: 7.0),
                                            child: Row(
                                              children: [
                                                Expanded(
                                                  child: Text(
                                                    r[0],
                                                    style: FlutterFlowTheme.of(
                                                            context)
                                                        .bodyMedium
                                                        .override(
                                                          font: GoogleFonts
                                                              .cairo(),
                                                          color: FlutterFlowTheme
                                                                  .of(context)
                                                              .secondaryText,
                                                          letterSpacing: 0.0,
                                                        ),
                                                  ),
                                                ),
                                                Text(
                                                  r[1],
                                                  style: FlutterFlowTheme.of(
                                                          context)
                                                      .bodyMedium
                                                      .override(
                                                        font: GoogleFonts.cairo(
                                                            fontWeight:
                                                                FontWeight.w600),
                                                        letterSpacing: 0.0,
                                                      ),
                                                ),
                                              ],
                                            ),
                                          ))
                                      .toList(),
                                ),
                              ),
                            ],
                          ),
                        );
                      },
                    ),

                    // ===== المميزات التي اختارها المعلن فقط =====
                    Builder(
                      builder: (context) {
                        final f = widget.data?.features ?? const <String>[];
                        if (f.isEmpty) return SizedBox.shrink();
                        return Padding(
                          padding: EdgeInsetsDirectional.fromSTEB(
                              15.0, 20.0, 15.0, 0.0),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Text(
                                'مميزات العقار',
                                style: FlutterFlowTheme.of(context)
                                    .headlineSmall
                                    .override(
                                      font: GoogleFonts.cairo(
                                          fontWeight: FontWeight.w600),
                                      letterSpacing: 0.0,
                                    ),
                              ),
                              SizedBox(height: 10.0),
                              Wrap(
                                spacing: 8.0,
                                runSpacing: 8.0,
                                children: f
                                    .map((x) => Container(
                                          padding: EdgeInsets.symmetric(
                                              horizontal: 12.0, vertical: 8.0),
                                          decoration: BoxDecoration(
                                            color: FlutterFlowTheme.of(context)
                                                .accent1,
                                            borderRadius:
                                                BorderRadius.circular(10.0),
                                          ),
                                          child: Row(
                                            mainAxisSize: MainAxisSize.min,
                                            children: [
                                              Icon(
                                                Icons.check_circle_rounded,
                                                size: 15.0,
                                                color:
                                                    FlutterFlowTheme.of(context)
                                                        .secondary,
                                              ),
                                              SizedBox(width: 6.0),
                                              Text(
                                                x,
                                                style: FlutterFlowTheme.of(
                                                        context)
                                                    .bodyMedium
                                                    .override(
                                                      font:
                                                          GoogleFonts.cairo(),
                                                      letterSpacing: 0.0,
                                                    ),
                                              ),
                                            ],
                                          ),
                                        ))
                                    .toList(),
                              ),
                            ],
                          ),
                        );
                      },
                    ),
                    Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(15.0, 20.0, 0.0, 0.0),
                      child: Text(
                        'الوصف',
                        style:
                            FlutterFlowTheme.of(context).headlineSmall.override(
                                  font: GoogleFonts.cairo(
                                    fontWeight: FlutterFlowTheme.of(context)
                                        .headlineSmall
                                        .fontWeight,
                                    fontStyle: FlutterFlowTheme.of(context)
                                        .headlineSmall
                                        .fontStyle,
                                  ),
                                  letterSpacing: 0.0,
                                  fontWeight: FlutterFlowTheme.of(context)
                                      .headlineSmall
                                      .fontWeight,
                                  fontStyle: FlutterFlowTheme.of(context)
                                      .headlineSmall
                                      .fontStyle,
                                ),
                      ),
                    ),
                    Column(
                      mainAxisSize: MainAxisSize.max,
                      children: [
                        AnimatedContainer(
                          duration: Duration(milliseconds: 250),
                          curve: Curves.easeInOut,
                          width: double.infinity,
                          height: valueOrDefault<double>(
                            _model.isFullDescription == true ? 595.0 : 110.0,
                            110.0,
                          ),
                          decoration: BoxDecoration(
                            color: FlutterFlowTheme.of(context)
                                .secondaryBackground,
                          ),
                          child: Align(
                            alignment: AlignmentDirectional(-1.0, -1.0),
                            child: Padding(
                              padding: EdgeInsetsDirectional.fromSTEB(
                                  15.0, 15.0, 15.0, 0.0),
                              child: Text(
                                (widget.data?.description ?? '')
                                        .trim()
                                        .isNotEmpty
                                    ? widget.data!.description.trim()
                                    : 'لم يضف المالك وصفاً تفصيلياً لهذا العقار.',
                                style: FlutterFlowTheme.of(context)
                                    .titleSmall
                                    .override(
                                      font: GoogleFonts.cairo(
                                        fontWeight: FlutterFlowTheme.of(context)
                                            .titleSmall
                                            .fontWeight,
                                        fontStyle: FlutterFlowTheme.of(context)
                                            .titleSmall
                                            .fontStyle,
                                      ),
                                      letterSpacing: 0.0,
                                      fontWeight: FlutterFlowTheme.of(context)
                                          .titleSmall
                                          .fontWeight,
                                      fontStyle: FlutterFlowTheme.of(context)
                                          .titleSmall
                                          .fontStyle,
                                    ),
                              ),
                            ),
                          ),
                        ),
                        Padding(
                          padding: EdgeInsetsDirectional.fromSTEB(
                              15.0, 0.0, 15.0, 0.0),
                          child: InkWell(
                            splashColor: Colors.transparent,
                            focusColor: Colors.transparent,
                            hoverColor: Colors.transparent,
                            highlightColor: Colors.transparent,
                            onTap: () async {
                              if (_model.isFullDescription) {
                                _model.isFullDescription = false;
                                safeSetState(() {});
                              } else {
                                _model.isFullDescription = true;
                                safeSetState(() {});
                              }
                            },
                            child: Row(
                              mainAxisSize: MainAxisSize.max,
                              children: [
                                Text(
                                  _model.isFullDescription == true
                                      ? 'عرض أقل'
                                      : 'عرض المزيد',
                                  style: FlutterFlowTheme.of(context)
                                      .titleSmall
                                      .override(
                                        font: GoogleFonts.cairo(
                                          fontWeight: FontWeight.w500,
                                          fontStyle:
                                              FlutterFlowTheme.of(context)
                                                  .titleSmall
                                                  .fontStyle,
                                        ),
                                        color: FlutterFlowTheme.of(context)
                                            .primary,
                                        letterSpacing: 0.0,
                                        fontWeight: FontWeight.w500,
                                        fontStyle: FlutterFlowTheme.of(context)
                                            .titleSmall
                                            .fontStyle,
                                      ),
                                ),
                                if (_model.isFullDescription == false)
                                  Padding(
                                    padding: EdgeInsetsDirectional.fromSTEB(
                                        10.0, 1.0, 0.0, 0.0),
                                    child: Icon(
                                      FFIcons.kchevronDown,
                                      color:
                                          FlutterFlowTheme.of(context).primary,
                                      size: 24.0,
                                    ),
                                  ),
                                if (_model.isFullDescription == true)
                                  Padding(
                                    padding: EdgeInsetsDirectional.fromSTEB(
                                        10.0, 0.0, 0.0, 0.0),
                                    child: Icon(
                                      FFIcons.kchevronUp,
                                      color:
                                          FlutterFlowTheme.of(context).primary,
                                      size: 24.0,
                                    ),
                                  ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                    Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(0.0, 16.0, 0.0, 25.0),
                      child: Container(
                        width: double.infinity,
                        height: 10.0,
                        decoration: BoxDecoration(
                          color: FlutterFlowTheme.of(context).primaryBackground,
                        ),
                      ),
                    ),
                    // قسم "ما يميز هذا العقار" — من مميزات الإعلان المحفوظة حصراً.
                    // كان يعرض FFAppConstants.Whatsspecial (قائمة ثابتة من القالب)
                    // فتظهر نفس المميزات في كل إعلان بلا اختيار المعلن.
                    Builder(
                      builder: (context) {
                        final specialList = widget.data?.features ?? const <String>[];
                        if (specialList.isEmpty) {
                          // لم يختر المعلن أي ميزة — لا يظهر القسم إطلاقاً
                          return SizedBox.shrink();
                        }
                        return Padding(
                          padding: EdgeInsetsDirectional.fromSTEB(15.0, 20.0, 15.0, 0.0),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Text(
                                'ما يميز هذا العقار',
                                style: FlutterFlowTheme.of(context).headlineSmall.override(
                                      font: GoogleFonts.cairo(fontWeight: FontWeight.w600),
                                      letterSpacing: 0.0,
                                    ),
                              ),
                              SizedBox(height: 10.0),
                              Wrap(
                                spacing: 8.0,
                                runSpacing: 8.0,
                                children: specialList
                                    .map((item) => Container(
                                          padding: EdgeInsets.symmetric(
                                              horizontal: 12.0, vertical: 8.0),
                                          decoration: BoxDecoration(
                                            color: FlutterFlowTheme.of(context).accent1,
                                            borderRadius: BorderRadius.circular(10.0),
                                          ),
                                          child: Row(
                                            mainAxisSize: MainAxisSize.min,
                                            children: [
                                              Icon(
                                                Icons.star_rounded,
                                                size: 15.0,
                                                color: FlutterFlowTheme.of(context).secondary,
                                              ),
                                              SizedBox(width: 6.0),
                                              Text(
                                                item,
                                                style: FlutterFlowTheme.of(context)
                                                    .bodyMedium
                                                    .override(
                                                      font: GoogleFonts.cairo(),
                                                      letterSpacing: 0.0,
                                                    ),
                                              ),
                                            ],
                                          ),
                                        ))
                                    .toList(),
                              ),
                            ],
                          ),
                        );
                      },
                    ),
                    Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(15.0, 16.0, 0.0, 0.0),
                      child: Text(
                        'الحقائق والمواصفات',
                        style:
                            FlutterFlowTheme.of(context).headlineSmall.override(
                                  font: GoogleFonts.cairo(
                                    fontWeight: FlutterFlowTheme.of(context)
                                        .headlineSmall
                                        .fontWeight,
                                    fontStyle: FlutterFlowTheme.of(context)
                                        .headlineSmall
                                        .fontStyle,
                                  ),
                                  letterSpacing: 0.0,
                                  fontWeight: FlutterFlowTheme.of(context)
                                      .headlineSmall
                                      .fontWeight,
                                  fontStyle: FlutterFlowTheme.of(context)
                                      .headlineSmall
                                      .fontStyle,
                                ),
                      ),
                    ),
                    Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(15.0, 15.0, 0.0, 0.0),
                      child: Column(
                        mainAxisSize: MainAxisSize.max,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'غرف النوم والحمامات',
                            style: FlutterFlowTheme.of(context)
                                .titleSmall
                                .override(
                                  font: GoogleFonts.cairo(
                                    fontWeight: FontWeight.w600,
                                    fontStyle: FlutterFlowTheme.of(context)
                                        .titleSmall
                                        .fontStyle,
                                  ),
                                  letterSpacing: 0.0,
                                  fontWeight: FontWeight.w600,
                                  fontStyle: FlutterFlowTheme.of(context)
                                      .titleSmall
                                      .fontStyle,
                                ),
                          ),
                          Padding(
                            padding: EdgeInsetsDirectional.fromSTEB(
                                0.0, 8.0, 0.0, 0.0),
                            child: Text(
                              '${widget.data?.rooms ?? 0} غرف • ${widget.data?.bathrooms ?? 0} حمامات',
                              style: FlutterFlowTheme.of(context)
                                  .titleSmall
                                  .override(
                                    font: GoogleFonts.cairo(
                                      fontWeight: FlutterFlowTheme.of(context)
                                          .titleSmall
                                          .fontWeight,
                                      fontStyle: FlutterFlowTheme.of(context)
                                          .titleSmall
                                          .fontStyle,
                                    ),
                                    letterSpacing: 0.0,
                                    fontWeight: FlutterFlowTheme.of(context)
                                        .titleSmall
                                        .fontWeight,
                                    fontStyle: FlutterFlowTheme.of(context)
                                        .titleSmall
                                        .fontStyle,
                                  ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(15.0, 15.0, 0.0, 0.0),
                      child: Column(
                        mainAxisSize: MainAxisSize.max,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'المساحة الداخلية',
                            style: FlutterFlowTheme.of(context)
                                .titleSmall
                                .override(
                                  font: GoogleFonts.cairo(
                                    fontWeight: FontWeight.w600,
                                    fontStyle: FlutterFlowTheme.of(context)
                                        .titleSmall
                                        .fontStyle,
                                  ),
                                  letterSpacing: 0.0,
                                  fontWeight: FontWeight.w600,
                                  fontStyle: FlutterFlowTheme.of(context)
                                      .titleSmall
                                      .fontStyle,
                                ),
                          ),
                          Padding(
                            padding: EdgeInsetsDirectional.fromSTEB(
                                0.0, 8.0, 0.0, 0.0),
                            child: Text(
                              '${widget.data?.halls ?? 0} صالات • ${widget.data?.kitchens ?? 0} مطابخ',
                              style: FlutterFlowTheme.of(context)
                                  .titleSmall
                                  .override(
                                    font: GoogleFonts.cairo(
                                      fontWeight: FlutterFlowTheme.of(context)
                                          .titleSmall
                                          .fontWeight,
                                      fontStyle: FlutterFlowTheme.of(context)
                                          .titleSmall
                                          .fontStyle,
                                    ),
                                    letterSpacing: 0.0,
                                    fontWeight: FlutterFlowTheme.of(context)
                                        .titleSmall
                                        .fontWeight,
                                    fontStyle: FlutterFlowTheme.of(context)
                                        .titleSmall
                                        .fontStyle,
                                  ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(15.0, 16.0, 15.0, 0.0),
                      child: FFButtonWidget(
                        onPressed: () async {
                          context.pushNamed(SingleApartment2Widget.routeName);
                        },
                        text: 'عرض المزيد',
                        options: FFButtonOptions(
                          width: double.infinity,
                          height: 50.0,
                          padding: EdgeInsetsDirectional.fromSTEB(
                              16.0, 0.0, 16.0, 0.0),
                          iconPadding: EdgeInsetsDirectional.fromSTEB(
                              0.0, 0.0, 0.0, 0.0),
                          color: FlutterFlowTheme.of(context).accent1,
                          textStyle: FlutterFlowTheme.of(context)
                              .titleSmall
                              .override(
                                font: GoogleFonts.cairo(
                                  fontWeight: FontWeight.w500,
                                  fontStyle: FlutterFlowTheme.of(context)
                                      .titleSmall
                                      .fontStyle,
                                ),
                                color: FlutterFlowTheme.of(context).primaryText,
                                letterSpacing: 0.0,
                                fontWeight: FontWeight.w500,
                                fontStyle: FlutterFlowTheme.of(context)
                                    .titleSmall
                                    .fontStyle,
                              ),
                          elevation: 0.0,
                          borderRadius: BorderRadius.circular(10.0),
                        ),
                      ),
                    ),
                    Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(0.0, 16.0, 0.0, 25.0),
                      child: Container(
                        width: double.infinity,
                        height: 10.0,
                        decoration: BoxDecoration(
                          color: FlutterFlowTheme.of(context).primaryBackground,
                        ),
                      ),
                    ),
                    Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(15.0, 0.0, 0.0, 0.0),
                      child: Text(
                        'الموقع',
                        style:
                            FlutterFlowTheme.of(context).headlineSmall.override(
                                  font: GoogleFonts.cairo(
                                    fontWeight: FlutterFlowTheme.of(context)
                                        .headlineSmall
                                        .fontWeight,
                                    fontStyle: FlutterFlowTheme.of(context)
                                        .headlineSmall
                                        .fontStyle,
                                  ),
                                  letterSpacing: 0.0,
                                  fontWeight: FlutterFlowTheme.of(context)
                                      .headlineSmall
                                      .fontWeight,
                                  fontStyle: FlutterFlowTheme.of(context)
                                      .headlineSmall
                                      .fontStyle,
                                ),
                      ),
                    ),
                    Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(15.0, 15.0, 15.0, 0.0),
                      child: Stack(
                        alignment: AlignmentDirectional(1.0, -1.0),
                        children: [
                          Align(
                            alignment: AlignmentDirectional(0.0, 0.0),
                            child: InkWell(
                              splashColor: Colors.transparent,
                              focusColor: Colors.transparent,
                              hoverColor: Colors.transparent,
                              highlightColor: Colors.transparent,
                              onTap: () async {
                                await _openPropertyLocation();
                              },
                              child: Container(
                                width: double.infinity,
                                padding: EdgeInsets.all(16.0),
                                decoration: BoxDecoration(
                                  color: FlutterFlowTheme.of(context).accent1,
                                  borderRadius: BorderRadius.circular(10.0),
                                  border: Border.all(
                                    color:
                                        FlutterFlowTheme.of(context).alternate,
                                    width: 1.0,
                                  ),
                                ),
                                child: Column(
                                  mainAxisSize: MainAxisSize.min,
                                  crossAxisAlignment:
                                      CrossAxisAlignment.start,
                                  children: [
                                    Row(
                                      children: [
                                        Icon(
                                          Icons.location_on_rounded,
                                          size: 22.0,
                                          color: FlutterFlowTheme.of(context)
                                              .secondary,
                                        ),
                                        SizedBox(width: 8.0),
                                        Expanded(
                                          child: Text(
                                            _propertyAddressLine(),
                                            maxLines: 2,
                                            overflow: TextOverflow.ellipsis,
                                            style: FlutterFlowTheme.of(context)
                                                .titleSmall
                                                .override(
                                                  font: GoogleFonts.cairo(
                                                      fontWeight:
                                                          FontWeight.w600),
                                                  letterSpacing: 0.0,
                                                ),
                                          ),
                                        ),
                                      ],
                                    ),
                                    SizedBox(height: 10.0),
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: [
                                        Icon(
                                          Icons.map_outlined,
                                          size: 18.0,
                                          color: FlutterFlowTheme.of(context)
                                              .primary,
                                        ),
                                        SizedBox(width: 6.0),
                                        Text(
                                          'عرض الموقع على الخريطة',
                                          style: FlutterFlowTheme.of(context)
                                              .bodyMedium
                                              .override(
                                                font: GoogleFonts.cairo(
                                                    fontWeight:
                                                        FontWeight.w600),
                                                color:
                                                    FlutterFlowTheme.of(context)
                                                        .primary,
                                                letterSpacing: 0.0,
                                              ),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                          Padding(
                            padding: EdgeInsetsDirectional.fromSTEB(
                                0.0, 12.0, 12.0, 0.0),
                            child: InkWell(
                              splashColor: Colors.transparent,
                              focusColor: Colors.transparent,
                              hoverColor: Colors.transparent,
                              highlightColor: Colors.transparent,
                              onTap: () async {
                                context.pushNamed(
                                    SingleApartment3Widget.routeName);
                              },
                              child: Container(
                                width: 48.0,
                                height: 48.0,
                                decoration: BoxDecoration(
                                  color: FlutterFlowTheme.of(context)
                                      .secondaryBackground,
                                  boxShadow: [
                                    BoxShadow(
                                      blurRadius: 10.0,
                                      color: Color(0x1E000000),
                                      offset: Offset(
                                        0.0,
                                        2.0,
                                      ),
                                    )
                                  ],
                                  borderRadius: BorderRadius.circular(8.0),
                                ),
                                child: Align(
                                  alignment: AlignmentDirectional(0.0, 0.0),
                                  child: Icon(
                                    FFIcons.kexpand01,
                                    color: FlutterFlowTheme.of(context)
                                        .primaryText,
                                    size: 24.0,
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(15.0, 15.0, 15.0, 0.0),
                      child: Row(
                        mainAxisSize: MainAxisSize.max,
                        children: [
                          Icon(
                            FFIcons.kmapPin,
                            color: FlutterFlowTheme.of(context).primaryText,
                            size: 24.0,
                          ),
                          Padding(
                            padding: EdgeInsetsDirectional.fromSTEB(
                                15.0, 0.0, 0.0, 0.0),
                            child: Text(
                              '',
                              style: FlutterFlowTheme.of(context)
                                  .labelLarge
                                  .override(
                                    font: GoogleFonts.cairo(
                                      fontWeight: FlutterFlowTheme.of(context)
                                          .labelLarge
                                          .fontWeight,
                                      fontStyle: FlutterFlowTheme.of(context)
                                          .labelLarge
                                          .fontStyle,
                                    ),
                                    letterSpacing: 0.0,
                                    fontWeight: FlutterFlowTheme.of(context)
                                        .labelLarge
                                        .fontWeight,
                                    fontStyle: FlutterFlowTheme.of(context)
                                        .labelLarge
                                        .fontStyle,
                                  ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(15.0, 16.0, 0.0, 0.0),
                      child: Text(
                        'بيانات التواصل',
                        style:
                            FlutterFlowTheme.of(context).headlineSmall.override(
                                  font: GoogleFonts.cairo(
                                    fontWeight: FlutterFlowTheme.of(context)
                                        .headlineSmall
                                        .fontWeight,
                                    fontStyle: FlutterFlowTheme.of(context)
                                        .headlineSmall
                                        .fontStyle,
                                  ),
                                  letterSpacing: 0.0,
                                  fontWeight: FlutterFlowTheme.of(context)
                                      .headlineSmall
                                      .fontWeight,
                                  fontStyle: FlutterFlowTheme.of(context)
                                      .headlineSmall
                                      .fontStyle,
                                ),
                      ),
                    ),
                    Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(15.0, 15.0, 15.0, 0.0),
                      child: Container(
                        width: double.infinity,
                        decoration: BoxDecoration(
                          color: FlutterFlowTheme.of(context).accent1,
                          borderRadius: BorderRadius.circular(10.0),
                        ),
                        child: Column(
                          mainAxisSize: MainAxisSize.max,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Padding(
                              padding: EdgeInsets.all(15.0),
                              child: InkWell(
                                splashColor: Colors.transparent,
                                focusColor: Colors.transparent,
                                hoverColor: Colors.transparent,
                                highlightColor: Colors.transparent,
                                onTap: () async {
                                  context.pushNamed(RealtorsWidget.routeName);
                                },
                                child: Row(
                                  mainAxisSize: MainAxisSize.max,
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Row(
                                      mainAxisSize: MainAxisSize.max,
                                      children: [
                                        Padding(
                                          padding:
                                              EdgeInsetsDirectional.fromSTEB(
                                                  0.0, 0.0, 15.0, 0.0),
                                          child: Container(
                                            width: 60.0,
                                            height: 60.0,
                                            decoration: BoxDecoration(
                                              color:
                                                  FlutterFlowTheme.of(context)
                                                      .accent1,
                                              image: DecorationImage(
                                                fit: BoxFit.cover,
                                                image: Image.asset(
                                                  'assets/images/clipboard-image-1731689725.png',
                                                ).image,
                                              ),
                                              shape: BoxShape.circle,
                                            ),
                                          ),
                                        ),
                                        Column(
                                          mainAxisSize: MainAxisSize.max,
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            Text(
                                              '',
                                              style:
                                                  FlutterFlowTheme.of(context)
                                                      .titleMedium
                                                      .override(
                                                        font: GoogleFonts.cairo(
                                                          fontWeight:
                                                              FlutterFlowTheme.of(
                                                                      context)
                                                                  .titleMedium
                                                                  .fontWeight,
                                                          fontStyle:
                                                              FlutterFlowTheme.of(
                                                                      context)
                                                                  .titleMedium
                                                                  .fontStyle,
                                                        ),
                                                        letterSpacing: 0.0,
                                                        fontWeight:
                                                            FlutterFlowTheme.of(
                                                                    context)
                                                                .titleMedium
                                                                .fontWeight,
                                                        fontStyle:
                                                            FlutterFlowTheme.of(
                                                                    context)
                                                                .titleMedium
                                                                .fontStyle,
                                                      ),
                                            ),
                                            Padding(
                                              padding: EdgeInsetsDirectional
                                                  .fromSTEB(0.0, 7.0, 0.0, 0.0),
                                              child: Container(
                                                decoration: BoxDecoration(
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          4.0),
                                                  border: Border.all(
                                                    color: FlutterFlowTheme.of(
                                                            context)
                                                        .primaryText,
                                                    width: 1.0,
                                                  ),
                                                ),
                                                child: Align(
                                                  alignment:
                                                      AlignmentDirectional(
                                                          0.0, 0.0),
                                                  child: Padding(
                                                    padding:
                                                        EdgeInsetsDirectional
                                                            .fromSTEB(6.0, 3.0,
                                                                6.0, 3.0),
                                                    child: Text(
                                                      'وسيط معتمد',
                                                      style: FlutterFlowTheme
                                                              .of(context)
                                                          .labelSmall
                                                          .override(
                                                            font: GoogleFonts
                                                                .cairo(
                                                              fontWeight:
                                                                  FontWeight
                                                                      .w500,
                                                              fontStyle:
                                                                  FlutterFlowTheme.of(
                                                                          context)
                                                                      .labelSmall
                                                                      .fontStyle,
                                                            ),
                                                            color: FlutterFlowTheme
                                                                    .of(context)
                                                                .primaryText,
                                                            fontSize: 9.0,
                                                            letterSpacing: 0.0,
                                                            fontWeight:
                                                                FontWeight.w500,
                                                            fontStyle:
                                                                FlutterFlowTheme.of(
                                                                        context)
                                                                    .labelSmall
                                                                    .fontStyle,
                                                          ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ],
                                    ),
                                    Icon(
                                      FFIcons.kchevronRight,
                                      color: FlutterFlowTheme.of(context).icon,
                                      size: 24.0,
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            Container(
                              width: double.infinity,
                              height: 1.0,
                              decoration: BoxDecoration(
                                color: FlutterFlowTheme.of(context).border,
                              ),
                            ),
                            Padding(
                              padding: EdgeInsetsDirectional.fromSTEB(
                                  15.0, 15.0, 15.0, 15.0),
                              child: Column(
                                mainAxisSize: MainAxisSize.max,
                                children: [
                                  Text(
                                    'وسيط عقاري معتمد لمساعدتك في إيجار أو شراء عقارك المناسب.',
                                    style: FlutterFlowTheme.of(context)
                                        .labelLarge
                                        .override(
                                          font: GoogleFonts.cairo(
                                            fontWeight:
                                                FlutterFlowTheme.of(context)
                                                    .labelLarge
                                                    .fontWeight,
                                            fontStyle:
                                                FlutterFlowTheme.of(context)
                                                    .labelLarge
                                                    .fontStyle,
                                          ),
                                          letterSpacing: 0.0,
                                          fontWeight:
                                              FlutterFlowTheme.of(context)
                                                  .labelLarge
                                                  .fontWeight,
                                          fontStyle:
                                              FlutterFlowTheme.of(context)
                                                  .labelLarge
                                                  .fontStyle,
                                        ),
                                  ),
                                ],
                              ),
                            ),
                            Padding(
                              padding: EdgeInsetsDirectional.fromSTEB(
                                  15.0, 0.0, 15.0, 15.0),
                              child: InkWell(
                                splashColor: Colors.transparent,
                                focusColor: Colors.transparent,
                                hoverColor: Colors.transparent,
                                highlightColor: Colors.transparent,
                                onTap: () async {
                                  context.pushNamed(RealtorsWidget.routeName);
                                },
                                child: Container(
                                  width: double.infinity,
                                  height: 48.0,
                                  decoration: BoxDecoration(
                                    color: FlutterFlowTheme.of(context)
                                        .secondaryBackground,
                                    borderRadius: BorderRadius.circular(10.0),
                                  ),
                                  child: Align(
                                    alignment: AlignmentDirectional(0.0, 0.0),
                                    child: Text(
                                      'المزيد عن الوسيط',
                                      style: FlutterFlowTheme.of(context)
                                          .titleSmall
                                          .override(
                                            font: GoogleFonts.cairo(
                                              fontWeight: FontWeight.w500,
                                              fontStyle:
                                                  FlutterFlowTheme.of(context)
                                                      .titleSmall
                                                      .fontStyle,
                                            ),
                                            letterSpacing: 0.0,
                                            fontWeight: FontWeight.w500,
                                            fontStyle:
                                                FlutterFlowTheme.of(context)
                                                    .titleSmall
                                                    .fontStyle,
                                          ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(15.0, 16.0, 0.0, 0.0),
                      child: Text(
                        'عقارات مشابهة',
                        style:
                            FlutterFlowTheme.of(context).headlineSmall.override(
                                  font: GoogleFonts.cairo(
                                    fontWeight: FlutterFlowTheme.of(context)
                                        .headlineSmall
                                        .fontWeight,
                                    fontStyle: FlutterFlowTheme.of(context)
                                        .headlineSmall
                                        .fontStyle,
                                  ),
                                  letterSpacing: 0.0,
                                  fontWeight: FlutterFlowTheme.of(context)
                                      .headlineSmall
                                      .fontWeight,
                                  fontStyle: FlutterFlowTheme.of(context)
                                      .headlineSmall
                                      .fontStyle,
                                ),
                      ),
                    ),
                    Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(0.0, 5.0, 0.0, 0.0),
                      child: Container(
                        width: double.infinity,
                        height: (MediaQuery.sizeOf(context).height * 0.40).clamp(240.0, 360.0),
                        decoration: BoxDecoration(
                          color:
                              FlutterFlowTheme.of(context).secondaryBackground,
                        ),
                        child: StreamBuilder<List<PropertyDataRecord>>(
                          stream: queryPropertyDataRecord(
                            limit: 5,
                          ),
                          builder: (context, snapshot) {
                            // Customize what your widget looks like when it's loading.
                            if (!snapshot.hasData) {
                              return Center(
                                child: SizedBox(
                                  width: 25.0,
                                  height: 25.0,
                                  child: CircularProgressIndicator(
                                    valueColor: AlwaysStoppedAnimation<Color>(
                                      FlutterFlowTheme.of(context).primary,
                                    ),
                                  ),
                                ),
                              );
                            }
                            List<PropertyDataRecord>
                                listViewPropertyDataRecordList = snapshot.data!.where((p) => p.isLive).toList();

                            return ListView.separated(
                              padding: EdgeInsets.fromLTRB(
                                15.0,
                                0,
                                15.0,
                                0,
                              ),
                              primary: false,
                              shrinkWrap: true,
                              scrollDirection: Axis.horizontal,
                              itemCount: listViewPropertyDataRecordList.length,
                              separatorBuilder: (_, __) =>
                                  SizedBox(width: 15.0),
                              itemBuilder: (context, listViewIndex) {
                                final listViewPropertyDataRecord =
                                    listViewPropertyDataRecordList[
                                        listViewIndex];
                                return Container(
                                  width: 300.0,
                                  child: Padding(
                                    padding: EdgeInsetsDirectional.fromSTEB(
                                        0.0, 15.0, 0.0, 15.0),
                                    child: wrapWithModel(
                                      model:
                                          _model.propertyCard2Models.getModel(
                                        listViewIndex.toString(),
                                        listViewIndex,
                                      ),
                                      updateCallback: () => safeSetState(() {}),
                                      child: PropertyCard2Widget(
                                        key: Key(
                                          'Keyb09_${listViewIndex.toString()}',
                                        ),
                                        data: listViewPropertyDataRecord,
                                        index: listViewIndex,
                                      ),
                                    ),
                                  ),
                                );
                              },
                            );
                          },
                        ),
                      ),
                    ),
                  ].addToEnd(SizedBox(height: 10.0)),
                ),
              ),
            ),
            Container(
              width: double.infinity,
              decoration: BoxDecoration(
                color: FlutterFlowTheme.of(context).secondaryBackground,
                boxShadow: [
                  BoxShadow(
                    blurRadius: 20.0,
                    color: Color(0x11000000),
                    offset: Offset(
                      0.0,
                      0.0,
                    ),
                  )
                ],
              ),
              child: Column(
                mainAxisSize: MainAxisSize.max,
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  if (FFAppState().SingleApartmentTab == true)
                    Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(15.0, 15.0, 15.0, 5.0),
                      child: Row(
                        mainAxisSize: MainAxisSize.max,
                        children: [
                          Container(
                            width: 50.0,
                            height: 50.0,
                            decoration: BoxDecoration(
                              color: FlutterFlowTheme.of(context).accent1,
                              image: DecorationImage(
                                fit: BoxFit.cover,
                                image: Image.asset(
                                  'assets/images/clipboard-image-1731689725.png',
                                ).image,
                              ),
                              shape: BoxShape.circle,
                            ),
                          ),
                          Padding(
                            padding: EdgeInsetsDirectional.fromSTEB(
                                15.0, 0.0, 0.0, 0.0),
                            child: Column(
                              mainAxisSize: MainAxisSize.max,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  '',
                                  style: FlutterFlowTheme.of(context)
                                      .titleSmall
                                      .override(
                                        font: GoogleFonts.cairo(
                                          fontWeight: FontWeight.w500,
                                          fontStyle:
                                              FlutterFlowTheme.of(context)
                                                  .titleSmall
                                                  .fontStyle,
                                        ),
                                        letterSpacing: 0.0,
                                        fontWeight: FontWeight.w500,
                                        fontStyle: FlutterFlowTheme.of(context)
                                            .titleSmall
                                            .fontStyle,
                                      ),
                                ),
                                Padding(
                                  padding: EdgeInsetsDirectional.fromSTEB(
                                      0.0, 5.0, 0.0, 0.0),
                                  child: Container(
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(4.0),
                                      border: Border.all(
                                        color: FlutterFlowTheme.of(context)
                                            .primaryText,
                                        width: 1.0,
                                      ),
                                    ),
                                    child: Align(
                                      alignment: AlignmentDirectional(0.0, 0.0),
                                      child: Padding(
                                        padding: EdgeInsetsDirectional.fromSTEB(
                                            6.0, 3.0, 6.0, 3.0),
                                        child: Text(
                                          'وسيط معتمد',
                                          style: FlutterFlowTheme.of(context)
                                              .labelSmall
                                              .override(
                                                font: GoogleFonts.cairo(
                                                  fontWeight: FontWeight.w500,
                                                  fontStyle:
                                                      FlutterFlowTheme.of(
                                                              context)
                                                          .labelSmall
                                                          .fontStyle,
                                                ),
                                                color:
                                                    FlutterFlowTheme.of(context)
                                                        .primaryText,
                                                fontSize: 9.0,
                                                letterSpacing: 0.0,
                                                fontWeight: FontWeight.w500,
                                                fontStyle:
                                                    FlutterFlowTheme.of(context)
                                                        .labelSmall
                                                        .fontStyle,
                                              ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  // تاريخ نشر الإعلان
                  Builder(
                    builder: (context) {
                      final pub = widget.data?.publishDate;
                      if (pub == null) return SizedBox.shrink();
                      return Padding(
                        padding: EdgeInsetsDirectional.fromSTEB(
                            15.0, 8.0, 15.0, 0.0),
                        child: Row(
                          children: [
                            Icon(
                              Icons.schedule_rounded,
                              size: 15.0,
                              color:
                                  FlutterFlowTheme.of(context).secondaryText,
                            ),
                            SizedBox(width: 6.0),
                            Text(
                              'نُشر ${dateTimeFormat('relative', pub, locale: FFLocalizations.of(context).languageCode)}',
                              style: FlutterFlowTheme.of(context)
                                  .bodySmall
                                  .override(
                                    font: GoogleFonts.cairo(),
                                    color: FlutterFlowTheme.of(context)
                                        .secondaryText,
                                    letterSpacing: 0.0,
                                  ),
                            ),
                          ],
                        ),
                      );
                    },
                  ),
                  Padding(
                    padding:
                        EdgeInsetsDirectional.fromSTEB(15.0, 0.0, 15.0, 0.0),
                    child: FutureBuilder<String>(
                      // رقم التواصل: من الإعلان أولاً، وللإعلانات القديمة
                      // نرجع لرقم المالك في ملفه الشخصي.
                      future: _resolveContactPhone(),
                      builder: (context, snap) {
                        final phone = (snap.data ?? '').trim();
                        if (snap.connectionState != ConnectionState.done) {
                          return SizedBox.shrink();
                        }
                        if (phone.isEmpty) {
                          return Container(
                            width: double.infinity,
                            padding: EdgeInsets.symmetric(
                                horizontal: 14.0, vertical: 12.0),
                            decoration: BoxDecoration(
                              color: FlutterFlowTheme.of(context).accent1,
                              borderRadius: BorderRadius.circular(12.0),
                            ),
                            child: Row(
                              children: [
                                Icon(
                                  Icons.phone_disabled_outlined,
                                  size: 18.0,
                                  color: FlutterFlowTheme.of(context)
                                      .secondaryText,
                                ),
                                SizedBox(width: 8.0),
                                Expanded(
                                  child: Text(
                                    'رقم التواصل غير متوفر لهذا الإعلان',
                                    style: FlutterFlowTheme.of(context)
                                        .bodySmall
                                        .override(
                                          font: GoogleFonts.cairo(),
                                          color: FlutterFlowTheme.of(context)
                                              .secondaryText,
                                          letterSpacing: 0.0,
                                        ),
                                  ),
                                ),
                              ],
                            ),
                          );
                        }
                        return InkWell(
                          splashColor: Colors.transparent,
                          focusColor: Colors.transparent,
                          hoverColor: Colors.transparent,
                          highlightColor: Colors.transparent,
                          onTap: () async {
                            await launchURL('tel:$phone');
                          },
                          child: Container(
                            width: double.infinity,
                            padding: EdgeInsets.symmetric(
                                horizontal: 14.0, vertical: 12.0),
                            decoration: BoxDecoration(
                              color: FlutterFlowTheme.of(context)
                                  .secondaryBackground,
                              borderRadius: BorderRadius.circular(12.0),
                              border: Border.all(
                                color: FlutterFlowTheme.of(context).secondary,
                                width: 1.0,
                              ),
                            ),
                            child: Row(
                              children: [
                                Icon(
                                  Icons.phone_in_talk_rounded,
                                  size: 20.0,
                                  color: FlutterFlowTheme.of(context).secondary,
                                ),
                                SizedBox(width: 10.0),
                                Expanded(
                                  child: Text(
                                    phone,
                                    textDirection: ui_dir.TextDirection.ltr,
                                    textAlign: TextAlign.start,
                                    style: FlutterFlowTheme.of(context)
                                        .titleSmall
                                        .override(
                                          font: GoogleFonts.cairo(
                                              fontWeight: FontWeight.w600),
                                          letterSpacing: 0.0,
                                        ),
                                  ),
                                ),
                                Text(
                                  'اتصال',
                                  style: FlutterFlowTheme.of(context)
                                      .bodyMedium
                                      .override(
                                        font: GoogleFonts.cairo(
                                            fontWeight: FontWeight.w600),
                                        color: FlutterFlowTheme.of(context)
                                            .secondary,
                                        letterSpacing: 0.0,
                                      ),
                                ),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                  Padding(
                    padding:
                        EdgeInsetsDirectional.fromSTEB(15.0, 10.0, 15.0, 0.0),
                    child: FutureBuilder<String>(
                      future: _resolveWhatsapp(),
                      builder: (context, snap) {
                        if (snap.connectionState != ConnectionState.done) {
                          return SizedBox.shrink();
                        }
                        final wa = (snap.data ?? '').trim();
                        if (wa.isEmpty) {
                          return SizedBox.shrink();
                        }
                        return InkWell(
                          splashColor: Colors.transparent,
                          focusColor: Colors.transparent,
                          hoverColor: Colors.transparent,
                          highlightColor: Colors.transparent,
                          onTap: () async {
                            await _openWhatsapp(wa);
                          },
                          child: Container(
                            width: double.infinity,
                            padding: EdgeInsets.symmetric(
                                horizontal: 14.0, vertical: 12.0),
                            decoration: BoxDecoration(
                              color: Color(0xFF25D366),
                              borderRadius: BorderRadius.circular(12.0),
                            ),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(
                                  Icons.chat_rounded,
                                  size: 20.0,
                                  color: Colors.white,
                                ),
                                SizedBox(width: 8.0),
                                Text(
                                  'تواصل عبر واتساب',
                                  style: FlutterFlowTheme.of(context)
                                      .titleSmall
                                      .override(
                                        font: GoogleFonts.cairo(
                                            fontWeight: FontWeight.w600),
                                        color: Colors.white,
                                        fontSize: 15.0,
                                        letterSpacing: 0.0,
                                      ),
                                ),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                  Padding(
                    padding:
                        EdgeInsetsDirectional.fromSTEB(15.0, 15.0, 15.0, 15.0),
                    child: Row(
                      mainAxisSize: MainAxisSize.max,
                      children: [
                        Expanded(
                          child: FFButtonWidget(
                            onPressed: () async {
                              final ownerRef = widget.data?.ownerRef;
                              if (ownerRef == null ||
                                  ownerRef == currentUserReference) {
                                ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(
                                    content: Text(
                                        'لا يمكن طلب معاينة لهذا الإعلان'),
                                    backgroundColor:
                                        FlutterFlowTheme.of(context).error,
                                  ),
                                );
                                return;
                              }
                              final chatRef = await getOrCreateChat(ownerRef,
                                  propertyRef: widget.data?.reference);
                              final tourMsg =
                                  'مرحباً، أرغب بحجز موعد لمعاينة العقار: ${widget.data?.title}';
                              await sendChatMessage(
                                  chatRef: chatRef,
                                  text: tourMsg,
                                );
                              final owner =
                                  await UsersRecord.getDocumentOnce(ownerRef);
                              if (!context.mounted) {
                                return;
                              }
                              context.pushNamed(
                                SingleMessageWidget.routeName,
                                queryParameters: {
                                  'data': serializeParam(
                                    UsersStruct(
                                      name: owner.displayName,
                                      image: owner.photoUrl,
                                      message: '',
                                    ),
                                    ParamType.DataStruct,
                                  ),
                                  'chatRef': serializeParam(
                                    chatRef,
                                    ParamType.DocumentReference,
                                  ),
                                }.withoutNulls,
                              );
                            },
                            text: 'طلب معاينة',
                            options: FFButtonOptions(
                              height: 48.0,
                              padding: EdgeInsetsDirectional.fromSTEB(
                                  16.0, 0.0, 16.0, 0.0),
                              iconPadding: EdgeInsetsDirectional.fromSTEB(
                                  0.0, 0.0, 0.0, 0.0),
                              color: FlutterFlowTheme.of(context).primary,
                              textStyle: FlutterFlowTheme.of(context)
                                  .titleSmall
                                  .override(
                                    font: GoogleFonts.cairo(
                                      fontWeight: FontWeight.w500,
                                      fontStyle: FlutterFlowTheme.of(context)
                                          .titleSmall
                                          .fontStyle,
                                    ),
                                    color: Colors.white,
                                    letterSpacing: 0.0,
                                    fontWeight: FontWeight.w500,
                                    fontStyle: FlutterFlowTheme.of(context)
                                        .titleSmall
                                        .fontStyle,
                                  ),
                              elevation: 0.0,
                              borderRadius: BorderRadius.circular(10.0),
                            ),
                          ),
                        ),
                        Expanded(
                          child: FFButtonWidget(
                            onPressed: () async {
                              final ownerRef = widget.data?.ownerRef;
                              if (ownerRef == null ||
                                  ownerRef == currentUserReference) {
                                ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(
                                    content: Text(
                                        'لا يمكن مراسلة هذا الإعلان'),
                                    backgroundColor:
                                        FlutterFlowTheme.of(context).error,
                                  ),
                                );
                                return;
                              }
                              final chatRef = await getOrCreateChat(ownerRef,
                                  propertyRef: widget.data?.reference);
                              final owner =
                                  await UsersRecord.getDocumentOnce(ownerRef);
                              if (!context.mounted) {
                                return;
                              }
                              context.pushNamed(
                                SingleMessageWidget.routeName,
                                queryParameters: {
                                  'data': serializeParam(
                                    UsersStruct(
                                      name: owner.displayName,
                                      image: owner.photoUrl,
                                      message: '',
                                    ),
                                    ParamType.DataStruct,
                                  ),
                                  'chatRef': serializeParam(
                                    chatRef,
                                    ParamType.DocumentReference,
                                  ),
                                }.withoutNulls,
                              );
                            },
                            text: 'مراسلة المالك',
                            options: FFButtonOptions(
                              height: 48.0,
                              padding: EdgeInsetsDirectional.fromSTEB(
                                  16.0, 0.0, 16.0, 0.0),
                              iconPadding: EdgeInsetsDirectional.fromSTEB(
                                  0.0, 0.0, 0.0, 0.0),
                              color: FlutterFlowTheme.of(context).accent2,
                              textStyle: FlutterFlowTheme.of(context)
                                  .titleSmall
                                  .override(
                                    font: GoogleFonts.cairo(
                                      fontWeight: FontWeight.w500,
                                      fontStyle: FlutterFlowTheme.of(context)
                                          .titleSmall
                                          .fontStyle,
                                    ),
                                    color: FlutterFlowTheme.of(context)
                                        .primaryText,
                                    letterSpacing: 0.0,
                                    fontWeight: FontWeight.w500,
                                    fontStyle: FlutterFlowTheme.of(context)
                                        .titleSmall
                                        .fontStyle,
                                  ),
                              elevation: 0.0,
                              borderRadius: BorderRadius.circular(10.0),
                            ),
                          ),
                        ),
                        InkWell(
                          splashColor: Colors.transparent,
                          focusColor: Colors.transparent,
                          hoverColor: Colors.transparent,
                          highlightColor: Colors.transparent,
                          onTap: () async {
                            if (FFAppState().SingleApartmentTab) {
                              FFAppState().SingleApartmentTab = false;
                              safeSetState(() {});
                            } else {
                              FFAppState().SingleApartmentTab = true;
                              safeSetState(() {});
                            }
                          },
                          child: Row(
                            mainAxisSize: MainAxisSize.max,
                            children: [
                              if (FFAppState().SingleApartmentTab == false)
                                Icon(
                                  FFIcons.kchevronUp,
                                  color: FlutterFlowTheme.of(context).icon,
                                  size: 28.0,
                                ),
                              if (FFAppState().SingleApartmentTab == true)
                                Icon(
                                  FFIcons.kchevronDown,
                                  color: FlutterFlowTheme.of(context).icon,
                                  size: 28.0,
                                ),
                            ],
                          ),
                        ),
                      ].divide(SizedBox(width: 15.0)),
                    ),
                  ),
                ],
              ),
            ).animateOnPageLoad(animationsMap['containerOnPageLoadAnimation']!),
          ],
        ),
       ),
      ),
    );
  }
}
