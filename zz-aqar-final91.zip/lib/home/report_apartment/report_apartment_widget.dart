import '/auth/firebase_auth/auth_util.dart';
import '/backend/admin_backend.dart';
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'report_apartment_model.dart';
export 'report_apartment_model.dart';

/// الإبلاغ عن إعلان — يحفظ البلاغ فعلاً في reports (كان الزر يُغلق
/// الصفحة فقط ولا يحفظ شيئاً).
class ReportApartmentWidget extends StatefulWidget {
  const ReportApartmentWidget({super.key, this.property});

  /// الإعلان المُبلَّغ عنه — إلزامي عملياً؛ بدونه لا يُحفظ البلاغ
  final PropertyDataRecord? property;

  static String routeName = 'ReportApartment';
  static String routePath = '/reportApartment';

  @override
  State<ReportApartmentWidget> createState() => _ReportApartmentWidgetState();
}

class _ReportApartmentWidgetState extends State<ReportApartmentWidget> {
  late ReportApartmentModel _model;
  String? _reason;
  final _details = TextEditingController();
  bool _sending = false;

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => ReportApartmentModel());
  }

  @override
  void dispose() {
    _model.dispose();
    _details.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    final theme = FlutterFlowTheme.of(context);
    if (widget.property == null) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('لم يُحدَّد الإعلان — أعد فتح الصفحة من الإعلان'),
        backgroundColor: theme.error,
      ));
      return;
    }
    if (_reason == null) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('اختر سبب البلاغ'),
        backgroundColor: theme.error,
      ));
      return;
    }
    if (_reason == 'أخرى' && _details.text.trim().length < 5) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('اكتب سبب البلاغ (5 أحرف على الأقل)'),
        backgroundColor: theme.error,
      ));
      return;
    }
    safeSetState(() => _sending = true);
    try {
      await submitReport(
        property: widget.property!,
        reason: _reason!,
        details: _details.text,
      );
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('تم إرسال البلاغ — شكراً لك')));
      context.safePop();
    } catch (e) {
      debugPrint('submitReport: $e');
      if (!mounted) return;
      safeSetState(() => _sending = false);
      final t = e.toString();
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text(t.contains('permission')
            ? 'لا يمكنك الإبلاغ حالياً (permission-denied)'
            : 'تعذّر الإرسال — تحقق من الاتصال'),
        backgroundColor: theme.error,
      ));
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = FlutterFlowTheme.of(context);
    return GestureDetector(
      onTap: () => FocusScope.of(context).unfocus(),
      child: Scaffold(
        backgroundColor: theme.primaryBackground,
        appBar: AppBar(
          backgroundColor: theme.primaryBackground,
          automaticallyImplyLeading: false,
          leading: FlutterFlowIconButton(
            borderRadius: 50.0,
            buttonSize: 42.0,
            icon: Icon(Icons.arrow_forward_rounded,
                color: theme.primaryText, size: 24.0),
            onPressed: () => context.safePop(),
          ),
          title: Text('الإبلاغ عن الإعلان',
              style: theme.headlineSmall.override(
                  font: GoogleFonts.cairo(fontWeight: FontWeight.w600),
                  letterSpacing: 0.0)),
          centerTitle: true,
          elevation: 0.0,
        ),
        body: SafeArea(
          child: SingleChildScrollView(
            padding: EdgeInsets.all(15.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                if (widget.property != null)
                  Container(
                    width: double.infinity,
                    padding: EdgeInsets.all(12.0),
                    margin: EdgeInsets.only(bottom: 16.0),
                    decoration: BoxDecoration(
                      color: theme.secondaryBackground,
                      borderRadius: BorderRadius.circular(12.0),
                    ),
                    child: Text(widget.property!.title,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: theme.bodyMedium.override(
                            font: GoogleFonts.cairo(fontWeight: FontWeight.w600),
                            letterSpacing: 0.0)),
                  ),
                Text('ما سبب البلاغ؟',
                    style: theme.titleMedium.override(
                        font: GoogleFonts.cairo(fontWeight: FontWeight.w700),
                        letterSpacing: 0.0)),
                SizedBox(height: 8.0),
                ...kReportReasons.map((r) => RadioListTile<String>(
                      value: r,
                      groupValue: _reason,
                      activeColor: theme.primary,
                      contentPadding: EdgeInsets.zero,
                      title: Text(r,
                          style: theme.bodyMedium.override(
                              font: GoogleFonts.cairo(), letterSpacing: 0.0)),
                      onChanged: (v) => safeSetState(() => _reason = v),
                    )),
                // حقل «أخرى» يظهر فقط عند اختيارها (قرار العميل)،
                // ويبقى اختيارياً للأسباب الأخرى كتفاصيل إضافية
                if (_reason == 'أخرى' || _reason != null) ...[
                  SizedBox(height: 12.0),
                  Text(
                    _reason == 'أخرى' ? 'اكتب السبب' : 'تفاصيل إضافية (اختياري)',
                    style: theme.bodySmall.override(
                        font: GoogleFonts.cairo(),
                        color: theme.secondaryText,
                        letterSpacing: 0.0),
                  ),
                  SizedBox(height: 6.0),
                  TextFormField(
                    controller: _details,
                    maxLines: 4,
                    maxLength: 500,
                    style: theme.bodyMedium.override(
                        font: GoogleFonts.cairo(), letterSpacing: 0.0),
                    decoration: InputDecoration(
                      hintText: _reason == 'أخرى'
                          ? 'ما المشكلة في هذا الإعلان؟'
                          : 'أي تفاصيل تساعد الإدارة',
                      filled: true,
                      fillColor: theme.secondaryBackground,
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12.0),
                          borderSide: BorderSide.none),
                    ),
                  ),
                ],
                SizedBox(height: 24.0),
                FFButtonWidget(
                  onPressed: _sending ? null : _submit,
                  text: _sending ? 'جارٍ الإرسال…' : 'إرسال البلاغ',
                  options: FFButtonOptions(
                    width: double.infinity,
                    height: 52.0,
                    color: theme.primary,
                    textStyle: theme.titleSmall.override(
                        font: GoogleFonts.cairo(fontWeight: FontWeight.w600),
                        color: Colors.white,
                        letterSpacing: 0.0),
                    elevation: 0.0,
                    borderRadius: BorderRadius.circular(12.0),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
