import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/foundation.dart' show debugPrint;

import '/auth/firebase_auth/auth_util.dart';
import 'backend.dart';

/// ══════════════════════════════════════════════════════════════
/// الدوال الإدارية — كل عملية هنا تكتب مباشرة في Firestore،
/// و**القواعد** هي التي تفرض الصلاحية (isAdmin على الخادم).
/// الواجهة تُخفي اللوحة عن غير الأدمن، لكن لو استُدعيت هذه الدوال
/// من حساب عادي فسيُرفض الطلب بـ permission-denied — لا بديل عن ذلك.
/// ══════════════════════════════════════════════════════════════

/* ── الإحصائيات: count() تجميعي — لا يقرأ الوثائق ──────────── */

class AdminCounts {
  final int users, banned, listings, live, expired, disabled,
      requests, newReports, realtors, contactRequests;
  const AdminCounts({
    required this.users, required this.banned, required this.listings,
    required this.live, required this.expired, required this.disabled,
    required this.requests, required this.newReports,
    required this.realtors, required this.contactRequests,
  });
}

Future<int> _count(Query q) async {
  try {
    return (await q.count().get()).count ?? 0;
  } catch (e) {
    debugPrint('count: $e');
    return -1; // -1 = تعذّر (فهرس ناقص أو صلاحية)
  }
}

Future<AdminCounts> adminCounts() async {
  final now = Timestamp.now();
  final r = await Future.wait([
    _count(UsersRecord.collection),
    _count(UsersRecord.collection.where('is_banned', isEqualTo: true)),
    _count(PropertyDataRecord.collection),
    _count(PropertyDataRecord.collection.where('is_live', isEqualTo: true)),
    _count(PropertyDataRecord.collection
        .where('is_live', isEqualTo: false)
        .where('expires_at', isLessThanOrEqualTo: now)),
    _count(PropertyDataRecord.collection
        .where('disabled_by_admin', isEqualTo: true)),
    _count(PropertyRequestsRecord.collection),
    _count(ReportsRecord.collection.where('status', isEqualTo: 'new')),
    _count(RealtorsRecord.collection),
    _count(ContactRequestsRecord.collection),
  ]);
  return AdminCounts(
    users: r[0], banned: r[1], listings: r[2], live: r[3], expired: r[4],
    disabled: r[5], requests: r[6], newReports: r[7], realtors: r[8],
    contactRequests: r[9],
  );
}

/* ── الإعلانات ─────────────────────────────────────────────── */

/// تعطيل إعلان مع سبب — يختفي من كل الاستعلامات (isApproved=false)
/// ويصل صاحبه إشعار listing_disabled (Cloud Function).
Future<void> adminDisableListing(DocumentReference ref, String reason) =>
    ref.update({
      'isApproved': false,
      'disabled_by_admin': true,
      'disabled_reason': reason.trim(),
      'disabled_at': FieldValue.serverTimestamp(),
    });

/// إعادة تفعيل إعلان معطَّل إدارياً
Future<void> adminEnableListing(DocumentReference ref) => ref.update({
      'isApproved': true,
      'disabled_by_admin': false,
      'disabled_reason': FieldValue.delete(),
      'disabled_at': FieldValue.delete(),
    });

/// حذف نهائي — الوثيقة فقط؛ صور Storage تُحذف على أفضل جهد
Future<void> adminDeleteListing(PropertyDataRecord p) async {
  for (final url in p.images) {
    try {
      await FirebaseStorage.instance.refFromURL(url).delete();
    } catch (_) {}
  }
  await p.reference.delete();
}

/* ── المستخدمون ────────────────────────────────────────────── */

/// حظر — القواعد تمنع المحظور من: نشر إعلان، رسالة، طلب، بلاغ.
/// إشعار account_banned يصل عبر Cloud Function.
Future<void> adminBanUser(DocumentReference userRef, String reason) =>
    userRef.set({
      'is_banned': true,
      'banned_at': FieldValue.serverTimestamp(),
      'ban_reason': reason.trim(),
    }, SetOptions(merge: true));

Future<void> adminUnbanUser(DocumentReference userRef) => userRef.set({
      'is_banned': false,
      'banned_at': FieldValue.delete(),
      'ban_reason': FieldValue.delete(),
    }, SetOptions(merge: true));

/// إعلانات مستخدم معيّن (كلها، حيّة أو لا)
Query userListingsQuery(DocumentReference userRef) =>
    PropertyDataRecord.collection
        .where('ownerRef', isEqualTo: userRef)
        .orderBy('created_at', descending: true);

/* ── البلاغات ──────────────────────────────────────────────── */

/// يكتبه المستخدم من صفحة الإبلاغ — status يبدأ new (القاعدة تشترطه)
Future<void> submitReport({
  required PropertyDataRecord property,
  required String reason,
  String details = '',
}) async {
  final me = currentUserReference;
  if (me == null) return;
  await ReportsRecord.collection.doc().set({
    'property_ref': property.reference,
    'property_title': property.title,
    'reporter_ref': me,
    'owner_ref': property.ownerRef,
    'reason': reason,
    'details': details.trim(),
    'status': 'new',
    'admin_note': '',
    'created_at': FieldValue.serverTimestamp(),
  });
}

/// تغيير حالة البلاغ — الأدمن فقط (القاعدة تحصر الحقول)
Future<void> adminSetReportStatus(
  DocumentReference ref,
  String status, {
  String? note,
}) =>
    ref.update({
      'status': status,
      if (note != null) 'admin_note': note.trim(),
      'reviewed_at': FieldValue.serverTimestamp(),
    });

Query reportsQuery({String? status}) {
  Query q = ReportsRecord.collection;
  if (status != null && status.isNotEmpty) {
    q = q.where('status', isEqualTo: status);
  }
  return q.orderBy('created_at', descending: true).limit(200);
}

/* ── استعلامات اللوحة ──────────────────────────────────────── */

Query adminListingsQuery({
  String? category,
  String? area,
  String? state, // live | expired | disabled | all
}) {
  Query q = PropertyDataRecord.collection;
  if (state == 'disabled') {
    q = q.where('disabled_by_admin', isEqualTo: true);
  } else if (state == 'live') {
    q = q.where('is_live', isEqualTo: true);
  } else if (state == 'expired') {
    q = q.where('is_live', isEqualTo: false)
        .where('expires_at', isLessThanOrEqualTo: Timestamp.now());
  }
  if (category != null && category.isNotEmpty) {
    q = q.where('category', isEqualTo: category);
  }
  if (area != null && area.isNotEmpty) {
    q = q.where('area', isEqualTo: area);
  }
  return q.orderBy(state == 'expired' ? 'expires_at' : 'created_at',
          descending: true)
      .limit(200);
}

/// بحث بادئة على الاسم أو البريد — Firestore لا يدعم «يحتوي»
Query adminUsersQuery({String? prefix, bool? banned}) {
  Query q = UsersRecord.collection;
  if (banned != null) q = q.where('is_banned', isEqualTo: banned);
  final p = (prefix ?? '').trim();
  if (p.isNotEmpty) {
    final field = p.contains('@') ? 'email' : 'display_name';
    q = q.orderBy(field).startAt([p]).endAt(['$p\uf8ff']);
  } else {
    q = q.orderBy('created_time', descending: true);
  }
  return q.limit(200);
}

Query adminRequestsQuery({String? type, String? area}) {
  Query q = PropertyRequestsRecord.collection;
  if (type != null && type.isNotEmpty) {
    q = q.where('request_type', isEqualTo: type);
  }
  if (area != null && area.isNotEmpty) q = q.where('area', isEqualTo: area);
  return q.orderBy('created_at', descending: true).limit(200);
}
