import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

/// بلاغ على إعلان — يُنشئه المستخدم، ويُدير حالته الأدمن.
/// status: new | reviewed | resolved
class ReportsRecord extends FirestoreRecord {
  ReportsRecord._(DocumentReference reference, Map<String, dynamic> data)
      : super(reference, data) {
    _initializeFields();
  }

  DocumentReference? _propertyRef;
  DocumentReference? get propertyRef => _propertyRef;

  DocumentReference? _reporterRef;
  DocumentReference? get reporterRef => _reporterRef;

  DocumentReference? _ownerRef;
  DocumentReference? get ownerRef => _ownerRef;

  String? _reason;
  String get reason => _reason ?? '';

  String? _details;
  String get details => _details ?? '';

  String? _status;
  String get status => _status ?? 'new';

  String? _adminNote;
  String get adminNote => _adminNote ?? '';

  DateTime? _createdAt;
  DateTime? get createdAt => _createdAt;

  DateTime? _reviewedAt;
  DateTime? get reviewedAt => _reviewedAt;

  /// عنوان الإعلان وقت الإبلاغ — يُنسخ حتى يبقى لو حُذف الإعلان
  String? _propertyTitle;
  String get propertyTitle => _propertyTitle ?? '';

  void _initializeFields() {
    _propertyRef = snapshotData['property_ref'] as DocumentReference?;
    _reporterRef = snapshotData['reporter_ref'] as DocumentReference?;
    _ownerRef = snapshotData['owner_ref'] as DocumentReference?;
    _reason = snapshotData['reason'] as String?;
    _details = snapshotData['details'] as String?;
    _status = snapshotData['status'] as String?;
    _adminNote = snapshotData['admin_note'] as String?;
    _createdAt = snapshotData['created_at'] as DateTime?;
    _reviewedAt = snapshotData['reviewed_at'] as DateTime?;
    _propertyTitle = snapshotData['property_title'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('reports');

  static Stream<ReportsRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => ReportsRecord.fromSnapshot(s));

  static Future<ReportsRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => ReportsRecord.fromSnapshot(s));

  static ReportsRecord fromSnapshot(DocumentSnapshot snapshot) =>
      ReportsRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  @override
  String toString() =>
      'ReportsRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is ReportsRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

/// أسباب الإبلاغ المعتمدة (قرار العميل)
const kReportReasons = <String>[
  'معلومات مضللة',
  'إعلان مكرر',
  'سعر وهمي',
  'محتوى مخالف',
  'أخرى',
];
