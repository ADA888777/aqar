import 'dart:async';

import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import '../auth_manager.dart';
import '../base_auth_user_provider.dart';
import '../../flutter_flow/flutter_flow_util.dart';

import '/backend/backend.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:stream_transform/stream_transform.dart';
import 'firebase_auth_manager.dart';

export 'firebase_auth_manager.dart';

final _authManager = FirebaseAuthManager();
FirebaseAuthManager get authManager => _authManager;

String get currentUserEmail =>
    currentUserDocument?.email ?? currentUser?.email ?? '';

String get currentUserUid => currentUser?.uid ?? '';

String get currentUserDisplayName =>
    currentUserDocument?.displayName ?? currentUser?.displayName ?? '';

String get currentUserPhoto =>
    currentUserDocument?.photoUrl ?? currentUser?.photoUrl ?? '';

String get currentPhoneNumber =>
    currentUserDocument?.phoneNumber ?? currentUser?.phoneNumber ?? '';

String get currentJwtToken => _currentJwtToken ?? '';

bool get currentUserEmailVerified => currentUser?.emailVerified ?? false;

/// Create a Stream that listens to the current user's JWT Token, since Firebase
/// generates a new token every hour.
String? _currentJwtToken;

/// الـ Custom Claims الحالية (admin: true …) — المصدر الموثوق للصلاحيات.
/// تُحدَّث عند كل تغيّر في التوكن، وبعد تسجيل الدخول نطلب تحديثاً قسرياً
/// (getIdTokenResult(true)) لأن الـ claim المُضاف من Admin SDK لا يظهر
/// في التوكن المخزّن حتى يُجدَّد.
Map<String, dynamic> currentUserClaims = const {};
bool get currentUserHasAdminClaim => currentUserClaims['admin'] == true;

/// يُجدّد التوكن قسرياً ويقرأ الـ claims — يُستدعى عند الدخول وعند فتح
/// صفحة الإعلان (حتى تظهر صلاحية أُضيفت أثناء الجلسة بلا خروج/دخول).
Future<void> refreshUserClaims() async {
  final u = FirebaseAuth.instance.currentUser;
  if (u == null) {
    currentUserClaims = const {};
    return;
  }
  try {
    final r = await u.getIdTokenResult(true);
    currentUserClaims = r.claims ?? const {};
  } catch (_) {
    // فشل التحديث (بلا شبكة مثلاً): نُبقي القيم السابقة
  }
}

final jwtTokenStream = FirebaseAuth.instance
    .idTokenChanges()
    .map((user) async {
      _currentJwtToken = await user?.getIdToken();
      // تحديث الـ claims مع كل تغيّر توكن (دخول/تجديد)
      if (user == null) {
        currentUserClaims = const {};
      } else {
        try {
          currentUserClaims = (await user.getIdTokenResult()).claims ?? const {};
        } catch (_) {}
      }
      return _currentJwtToken;
    })
    .asBroadcastStream();

DocumentReference? get currentUserReference =>
    loggedIn ? UsersRecord.collection.doc(currentUser!.uid) : null;

UsersRecord? currentUserDocument;
final authenticatedUserStream = FirebaseAuth.instance
    .authStateChanges()
    .map<String>((user) => user?.uid ?? '')
    .switchMap(
      (uid) => uid.isEmpty
          ? Stream.value(null)
          : UsersRecord.getDocument(UsersRecord.collection.doc(uid))
              .handleError((_) {}),
    )
    .map((user) {
  currentUserDocument = user;

  return currentUserDocument;
}).asBroadcastStream();

class AuthUserStreamWidget extends StatelessWidget {
  const AuthUserStreamWidget({Key? key, required this.builder})
      : super(key: key);

  final WidgetBuilder builder;

  @override
  Widget build(BuildContext context) => StreamBuilder(
        stream: authenticatedUserStream,
        builder: (context, _) => builder(context),
      );
}
