import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/index.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'property_card_model.dart';
export 'property_card_model.dart';

class PropertyCardWidget extends StatefulWidget {
  const PropertyCardWidget({
    super.key,
    this.data,
    this.index,
  });

  final PropertyDataRecord? data;
  final int? index;

  @override
  State<PropertyCardWidget> createState() => _PropertyCardWidgetState();
}

class _PropertyCardWidgetState extends State<PropertyCardWidget> {
  late PropertyCardModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => PropertyCardModel());
  }

  @override
  void dispose() {
    _model.maybeDispose();
    super.dispose();
  }

  /// الصورة الرئيسية فقط — باقي الصور تُعرض في صفحة التفاصيل
  String get _mainImage {
    final imgs = widget.data?.propertyImages ?? const <String>[];
    return imgs.isNotEmpty ? imgs.first : '';
  }

  /// التقسيم الداخلي المختصر — من سجل الإعلان حصراً
  String get _roomsSummary {
    final d = widget.data;
    if (d == null) return '';
    // الملخص يتبع تصنيف العقار — المحل التجاري لا يعرض غرفاً وصالات
    final fields =
        FFAppConstants.FieldsByCategory[d.category] ?? const <String>[];
    final parts = <String>[];
    if (fields.contains('units') && d.units > 0) {
      parts.add('${d.units} وحدات');
    }
    if (fields.contains('rooms') && d.rooms > 0) parts.add('${d.rooms} غرف');
    if (fields.contains('bathrooms') && d.bathrooms > 0) {
      parts.add('${d.bathrooms} حمامات');
    }
    if (fields.contains('halls') && d.halls > 0) parts.add('${d.halls} صالات');
    if (fields.contains('kitchens') && d.kitchens > 0) {
      parts.add('${d.kitchens} مطابخ');
    }
    if (fields.contains('floors') && d.floors > 0) {
      parts.add(FFAppConstants.floorsLabel(d.floors));
    }
    if (d.size.trim().isNotEmpty) parts.add('${d.size.trim()} م²');
    return parts.take(4).join(' | ');
  }

  /// الموقع من بيانات الإعلان
  String get _locationLine {
    final d = widget.data;
    if (d == null) return '';
    final parts = <String>[
      if (d.area.trim().isNotEmpty) d.area.trim(),
      if (d.governorate.trim().isNotEmpty) d.governorate.trim(),
    ];
    return parts.join('، ');
  }

  /// السعر بصيغة نوع الإعلان
  String get _priceLine {
    final d = widget.data;
    if (d == null || d.price <= 0) return 'السعر عند الاتصال';
    final p = d.price.toStringAsFixed(0);
    if (d.listingTypy == 'rent') return 'السعر: $p د.ك شهرياً';
    if (d.listingTypy == 'exchange') return 'للبدل — القيمة: $p د.ك';
    return 'السعر: $p د.ك';
  }

  @override
  Widget build(BuildContext context) {
    context.watch<FFAppState>();
    final d = widget.data;

    return InkWell(
      splashColor: Colors.transparent,
      focusColor: Colors.transparent,
      hoverColor: Colors.transparent,
      highlightColor: Colors.transparent,
      onTap: () async {
        if (d == null) {
          return;
        }
        context.pushNamed(
          SingleApartmentWidget.routeName,
          queryParameters: {
            'data': serializeParam(
              d,
              ParamType.Document,
            ),
          }.withoutNulls,
          extra: <String, dynamic>{
            'data': d,
          },
        );
      },
      child: Container(
        decoration: BoxDecoration(
          color: FlutterFlowTheme.of(context).secondaryBackground,
          borderRadius: BorderRadius.circular(14.0),
          border: Border.all(
            color: FlutterFlowTheme.of(context).alternate,
            width: 1.0,
          ),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // ===== صورة رئيسية واحدة بارتفاع متجاوب معتدل =====
            Stack(
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.vertical(
                    top: Radius.circular(14.0),
                  ),
                  child: Container(
                    width: double.infinity,
                    height: (MediaQuery.sizeOf(context).height * 0.20)
                        .clamp(140.0, 180.0),
                    color: FlutterFlowTheme.of(context).accent1,
                    child: _mainImage.isNotEmpty
                        ? CachedNetworkImage(
                            // تخزين مؤقت: لا يُعاد تحميل الصورة في كل rebuild
                            // ولا عند العودة للقائمة — تحسين أداء كبير.
                            imageUrl: _mainImage,
                            fit: BoxFit.cover,
                            width: double.infinity,
                            fadeInDuration: Duration(milliseconds: 150),
                            memCacheWidth: 800,
                            errorWidget: (_, __, ___) => Center(
                              child: Icon(
                                Icons.image_not_supported_outlined,
                                color:
                                    FlutterFlowTheme.of(context).secondaryText,
                                size: 28.0,
                              ),
                            ),
                          )
                        : Center(
                            child: Icon(
                              Icons.home_work_outlined,
                              color: FlutterFlowTheme.of(context).secondaryText,
                              size: 32.0,
                            ),
                          ),
                  ),
                ),
                // شارة نوع الإعلان — من الحقل المحفوظ
                Positioned(
                  top: 10.0,
                  right: 10.0,
                  child: Container(
                    padding:
                        EdgeInsets.symmetric(horizontal: 10.0, vertical: 5.0),
                    decoration: BoxDecoration(
                      color: FlutterFlowTheme.of(context).primary,
                      borderRadius: BorderRadius.circular(8.0),
                    ),
                    child: Text(
                      (d?.listingTypy ?? '') == 'rent'
                          ? 'للإيجار'
                          : (d?.listingTypy ?? '') == 'exchange'
                              ? 'للبدل'
                              : 'للبيع',
                      style: FlutterFlowTheme.of(context).bodySmall.override(
                            font:
                                GoogleFonts.cairo(fontWeight: FontWeight.w600),
                            color: Colors.white,
                            fontSize: 11.0,
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                // زر المفضلة
                Positioned(
                  top: 8.0,
                  left: 8.0,
                  child: Builder(
                    builder: (context) {
                      final ref = d?.reference;
                      final isFav = ref != null &&
                          FFAppState().favoritesList.contains(ref);
                      return InkWell(
                        splashColor: Colors.transparent,
                        focusColor: Colors.transparent,
                        hoverColor: Colors.transparent,
                        highlightColor: Colors.transparent,
                        onTap: () async {
                          if (ref == null) {
                            return;
                          }
                          if (currentUserReference == null) {
                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(
                                content: Text(
                                    'سجّل دخولك لحفظ العقارات في المفضلة'),
                              ),
                            );
                            return;
                          }
                          safeSetState(() => isFav
                              ? FFAppState().removeFromFavoritesList(ref)
                              : FFAppState().addToFavoritesList(ref));
                          await currentUserReference!.update({
                            'favorites': isFav
                                ? FieldValue.arrayRemove([ref])
                                : FieldValue.arrayUnion([ref]),
                          });
                        },
                        child: Container(
                          padding: EdgeInsets.all(7.0),
                          decoration: BoxDecoration(
                            color:
                                FlutterFlowTheme.of(context).secondaryBackground,
                            shape: BoxShape.circle,
                          ),
                          child: Icon(
                            isFav
                                ? Icons.favorite_rounded
                                : Icons.favorite_border_rounded,
                            color: isFav
                                ? FlutterFlowTheme.of(context).error
                                : FlutterFlowTheme.of(context).secondaryText,
                            size: 18.0,
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ],
            ),

            // ===== بيانات الإعلان =====
            Padding(
              padding: EdgeInsetsDirectional.fromSTEB(12.0, 10.0, 12.0, 12.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    d?.title ?? '',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: FlutterFlowTheme.of(context).titleSmall.override(
                          font: GoogleFonts.cairo(fontWeight: FontWeight.w600),
                          letterSpacing: 0.0,
                        ),
                  ),
                  if (_locationLine.isNotEmpty)
                    Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(0.0, 4.0, 0.0, 0.0),
                      child: Row(
                        children: [
                          Icon(
                            Icons.location_on_outlined,
                            size: 14.0,
                            color: FlutterFlowTheme.of(context).secondaryText,
                          ),
                          SizedBox(width: 4.0),
                          Expanded(
                            child: Text(
                              _locationLine,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: FlutterFlowTheme.of(context)
                                  .bodySmall
                                  .override(
                                    font: GoogleFonts.cairo(),
                                    color: FlutterFlowTheme.of(context)
                                        .secondaryText,
                                    letterSpacing: 0.0,
                                  ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  Padding(
                    padding:
                        EdgeInsetsDirectional.fromSTEB(0.0, 8.0, 0.0, 0.0),
                    child: Text(
                      _priceLine,
                      style: FlutterFlowTheme.of(context).titleSmall.override(
                            font:
                                GoogleFonts.cairo(fontWeight: FontWeight.w600),
                            color: FlutterFlowTheme.of(context).secondary,
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                  if (_roomsSummary.isNotEmpty)
                    Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(0.0, 8.0, 0.0, 0.0),
                      child: Text(
                        _roomsSummary,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: FlutterFlowTheme.of(context).bodyMedium.override(
                              font: GoogleFonts.cairo(),
                              letterSpacing: 0.0,
                            ),
                      ),
                    ),
                  if ((d?.description ?? '').trim().isNotEmpty)
                    Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(0.0, 8.0, 0.0, 0.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(
                            'الوصف',
                            style:
                                FlutterFlowTheme.of(context).bodySmall.override(
                                      font: GoogleFonts.cairo(
                                          fontWeight: FontWeight.w600),
                                      color: FlutterFlowTheme.of(context)
                                          .secondaryText,
                                      letterSpacing: 0.0,
                                    ),
                          ),
                          SizedBox(height: 2.0),
                          Text(
                            d!.description.trim(),
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                            style:
                                FlutterFlowTheme.of(context).bodySmall.override(
                                      font: GoogleFonts.cairo(),
                                      color: FlutterFlowTheme.of(context)
                                          .secondaryText,
                                      letterSpacing: 0.0,
                                    ),
                          ),
                        ],
                      ),
                    ),
                  if ((d?.features ?? const <String>[]).isNotEmpty)
                    Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(0.0, 8.0, 0.0, 0.0),
                      child: Wrap(
                        spacing: 6.0,
                        runSpacing: 6.0,
                        children: d!.features
                            .take(3)
                            .map((f) => Container(
                                  padding: EdgeInsets.symmetric(
                                      horizontal: 8.0, vertical: 4.0),
                                  decoration: BoxDecoration(
                                    color: FlutterFlowTheme.of(context).accent1,
                                    borderRadius: BorderRadius.circular(6.0),
                                  ),
                                  child: Text(
                                    f,
                                    style: FlutterFlowTheme.of(context)
                                        .bodySmall
                                        .override(
                                          font: GoogleFonts.cairo(),
                                          fontSize: 11.0,
                                          letterSpacing: 0.0,
                                        ),
                                  ),
                                ))
                            .toList(),
                      ),
                    ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
