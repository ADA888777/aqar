import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_animations.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/home/components/filte_rooms/filte_rooms_widget.dart';
import '/home/components/filter_area/filter_area_widget.dart';
import '/home/components/filter_home_type/filter_home_type_widget.dart';
import '/home/components/filter_orientation/filter_orientation_widget.dart';
import '/home/components/filter_price/filter_price_widget.dart';
import '/home/components/filter_sort_by/filter_sort_by_widget.dart';
import '/home/components/filter_views/filter_views_widget.dart';
import '/home/components/property_card/property_card_widget.dart';
import '/home/z_filter_ameneties/z_filter_ameneties_widget.dart';
import '/walkthroughs/archive.dart';
import 'dart:math';
import 'dart:ui';
import '/index.dart';
import 'package:sticky_headers/sticky_headers.dart';
import 'package:tutorial_coach_mark/tutorial_coach_mark.dart'
    show TutorialCoachMark;
import 'search_archive_widget.dart' show SearchArchiveWidget;
import 'package:aligned_dialog/aligned_dialog.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class SearchArchiveModel extends FlutterFlowModel<SearchArchiveWidget> {
  ///  State fields for stateful widgets in this page.

  TutorialCoachMark? archiveController;
  // State field(s) for TextField widget.
  FocusNode? textFieldFocusNode;
  TextEditingController? textController;
  String? Function(BuildContext, String?)? textControllerValidator;
  // Models for PropertyCard dynamic component.
  late FlutterFlowDynamicModels<PropertyCardModel> propertyCardModels;

  // ===== حالة الصفحات (Pagination حقيقية) =====
  /// الإعلانات المحمّلة حتى الآن (تُضاف دفعة بعد دفعة)
  final List<PropertyDataRecord> loadedProperties = [];

  /// آخر وثيقة في الصفحة الأخيرة — cursor لطلب الصفحة التالية
  DocumentSnapshot? lastDoc;

  bool isLoadingPage = false;
  bool hasMorePages = true;
  bool initialLoadDone = false;

  static const int pageSize = 20;

  void resetPaging() {
    loadedProperties.clear();
    lastDoc = null;
    hasMorePages = true;
    initialLoadDone = false;
  }

  // ===== حالة الفلاتر =====
  /// التصنيف المختار (يأتي من الرئيسية أو من نافذة الفلاتر)
  String? filterCategory;

  /// نوع الإعلان: '' = الكل، 'rent' = إيجار، 'sale' = بيع
  String filterListingType = '';

  String? filterGovernorate;
  String? filterArea;

  /// نطاق السعر (د.ك)
  double? minPrice;
  double? maxPrice;

  /// الحد الأدنى للغرف والحمامات (0 = بلا حد)
  int minRooms = 0;
  int minBathrooms = 0;

  /// الترتيب: 'newest' | 'price_asc' | 'price_desc'
  String sortBy = 'newest';

  /// عدد الفلاتر المفعّلة (لعرض شارة على زر الفلاتر)
  int get activeFiltersCount {
    var n = 0;
    if ((filterCategory ?? '').isNotEmpty) n++;
    if (filterListingType.isNotEmpty) n++;
    if ((filterGovernorate ?? '').isNotEmpty) n++;
    if ((filterArea ?? '').isNotEmpty) n++;
    if (minPrice != null || maxPrice != null) n++;
    if (minRooms > 0) n++;
    if (minBathrooms > 0) n++;
    if (sortBy != 'newest') n++;
    return n;
  }

  void resetFilters() {
    filterCategory = null;
    filterListingType = '';
    filterGovernorate = null;
    filterArea = null;
    minPrice = null;
    maxPrice = null;
    minRooms = 0;
    minBathrooms = 0;
    sortBy = 'newest';
  }

  @override
  void initState(BuildContext context) {
    propertyCardModels = FlutterFlowDynamicModels(() => PropertyCardModel());
  }

  @override
  void dispose() {
    archiveController?.finish();
    textFieldFocusNode?.dispose();
    textController?.dispose();

    propertyCardModels.dispose();
  }
}
