import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';

/// ترجمة مركزية لأخطاء Firebase إلى رسائل عربية مفهومة.
///
/// القاعدة: لا يُعرض `e.message` للمستخدم إطلاقاً — لأن Firebase يُرجع
/// نصوصاً إنجليزية تقنية مثل:
///   [firebase_auth/invalid-credential] Firebase: Error (auth/...)
/// بل نمرّ دائماً عبر `authErrorAr` / `firebaseErrorAr`.

/// أخطاء المصادقة (تسجيل الدخول، التسجيل، كلمة المرور، الحساب)
String authErrorAr(FirebaseAuthException e) {
  switch (e.code) {
    // بيانات الدخول
    case 'wrong-password':
    case 'invalid-credential':
    case 'invalid-login-credentials':
      return 'البريد الإلكتروني أو كلمة المرور غير صحيحة';
    case 'user-not-found':
      return 'لا يوجد حساب مسجّل بهذا البريد الإلكتروني';
    case 'invalid-email':
      return 'صيغة البريد الإلكتروني غير صحيحة';
    case 'user-disabled':
      return 'هذا الحساب معطّل، تواصل مع الدعم';

    // التسجيل
    case 'email-already-in-use':
      return 'هذا البريد الإلكتروني مستخدم في حساب آخر';
    case 'weak-password':
      return 'كلمة المرور ضعيفة، اختر كلمة مرور أقوى (6 أحرف فأكثر)';
    case 'operation-not-allowed':
      return 'طريقة التسجيل هذه غير مفعّلة حالياً';

    // الجلسة والصلاحيات
    case 'requires-recent-login':
      return 'لأمانك، سجّل خروجك ثم ادخل من جديد وأعد المحاولة';
    case 'user-token-expired':
    case 'invalid-user-token':
      return 'انتهت جلستك، سجّل دخولك من جديد';

    // الشبكة والحدود
    case 'too-many-requests':
      return 'محاولات كثيرة، انتظر قليلاً ثم حاول مرة أخرى';
    case 'network-request-failed':
      return 'تعذّر الاتصال بالإنترنت، تحقق من اتصالك وحاول مرة أخرى';

    // الهاتف
    case 'invalid-verification-code':
      return 'رمز التحقق غير صحيح';
    case 'invalid-phone-number':
      return 'رقم الهاتف غير صحيح';
    case 'session-expired':
      return 'انتهت صلاحية رمز التحقق، اطلب رمزاً جديداً';

    default:
      return 'حدث خطأ، حاول مرة أخرى';
  }
}

/// أخطاء Firestore و Storage والعمليات العامة
String firebaseErrorAr(Object error) {
  if (error is FirebaseAuthException) {
    return authErrorAr(error);
  }
  final code = error is FirebaseException ? error.code : '';
  final text = error.toString();

  switch (code) {
    case 'permission-denied':
    case 'unauthorized':
      return 'ليست لديك صلاحية لتنفيذ هذه العملية';
    case 'not-found':
    case 'object-not-found':
      return 'العنصر المطلوب غير موجود';
    case 'unavailable':
    case 'deadline-exceeded':
      return 'الخدمة غير متاحة حالياً، حاول بعد قليل';
    case 'canceled':
      return 'أُلغيت العملية';
    case 'quota-exceeded':
      return 'تم تجاوز الحد المسموح، حاول لاحقاً';
    case 'unauthenticated':
      return 'سجّل دخولك للمتابعة';
  }

  if (text.contains('network') || text.contains('SocketException')) {
    return 'تعذّر الاتصال بالإنترنت، تحقق من اتصالك وحاول مرة أخرى';
  }
  if (text.contains('storage') || text.contains('bucket')) {
    return 'تعذّر رفع الملف، حاول مرة أخرى';
  }
  return 'حدث خطأ، حاول مرة أخرى';
}

/// أخطاء رفع الصور تحديداً (تُستخدم في نشر العقار وصورة الملف الشخصي)
String uploadErrorAr(Object error) {
  final text = error.toString();
  if (text.contains('object-not-found') ||
      text.contains('bucket') ||
      text.contains('404')) {
    return 'خدمة تخزين الصور غير مفعّلة';
  }
  if (text.contains('permission-denied') || text.contains('unauthorized')) {
    return 'الصلاحيات ترفض رفع الصورة';
  }
  if (text.contains('network') || text.contains('SocketException')) {
    return 'تحقق من اتصال الإنترنت';
  }
  if (text.contains('canceled')) {
    return 'أُلغي رفع الصورة';
  }
  return 'تعذّر رفع الصورة، حاول مرة أخرى';
}
