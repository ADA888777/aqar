import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'help_center_terms_model.dart';
export 'help_center_terms_model.dart';

class HelpCenterTermsWidget extends StatefulWidget {
  const HelpCenterTermsWidget({super.key});

  static String routeName = 'HelpCenterTerms';
  static String routePath = '/helpCenterTerms';

  @override
  State<HelpCenterTermsWidget> createState() => _HelpCenterTermsWidgetState();
}

class _HelpCenterTermsWidgetState extends State<HelpCenterTermsWidget> {
  late HelpCenterTermsModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => HelpCenterTermsModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        FocusScope.of(context).unfocus();
        FocusManager.instance.primaryFocus?.unfocus();
      },
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: FlutterFlowTheme.of(context).secondaryBackground,
        appBar: AppBar(
          backgroundColor: FlutterFlowTheme.of(context).secondaryBackground,
          automaticallyImplyLeading: false,
          leading: Padding(
            padding: EdgeInsetsDirectional.fromSTEB(6.0, 6.0, 6.0, 6.0),
            child: FlutterFlowIconButton(
              borderRadius: 50.0,
              buttonSize: 42.0,
              fillColor: FlutterFlowTheme.of(context).accent4,
              icon: Icon(
                FFIcons.karrowLeft,
                color: FlutterFlowTheme.of(context).primaryText,
                size: 24.0,
              ),
              onPressed: () async {
                context.safePop();
              },
            ),
          ),
          title: Text(
            'الشروط والأحكام',
            style: FlutterFlowTheme.of(context).headlineSmall.override(
                  font: GoogleFonts.cairo(
                    fontWeight:
                        FlutterFlowTheme.of(context).headlineSmall.fontWeight,
                    fontStyle:
                        FlutterFlowTheme.of(context).headlineSmall.fontStyle,
                  ),
                  letterSpacing: 0.0,
                  fontWeight:
                      FlutterFlowTheme.of(context).headlineSmall.fontWeight,
                  fontStyle:
                      FlutterFlowTheme.of(context).headlineSmall.fontStyle,
                ),
          ),
          actions: [],
          centerTitle: true,
          elevation: 0.0,
        ),
        body: SafeArea(
          child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Padding(
                padding: EdgeInsetsDirectional.fromSTEB(16.0, 0.0, 16.0, 0.0),
                child: Text(
                  'Welcome to عقارات الكويت! By accessing or using our platform, you agree to comply with and be bound by the following Terms and Conditions. Please read them carefully before using our services.\n\n1. Definitions\n1.1. \"عقارات الكويت\" refers to our real estate platform, accessible via our website or app.\n1.2. \"User\" refers to anyone accessing or using عقارات الكويت, including buyers, sellers, renters, agents, and visitors.\n1.3. \"Services\" refers to all features, tools, and resources provided through عقارات الكويت.\n\n2. Acceptance of Terms\nBy registering, accessing, or using عقارات الكويت, you confirm that you are at least 18 years old and have read, understood, and agreed to these Terms and Conditions.\n\n3. Use of the Platform\n3.1. Users agree to use the platform only for lawful purposes related to real estate activities, such as searching for properties, listing properties, or contacting agents.\n3.2. You must not:\n\nPost false or misleading property listings.\nUse the platform for fraudulent or illegal activities.\nInterfere with the functionality of the platform.\n4. User Accounts\n4.1. You are responsible for maintaining the confidentiality of your account credentials and for all activities conducted under your account.\n4.2. عقارات الكويت reserves the right to suspend or terminate accounts that violate these Terms.\n\n5. Property Listings\n5.1. All property listings must be accurate, truthful, and comply with applicable laws.\n5.2. عقارات الكويت is not responsible for the accuracy of the information provided in property listings.\n\n6. Fees and Payments\n6.1. Basic services may be free, but premium features (e.g., promoted listings) may incur fees.\n6.2. Payments for premium features are non-refundable unless explicitly stated otherwise.\n\n7. Privacy\n7.1. By using عقارات الكويت, you agree to our Privacy Policy, which governs how we collect, use, and store your personal information.\n\n8. Disclaimer\n8.1. عقارات الكويت acts as a platform to connect buyers, sellers, and agents. We do not guarantee the quality, legality, or accuracy of the properties listed.\n8.2. Users interact and engage with others on the platform at their own risk.\n\n9. Limitation of Liability\n9.1. عقارات الكويت is not liable for any direct, indirect, or consequential damages resulting from the use or inability to use the platform.\n9.2. We are not responsible for disputes or issues between users.\n\n10. Termination\n10.1. عقارات الكويت reserves the right to suspend or terminate access to the platform for users who violate these Terms.\n\n11. Changes to the Terms\n11.1. عقارات الكويت reserves the right to modify these Terms at any time. Users will be notified of significant changes, and continued use of the platform constitutes acceptance of the updated Terms.',
                  style: FlutterFlowTheme.of(context).titleSmall.override(
                        font: GoogleFonts.cairo(
                          fontWeight: FlutterFlowTheme.of(context)
                              .titleSmall
                              .fontWeight,
                          fontStyle:
                              FlutterFlowTheme.of(context).titleSmall.fontStyle,
                        ),
                        letterSpacing: 0.0,
                        fontWeight:
                            FlutterFlowTheme.of(context).titleSmall.fontWeight,
                        fontStyle:
                            FlutterFlowTheme.of(context).titleSmall.fontStyle,
                      ),
                ),
              ),
            ]
                .addToStart(SizedBox(height: 15.0))
                .addToEnd(SizedBox(height: 15.0)),
          ),
        ),
        ),
      ),
    );
  }
}
