import '/flutter_flow/flutter_flow_util.dart';
import 'add_new_widget.dart' show AddNewWidget;
import 'package:flutter/material.dart';

class AddNewModel extends FlutterFlowModel<AddNewWidget> {
  final formKey = GlobalKey<FormState>();

  // الصور المختارة (حتى 6)
  List<FFUploadedFile> images = [];
  List<String> existingImages = [];
  bool isUploading = false;

  // نوع الإعلان: rent / sale
  String listingType = 'rent';

  // نوع العقار والمحافظة والمنطقة
  String? propertyType;
  String? governorate;
  String? area;

  /// المميزات التي اختارها المعلن (اختيارية)
  List<String> selectedFeatures = [];

  // التقسيم الداخلي
  int masterRooms = 0;
  int rooms = 1;
  int halls = 1;
  int kitchens = 1;
  int diwaniyas = 0;
  bool maidRoom = false;
  int bathrooms = 1;
  bool laundryRoom = false;

  /// حقول خاصة بأنواع معينة (أبراج/شاليهات/محلات)
  int units = 0;
  int floors = 0;

  /// دور العقار (يظهر للتصنيفات المناسبة فقط)
  String? floorLabel;
  FocusNode? frontageFocusNode;
  TextEditingController? frontageController;

  // الحقول النصية
  FocusNode? blockFocusNode;
  TextEditingController? blockController;
  String? Function(BuildContext, String?)? blockControllerValidator;

  FocusNode? streetFocusNode;
  TextEditingController? streetController;
  String? Function(BuildContext, String?)? streetControllerValidator;

  FocusNode? numberFocusNode;
  TextEditingController? numberController;
  String? Function(BuildContext, String?)? numberControllerValidator;

  FocusNode? sizeFocusNode;
  TextEditingController? sizeController;
  String? Function(BuildContext, String?)? sizeControllerValidator;

  FocusNode? priceFocusNode;
  TextEditingController? priceController;
  String? Function(BuildContext, String?)? priceControllerValidator;

  FocusNode? depositFocusNode;
  TextEditingController? depositController;
  String? Function(BuildContext, String?)? depositControllerValidator;

  FocusNode? phoneFocusNode;
  TextEditingController? phoneController;
  String? Function(BuildContext, String?)? phoneControllerValidator;

  FocusNode? whatsappFocusNode;
  TextEditingController? whatsappController;

  FocusNode? descFocusNode;
  TextEditingController? descController;
  String? Function(BuildContext, String?)? descControllerValidator;

  @override
  void initState(BuildContext context) {
    blockController = TextEditingController();
    streetController = TextEditingController();
    numberController = TextEditingController();
    sizeController = TextEditingController();
    priceController = TextEditingController();
    depositController = TextEditingController();
    frontageController = TextEditingController();
    phoneController = TextEditingController();
    whatsappController = TextEditingController();
    descController = TextEditingController();
  }

  @override
  void dispose() {
    blockFocusNode?.dispose();
    blockController?.dispose();
    streetFocusNode?.dispose();
    streetController?.dispose();
    numberFocusNode?.dispose();
    numberController?.dispose();
    sizeFocusNode?.dispose();
    sizeController?.dispose();
    priceFocusNode?.dispose();
    priceController?.dispose();
    depositFocusNode?.dispose();
    depositController?.dispose();
    frontageFocusNode?.dispose();
    frontageController?.dispose();
    phoneFocusNode?.dispose();
    phoneController?.dispose();
    whatsappFocusNode?.dispose();
    whatsappController?.dispose();
    descFocusNode?.dispose();
    descController?.dispose();
  }
}
