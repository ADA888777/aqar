import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_animations.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/home/components/filte_rooms/filte_rooms_widget.dart';
import '/home/components/filter_area/filter_area_widget.dart';
import '/home/components/filter_home_type/filter_home_type_widget.dart';
import '/home/components/filter_orientation/filter_orientation_widget.dart';
import '/home/components/filter_price/filter_price_widget.dart';
import '/home/components/filter_sort_by/filter_sort_by_widget.dart';
import '/home/components/filter_views/filter_views_widget.dart';
import '/home/components/property_card/property_card_widget.dart';
import '/home/z_filter_ameneties/z_filter_ameneties_widget.dart';
import '/walkthroughs/archive.dart';
import 'dart:math';
import 'dart:ui';
import '/index.dart';
import 'package:sticky_headers/sticky_headers.dart';
import 'package:tutorial_coach_mark/tutorial_coach_mark.dart'
    show TutorialCoachMark;
import 'package:aligned_dialog/aligned_dialog.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'search_archive_model.dart';
export 'search_archive_model.dart';

class SearchArchiveWidget extends StatefulWidget {
  const SearchArchiveWidget({
    super.key,
    this.category,
  });

  /// عند تمرير تصنيف، تُعرض إعلانات هذا التصنيف فقط
  final String? category;

  static String routeName = 'SearchArchive';
  static String routePath = '/searchArchive';

  @override
  State<SearchArchiveWidget> createState() => _SearchArchiveWidgetState();
}

class _SearchArchiveWidgetState extends State<SearchArchiveWidget>
    with TickerProviderStateMixin {
  late SearchArchiveModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  final animationsMap = <String, AnimationInfo>{};

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => SearchArchiveModel());

    // تحميل الصفحة الأولى (20 إعلاناً فقط)
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _loadNextPage(reset: true);
    });

    // On page load action.
    SchedulerBinding.instance.addPostFrameCallback((_) async {
      await Future.delayed(
        Duration(
          milliseconds: 700,
        ),
      );
      if (FFAppState().fromRegister == true) {
        safeSetState(
            () => _model.archiveController = createPageWalkthrough(context));
        _model.archiveController?.show(context: context);
        FFAppState().fromRegister = false;
        safeSetState(() {});
      }
    });

    _model.textController ??= TextEditingController();
    _model.textFieldFocusNode ??= FocusNode();

    animationsMap.addAll({
      'listViewOnPageLoadAnimation': AnimationInfo(
        trigger: AnimationTrigger.onPageLoad,
        effectsBuilder: () => [
          VisibilityEffect(duration: 1.ms),
          MoveEffect(
            curve: Curves.easeInOut,
            delay: 0.0.ms,
            duration: 300.0.ms,
            begin: Offset(0.0, 25.0),
            end: Offset(0.0, 0.0),
          ),
          FadeEffect(
            curve: Curves.easeInOut,
            delay: 0.0.ms,
            duration: 300.0.ms,
            begin: 0.4,
            end: 1.0,
          ),
        ],
      ),
    });
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  /// نافذة الفلاتر — تُفتح من زر الفلاتر وتعدّل حالة الموديل مباشرة.
  Future<void> _openFilterSheet() async {
    await showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) {
        return StatefulBuilder(
          builder: (ctx, setSheet) {
            Widget label(String t) => Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(0, 16, 0, 8),
                  child: Text(
                    t,
                    style: FlutterFlowTheme.of(context).titleSmall.override(
                          font: GoogleFonts.cairo(fontWeight: FontWeight.w600),
                          letterSpacing: 0.0,
                        ),
                  ),
                );

            Widget chip(String text, bool selected, VoidCallback onTap) =>
                InkWell(
                  splashColor: Colors.transparent,
                  onTap: () => setSheet(onTap),
                  child: Container(
                    padding:
                        EdgeInsets.symmetric(horizontal: 14, vertical: 9),
                    decoration: BoxDecoration(
                      color: selected
                          ? FlutterFlowTheme.of(context).primary
                          : FlutterFlowTheme.of(context).secondaryBackground,
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(
                        color: selected
                            ? FlutterFlowTheme.of(context).primary
                            : FlutterFlowTheme.of(context).alternate,
                      ),
                    ),
                    child: Text(
                      text,
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            font: GoogleFonts.cairo(
                                fontWeight:
                                    selected ? FontWeight.w600 : FontWeight.normal),
                            color: selected
                                ? Colors.white
                                : FlutterFlowTheme.of(context).primaryText,
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                );

            Widget counter(String t, int value, void Function(int) onChanged) =>
                Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(0, 0, 0, 8),
                  child: Row(
                    children: [
                      Expanded(
                        child: Text(
                          t,
                          style: FlutterFlowTheme.of(context)
                              .bodyMedium
                              .override(
                                font: GoogleFonts.cairo(),
                                letterSpacing: 0.0,
                              ),
                        ),
                      ),
                      IconButton(
                        onPressed: value > 0
                            ? () => setSheet(() => onChanged(value - 1))
                            : null,
                        icon: Icon(Icons.remove_circle_outline_rounded,
                            color: value > 0
                                ? FlutterFlowTheme.of(context).primary
                                : FlutterFlowTheme.of(context).alternate),
                      ),
                      Container(
                        width: 34,
                        alignment: Alignment.center,
                        child: Text(
                          value == 0 ? 'الكل' : '+$value',
                          style: FlutterFlowTheme.of(context)
                              .titleSmall
                              .override(
                                font: GoogleFonts.cairo(
                                    fontWeight: FontWeight.w600),
                                letterSpacing: 0.0,
                              ),
                        ),
                      ),
                      IconButton(
                        onPressed: value < 10
                            ? () => setSheet(() => onChanged(value + 1))
                            : null,
                        icon: Icon(Icons.add_circle_outline_rounded,
                            color: FlutterFlowTheme.of(context).primary),
                      ),
                    ],
                  ),
                );

            final areas = (_model.filterGovernorate == null)
                ? const <String>[]
                : (FFAppConstants
                        .AreasByGovernorate[_model.filterGovernorate] ??
                    const <String>[]);

            return Container(
              constraints: BoxConstraints(
                maxHeight: MediaQuery.sizeOf(context).height * 0.85,
              ),
              decoration: BoxDecoration(
                color: FlutterFlowTheme.of(context).primaryBackground,
                borderRadius:
                    BorderRadius.vertical(top: Radius.circular(20)),
              ),
              padding: EdgeInsets.fromLTRB(16, 8, 16, 16),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: 44,
                    height: 4,
                    decoration: BoxDecoration(
                      color: FlutterFlowTheme.of(context).alternate,
                      borderRadius: BorderRadius.circular(2),
                    ),
                  ),
                  Padding(
                    padding: EdgeInsetsDirectional.fromSTEB(0, 12, 0, 0),
                    child: Row(
                      children: [
                        Expanded(
                          child: Text(
                            'الفلاتر',
                            style: FlutterFlowTheme.of(context)
                                .headlineSmall
                                .override(
                                  font: GoogleFonts.cairo(
                                      fontWeight: FontWeight.w600),
                                  letterSpacing: 0.0,
                                ),
                          ),
                        ),
                        InkWell(
                          onTap: () => setSheet(() => _model.resetFilters()),
                          child: Text(
                            'إعادة تعيين',
                            style: FlutterFlowTheme.of(context)
                                .bodyMedium
                                .override(
                                  font: GoogleFonts.cairo(
                                      fontWeight: FontWeight.w600),
                                  color:
                                      FlutterFlowTheme.of(context).secondary,
                                  letterSpacing: 0.0,
                                ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Flexible(
                    child: SingleChildScrollView(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          label('نوع الإعلان'),
                          Wrap(spacing: 8, runSpacing: 8, children: [
                            chip('الكل', _model.filterListingType.isEmpty,
                                () => _model.filterListingType = ''),
                            chip('للإيجار',
                                _model.filterListingType == 'rent',
                                () => _model.filterListingType = 'rent'),
                            chip('للبيع', _model.filterListingType == 'sale',
                                () => _model.filterListingType = 'sale'),
                            chip(
                                'للبدل',
                                _model.filterListingType == 'exchange',
                                () => _model.filterListingType = 'exchange'),
                          ]),
                          label('التصنيف'),
                          Wrap(
                            spacing: 8,
                            runSpacing: 8,
                            children: [
                              chip(
                                  'الكل',
                                  (_model.filterCategory ?? '').isEmpty,
                                  () => _model.filterCategory = null),
                              ...FFAppConstants.PropertyCategories.map(
                                (c) => chip(
                                    FFAppConstants.categoryLabel(c),
                                    _model.filterCategory == c,
                                    () => _model.filterCategory = c),
                              ),
                            ],
                          ),
                          label('المحافظة'),
                          Wrap(
                            spacing: 8,
                            runSpacing: 8,
                            children: [
                              chip(
                                  'الكل',
                                  (_model.filterGovernorate ?? '').isEmpty,
                                  () {
                                _model.filterGovernorate = null;
                                _model.filterArea = null;
                              }),
                              ...FFAppConstants.Governorates.map(
                                (g) => chip(
                                    g, _model.filterGovernorate == g, () {
                                  _model.filterGovernorate = g;
                                  _model.filterArea = null;
                                }),
                              ),
                            ],
                          ),
                          if (areas.isNotEmpty) label('المنطقة'),
                          if (areas.isNotEmpty)
                            Wrap(
                              spacing: 8,
                              runSpacing: 8,
                              children: [
                                chip('الكل', (_model.filterArea ?? '').isEmpty,
                                    () => _model.filterArea = null),
                                ...areas.map((a) => chip(
                                    a,
                                    _model.filterArea == a,
                                    () => _model.filterArea = a)),
                              ],
                            ),
                          // الدور — يظهر للتصنيفات المناسبة فقط
                          if (FFAppConstants.CategoriesWithFloor.contains(
                              _model.filterCategory ?? widget.category ?? ''))
                            label('الدور'),
                          if (FFAppConstants.CategoriesWithFloor.contains(
                              _model.filterCategory ?? widget.category ?? ''))
                            Wrap(
                              spacing: 8.0,
                              runSpacing: 8.0,
                              children: [
                                chip('الكل',
                                    (_model.filterFloor ?? '').isEmpty,
                                    () => _model.filterFloor = null),
                                ...FFAppConstants.FloorOptions.map(
                                  (f) => chip(f, _model.filterFloor == f,
                                      () => _model.filterFloor = f),
                                ),
                              ],
                            ),
                          label('نطاق السعر (د.ك)'),
                          Row(
                            children: [
                              Expanded(
                                child: TextFormField(
                                  initialValue:
                                      _model.minPrice?.toStringAsFixed(0) ?? '',
                                  keyboardType: TextInputType.number,
                                  decoration: InputDecoration(
                                    hintText: 'من',
                                    isDense: true,
                                    border: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(10),
                                    ),
                                  ),
                                  style: FlutterFlowTheme.of(context)
                                      .bodyMedium
                                      .override(
                                        font: GoogleFonts.cairo(),
                                        letterSpacing: 0.0,
                                      ),
                                  onChanged: (v) => _model.minPrice =
                                      double.tryParse(v.trim()),
                                ),
                              ),
                              SizedBox(width: 10),
                              Expanded(
                                child: TextFormField(
                                  initialValue:
                                      _model.maxPrice?.toStringAsFixed(0) ?? '',
                                  keyboardType: TextInputType.number,
                                  decoration: InputDecoration(
                                    hintText: 'إلى',
                                    isDense: true,
                                    border: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(10),
                                    ),
                                  ),
                                  style: FlutterFlowTheme.of(context)
                                      .bodyMedium
                                      .override(
                                        font: GoogleFonts.cairo(),
                                        letterSpacing: 0.0,
                                      ),
                                  onChanged: (v) => _model.maxPrice =
                                      double.tryParse(v.trim()),
                                ),
                              ),
                            ],
                          ),
                          label('الغرف والحمامات'),
                          counter('أقل عدد غرف', _model.minRooms,
                              (v) => _model.minRooms = v),
                          counter('أقل عدد حمامات', _model.minBathrooms,
                              (v) => _model.minBathrooms = v),
                          label('الترتيب'),
                          Wrap(spacing: 8, runSpacing: 8, children: [
                            chip('الأحدث', _model.sortBy == 'newest',
                                () => _model.sortBy = 'newest'),
                            chip('الأقل سعراً', _model.sortBy == 'price_asc',
                                () => _model.sortBy = 'price_asc'),
                            chip('الأعلى سعراً', _model.sortBy == 'price_desc',
                                () => _model.sortBy = 'price_desc'),
                          ]),
                          SizedBox(height: 16),
                        ],
                      ),
                    ),
                  ),
                  FFButtonWidget(
                    onPressed: () => Navigator.pop(ctx),
                    text: 'عرض النتائج',
                    options: FFButtonOptions(
                      width: double.infinity,
                      height: 50,
                      padding: EdgeInsets.zero,
                      iconPadding: EdgeInsets.zero,
                      color: FlutterFlowTheme.of(context).primary,
                      textStyle: FlutterFlowTheme.of(context)
                          .titleSmall
                          .override(
                            font: GoogleFonts.cairo(
                                fontWeight: FontWeight.w600),
                            color: Colors.white,
                            fontSize: 16,
                            letterSpacing: 0.0,
                          ),
                      elevation: 0,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    showLoadingIndicator: false,
                  ),
                ],
              ),
            );
          },
        );
      },
    );
    // الفلاتر تغيّرت → أعد التحميل من الخادم بالشروط الجديدة
    await _loadNextPage(reset: true);
  }

  /// تحميل صفحة واحدة (20 إعلاناً) من Firestore.
  /// يطلب pageSize وثيقة فقط — لا يجلب المجموعة كاملة مهما بلغ عددها.
  Future<void> _loadNextPage({bool reset = false}) async {
    if (_model.isLoadingPage) return;
    if (!reset && !_model.hasMorePages) return;

    safeSetState(() {
      _model.isLoadingPage = true;
      if (reset) _model.resetPaging();
    });

    try {
      final snap = await fetchPropertiesPageSnapshot(
        pageSize: SearchArchiveModel.pageSize,
        startAfter: reset ? null : _model.lastDoc,
        // فلاتر المساواة على الخادم لتقليل الوثائق المنقولة
        category: _model.filterCategory ?? widget.category,
        listingType: _model.filterListingType.isEmpty
            ? null
            : _model.filterListingType,
        governorate: _model.filterGovernorate,
        floorLabel: _model.filterFloor,
      );
      final docs = snap.docs;
      safeSetState(() {
        _model.loadedProperties.addAll(
            docs.map((d) => PropertyDataRecord.fromSnapshot(d)));
        if (docs.isNotEmpty) _model.lastDoc = docs.last;
        _model.hasMorePages = docs.length >= SearchArchiveModel.pageSize;
        _model.isLoadingPage = false;
        _model.initialLoadDone = true;
      });
    } catch (_) {
      safeSetState(() {
        _model.isLoadingPage = false;
        _model.initialLoadDone = true;
      });
    }
  }

  /// يطبّق البحث النصي وكل الفلاتر والترتيب على قائمة الإعلانات.
  /// البحث يشمل: العنوان، المنطقة، المحافظة، الشارع، القطعة، الوصف، التصنيف.
  /// ملاحظة مهمة عن تقسيم العمل:
  ///  • الفلاتر التي يدعمها Firestore (التصنيف، نوع العرض، المحافظة،
  ///    الدور) تُنفَّذ على الخادم في fetchPropertiesPageSnapshot — فلا
  ///    تصل الوثائق غير المطابقة للجهاز أصلاً.
  ///  • ما تبقى هنا يعمل على الدفعة المحمّلة فقط (15 وثيقة): البحث
  ///    النصي، ونطاق السعر، والحد الأدنى للغرف — لأن Firestore لا
  ///    يدعم بحثاً نصياً جزئياً ولا يجمع أكثر من نطاق واحد في استعلام.
  ///  • الشروط الأربعة الأولى مكررة كطبقة أمان لا أكثر (تكلفتها صفر
  ///    على 15 عنصراً).
  List<PropertyDataRecord> _applyFilters(List<PropertyDataRecord> source) {
    final q = _model.textController.text.trim().toLowerCase();
    // التصنيف: من الرئيسية (widget.category) أو من نافذة الفلاتر
    final cat = (_model.filterCategory ?? widget.category ?? '').trim();

    var list = source.where((p) {
      // 1) البحث النصي
      if (q.isNotEmpty) {
        final haystack = [
          p.title,
          p.area,
          p.governorate,
          p.street,
          p.block,
          p.description,
          p.category,
        ].join(' ').toLowerCase();
        if (!haystack.contains(q)) return false;
      }
      // 2) التصنيف
      if (cat.isNotEmpty && p.category.trim() != cat) return false;
      // 3) نوع الإعلان (إيجار/بيع)
      if (_model.filterListingType.isNotEmpty &&
          p.listingTypy.trim() != _model.filterListingType) return false;
      // 4) المحافظة والمنطقة
      final gov = (_model.filterGovernorate ?? '').trim();
      if (gov.isNotEmpty && p.governorate.trim() != gov) return false;
      final ar = (_model.filterArea ?? '').trim();
      if (ar.isNotEmpty && p.area.trim() != ar) return false;
      // 5) نطاق السعر
      if (_model.minPrice != null && p.price < _model.minPrice!) return false;
      if (_model.maxPrice != null && p.price > _model.maxPrice!) return false;
      // 6) الغرف والحمامات
      if (_model.minRooms > 0 && p.rooms < _model.minRooms) return false;
      if (_model.minBathrooms > 0 && p.bathrooms < _model.minBathrooms) {
        return false;
      }
      return true;
    }).toList();

    // 7) الترتيب
    switch (_model.sortBy) {
      case 'price_asc':
        list.sort((a, b) => a.price.compareTo(b.price));
        break;
      case 'price_desc':
        list.sort((a, b) => b.price.compareTo(a.price));
        break;
      default: // newest
        list.sort((a, b) => (b.createdAt ?? DateTime(2000))
            .compareTo(a.createdAt ?? DateTime(2000)));
    }
    return list;
  }

  @override
  Widget build(BuildContext context) {
    context.watch<FFAppState>();

    return GestureDetector(
      onTap: () {
        FocusScope.of(context).unfocus();
        FocusManager.instance.primaryFocus?.unfocus();
      },
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
        appBar: PreferredSize(
          preferredSize: Size.fromHeight(0.0),
          child: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).secondaryBackground,
            automaticallyImplyLeading: false,
            actions: [],
            centerTitle: false,
            elevation: 0.0,
          ),
        ),
        body: SafeArea(
         child: Stack(
          alignment: AlignmentDirectional(0.0, 1.0),
          children: [
            Column(
              mainAxisSize: MainAxisSize.max,
              children: [
                Expanded(
                  child: SingleChildScrollView(
                    primary: false,
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Container(
                          decoration: BoxDecoration(
                            color: FlutterFlowTheme.of(context)
                                .secondaryBackground,
                          ),
                          child: Padding(
                            padding: EdgeInsetsDirectional.fromSTEB(
                                0.0, 20.0, 0.0, 0.0),
                            child: Column(
                              mainAxisSize: MainAxisSize.max,
                              children: [
                                Padding(
                                  padding: EdgeInsetsDirectional.fromSTEB(
                                      15.0, 0.0, 15.0, 0.0),
                                  child: AnimatedContainer(
                                    duration: Duration(milliseconds: 500),
                                    curve: Curves.easeInOut,
                                    width: double.infinity,
                                    height: 52.0,
                                    decoration: BoxDecoration(
                                      color:
                                          FlutterFlowTheme.of(context).accent1,
                                      borderRadius: BorderRadius.circular(12.0),
                                    ),
                                    child: Row(
                                      mainAxisSize: MainAxisSize.max,
                                      children: [
                                        Stack(
                                          alignment:
                                              AlignmentDirectional(0.0, 0.0),
                                          children: [
                                            Align(
                                              alignment: AlignmentDirectional(
                                                  0.0, 0.0),
                                              child: Padding(
                                                padding: EdgeInsetsDirectional
                                                    .fromSTEB(
                                                        0.0, 0.0, 2.0, 0.0),
                                                child: Icon(
                                                  FFIcons.kchevronLeft,
                                                  color: FlutterFlowTheme.of(
                                                          context)
                                                      .primaryText,
                                                  size: 27.0,
                                                ),
                                              ),
                                            ),
                                            Padding(
                                              padding: EdgeInsetsDirectional
                                                  .fromSTEB(5.0, 7.0, 5.0, 7.0),
                                              child: FlutterFlowIconButton(
                                                borderColor: Colors.transparent,
                                                borderRadius: 50.0,
                                                buttonSize: 38.0,
                                                fillColor:
                                                    FlutterFlowTheme.of(context)
                                                        .accent4,
                                                icon: Icon(
                                                  Icons.chevron_left_rounded,
                                                  color: FlutterFlowTheme.of(
                                                          context)
                                                      .accent4,
                                                  size: 0.0,
                                                ),
                                                onPressed: () async {
                                                  await Future.delayed(
                                                    Duration(
                                                      milliseconds: 100,
                                                    ),
                                                  );
                                                  context.safePop();
                                                },
                                              ),
                                            ),
                                          ],
                                        ),
                                        Container(
                                          width: 1.0,
                                          height: 30.0,
                                          decoration: BoxDecoration(
                                            color: FlutterFlowTheme.of(context)
                                                .border,
                                          ),
                                        ),
                                        Expanded(
                                          child: Padding(
                                            padding:
                                                EdgeInsetsDirectional.fromSTEB(
                                                    0.0, 0.0, 15.0, 0.0),
                                            child: Container(
                                              width: 200.0,
                                              child: TextFormField(
                                                controller:
                                                    _model.textController,
                                                focusNode:
                                                    _model.textFieldFocusNode,
                                                onChanged: (_) =>
                                                    safeSetState(() {}),
                                                autofocus: false,
                                                obscureText: false,
                                                decoration: InputDecoration(
                                                  isDense: false,
                                                  hintText:
                                                      '',
                                                  hintStyle: FlutterFlowTheme
                                                          .of(context)
                                                      .titleSmall
                                                      .override(
                                                        font: GoogleFonts.cairo(
                                                          fontWeight:
                                                              FlutterFlowTheme.of(
                                                                      context)
                                                                  .titleSmall
                                                                  .fontWeight,
                                                          fontStyle:
                                                              FlutterFlowTheme.of(
                                                                      context)
                                                                  .titleSmall
                                                                  .fontStyle,
                                                        ),
                                                        color:
                                                            FlutterFlowTheme.of(
                                                                    context)
                                                                .secondaryText,
                                                        letterSpacing: 0.0,
                                                        fontWeight:
                                                            FlutterFlowTheme.of(
                                                                    context)
                                                                .titleSmall
                                                                .fontWeight,
                                                        fontStyle:
                                                            FlutterFlowTheme.of(
                                                                    context)
                                                                .titleSmall
                                                                .fontStyle,
                                                      ),
                                                  enabledBorder:
                                                      OutlineInputBorder(
                                                    borderSide: BorderSide(
                                                      color: Color(0x00000000),
                                                      width: 1.0,
                                                    ),
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            0.0),
                                                  ),
                                                  focusedBorder:
                                                      OutlineInputBorder(
                                                    borderSide: BorderSide(
                                                      color: Color(0x00000000),
                                                      width: 1.0,
                                                    ),
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            0.0),
                                                  ),
                                                  errorBorder:
                                                      OutlineInputBorder(
                                                    borderSide: BorderSide(
                                                      color:
                                                          FlutterFlowTheme.of(
                                                                  context)
                                                              .error,
                                                      width: 1.0,
                                                    ),
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            0.0),
                                                  ),
                                                  focusedErrorBorder:
                                                      OutlineInputBorder(
                                                    borderSide: BorderSide(
                                                      color:
                                                          FlutterFlowTheme.of(
                                                                  context)
                                                              .error,
                                                      width: 1.0,
                                                    ),
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            0.0),
                                                  ),
                                                  contentPadding:
                                                      EdgeInsetsDirectional
                                                          .fromSTEB(15.0, 0.0,
                                                              0.0, 0.0),
                                                  hoverColor:
                                                      FlutterFlowTheme.of(
                                                              context)
                                                          .accent4,
                                                ),
                                                style:
                                                    FlutterFlowTheme.of(context)
                                                        .titleSmall
                                                        .override(
                                                          font:
                                                              GoogleFonts.cairo(
                                                            fontWeight:
                                                                FlutterFlowTheme.of(
                                                                        context)
                                                                    .titleSmall
                                                                    .fontWeight,
                                                            fontStyle:
                                                                FlutterFlowTheme.of(
                                                                        context)
                                                                    .titleSmall
                                                                    .fontStyle,
                                                          ),
                                                          letterSpacing: 0.0,
                                                          fontWeight:
                                                              FlutterFlowTheme.of(
                                                                      context)
                                                                  .titleSmall
                                                                  .fontWeight,
                                                          fontStyle:
                                                              FlutterFlowTheme.of(
                                                                      context)
                                                                  .titleSmall
                                                                  .fontStyle,
                                                        ),
                                                cursorColor:
                                                    FlutterFlowTheme.of(context)
                                                        .primaryText,
                                                validator: _model
                                                    .textControllerValidator
                                                    .asValidator(context),
                                              ),
                                            ),
                                          ),
                                        ),
                                        // زر الفلاتر — يعرض عدد الفلاتر المفعّلة
                                        Padding(
                                          padding: EdgeInsetsDirectional.fromSTEB(8.0, 0.0, 0.0, 0.0),
                                          child: InkWell(
                                            splashColor: Colors.transparent,
                                            focusColor: Colors.transparent,
                                            hoverColor: Colors.transparent,
                                            highlightColor: Colors.transparent,
                                            onTap: () async {
                                              await _openFilterSheet();
                                            },
                                            child: Container(
                                              padding: EdgeInsets.symmetric(horizontal: 12.0, vertical: 10.0),
                                              decoration: BoxDecoration(
                                                color: _model.activeFiltersCount > 0
                                                    ? FlutterFlowTheme.of(context).primary
                                                    : FlutterFlowTheme.of(context).secondaryBackground,
                                                borderRadius: BorderRadius.circular(10.0),
                                                border: Border.all(
                                                  color: FlutterFlowTheme.of(context).alternate,
                                                ),
                                              ),
                                              child: Row(
                                                mainAxisSize: MainAxisSize.min,
                                                children: [
                                                  Icon(
                                                    Icons.tune_rounded,
                                                    size: 20.0,
                                                    color: _model.activeFiltersCount > 0
                                                        ? Colors.white
                                                        : FlutterFlowTheme.of(context).primaryText,
                                                  ),
                                                  if (_model.activeFiltersCount > 0)
                                                    Padding(
                                                      padding:
                                                          EdgeInsetsDirectional.fromSTEB(6.0, 0.0, 0.0, 0.0),
                                                      child: Text(
                                                        _model.activeFiltersCount.toString(),
                                                        style: FlutterFlowTheme.of(context)
                                                            .bodySmall
                                                            .override(
                                                              font: GoogleFonts.cairo(
                                                                  fontWeight: FontWeight.w600),
                                                              color: Colors.white,
                                                              letterSpacing: 0.0,
                                                            ),
                                                      ),
                                                    ),
                                                ],
                                              ),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        Expanded(
                          child: StickyHeader(
                            overlapHeaders: false,
                            header: Column(
                              mainAxisSize: MainAxisSize.max,
                              children: [
                                Container(
                                  decoration: BoxDecoration(
                                    color: FlutterFlowTheme.of(context)
                                        .secondaryBackground,
                                  ),
                                  child: Padding(
                                    padding: EdgeInsetsDirectional.fromSTEB(
                                        0.0, 12.0, 0.0, 12.0),
                                    child: SingleChildScrollView(
                                      scrollDirection: Axis.horizontal,
                                      child: Row(
                                        mainAxisSize: MainAxisSize.max,
                                        children: [
                                          InkWell(
                                            splashColor: Colors.transparent,
                                            focusColor: Colors.transparent,
                                            hoverColor: Colors.transparent,
                                            highlightColor: Colors.transparent,
                                            onTap: () async {
                                              FFAppState().messagesTab = 0;
                                              safeSetState(() {});

                                              context.pushNamed(
                                                  SearchArchiveFilterWidget
                                                      .routeName);
                                            },
                                            child: Container(
                                              height: 38.0,
                                              decoration: BoxDecoration(
                                                color:
                                                    FlutterFlowTheme.of(context)
                                                        .accent1,
                                                borderRadius:
                                                    BorderRadius.circular(10.0),
                                              ),
                                              child: Padding(
                                                padding: EdgeInsetsDirectional
                                                    .fromSTEB(
                                                        12.0, 0.0, 0.0, 0.0),
                                                child: Row(
                                                  mainAxisSize:
                                                      MainAxisSize.max,
                                                  children: [
                                                    Stack(
                                                      alignment:
                                                          AlignmentDirectional(
                                                              1.0, -1.0),
                                                      children: [
                                                        Icon(
                                                          FFIcons
                                                              .kadjustmentsHorizontal,
                                                          color: FlutterFlowTheme
                                                                  .of(context)
                                                              .primaryText,
                                                          size: 22.0,
                                                        ),
                                                        Padding(
                                                          padding:
                                                              EdgeInsetsDirectional
                                                                  .fromSTEB(
                                                                      0.0,
                                                                      2.0,
                                                                      2.0,
                                                                      0.0),
                                                          child: Container(
                                                            width: 6.0,
                                                            height: 6.0,
                                                            decoration:
                                                                BoxDecoration(
                                                              color: FlutterFlowTheme
                                                                      .of(context)
                                                                  .primary,
                                                              boxShadow: [
                                                                BoxShadow(
                                                                  blurRadius:
                                                                      0.0,
                                                                  color: FlutterFlowTheme.of(
                                                                          context)
                                                                      .accent1,
                                                                  offset:
                                                                      Offset(
                                                                    0.0,
                                                                    0.0,
                                                                  ),
                                                                  spreadRadius:
                                                                      2.0,
                                                                )
                                                              ],
                                                              shape: BoxShape
                                                                  .circle,
                                                            ),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                    Padding(
                                                      padding:
                                                          EdgeInsetsDirectional
                                                              .fromSTEB(
                                                                  10.0,
                                                                  0.0,
                                                                  12.0,
                                                                  0.0),
                                                      child: Text(
                                                        'الفلاتر',
                                                        style:
                                                            FlutterFlowTheme.of(
                                                                    context)
                                                                .titleSmall
                                                                .override(
                                                                  font:
                                                                      GoogleFonts
                                                                          .cairo(
                                                                    fontWeight:
                                                                        FontWeight
                                                                            .w500,
                                                                    fontStyle: FlutterFlowTheme.of(
                                                                            context)
                                                                        .titleSmall
                                                                        .fontStyle,
                                                                  ),
                                                                  letterSpacing:
                                                                      0.0,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .w500,
                                                                  fontStyle: FlutterFlowTheme.of(
                                                                          context)
                                                                      .titleSmall
                                                                      .fontStyle,
                                                                ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                          ).addWalkthrough(
                                            containerP5ty8vss,
                                            _model.archiveController,
                                          ),
                                          InkWell(
                                            splashColor: Colors.transparent,
                                            focusColor: Colors.transparent,
                                            hoverColor: Colors.transparent,
                                            highlightColor: Colors.transparent,
                                            onTap: () async {
                                              await showModalBottomSheet(
                                                isScrollControlled: true,
                                                backgroundColor:
                                                    FlutterFlowTheme.of(context)
                                                        .accent4,
                                                barrierColor:
                                                    FlutterFlowTheme.of(context)
                                                        .barier,
                                                context: context,
                                                builder: (context) {
                                                  return GestureDetector(
                                                    onTap: () {
                                                      FocusScope.of(context)
                                                          .unfocus();
                                                      FocusManager
                                                          .instance.primaryFocus
                                                          ?.unfocus();
                                                    },
                                                    child: Padding(
                                                      padding: MediaQuery
                                                          .viewInsetsOf(
                                                              context),
                                                      child: FilteRoomsWidget(),
                                                    ),
                                                  );
                                                },
                                              ).then((value) =>
                                                  safeSetState(() {}));
                                            },
                                            child: Container(
                                              height: 38.0,
                                              decoration: BoxDecoration(
                                                color:
                                                    FlutterFlowTheme.of(context)
                                                        .accent1,
                                                borderRadius:
                                                    BorderRadius.circular(10.0),
                                              ),
                                              child: Row(
                                                mainAxisSize: MainAxisSize.max,
                                                mainAxisAlignment:
                                                    MainAxisAlignment.center,
                                                children: [
                                                  Padding(
                                                    padding:
                                                        EdgeInsetsDirectional
                                                            .fromSTEB(15.0, 0.0,
                                                                10.0, 0.0),
                                                    child: Text(
                                                      'الغرف',
                                                      style: FlutterFlowTheme
                                                              .of(context)
                                                          .titleSmall
                                                          .override(
                                                            font: GoogleFonts
                                                                .cairo(
                                                              fontWeight:
                                                                  FontWeight
                                                                      .w500,
                                                              fontStyle:
                                                                  FlutterFlowTheme.of(
                                                                          context)
                                                                      .titleSmall
                                                                      .fontStyle,
                                                            ),
                                                            letterSpacing: 0.0,
                                                            fontWeight:
                                                                FontWeight.w500,
                                                            fontStyle:
                                                                FlutterFlowTheme.of(
                                                                        context)
                                                                    .titleSmall
                                                                    .fontStyle,
                                                          ),
                                                    ),
                                                  ),
                                                  Container(
                                                    width: 1.0,
                                                    height: 22.0,
                                                    decoration: BoxDecoration(
                                                      color:
                                                          FlutterFlowTheme.of(
                                                                  context)
                                                              .border,
                                                    ),
                                                  ),
                                                  Padding(
                                                    padding:
                                                        EdgeInsetsDirectional
                                                            .fromSTEB(6.0, 0.0,
                                                                6.0, 0.0),
                                                    child: Icon(
                                                      FFIcons.kchevronDown,
                                                      color:
                                                          FlutterFlowTheme.of(
                                                                  context)
                                                              .primaryText,
                                                      size: 22.0,
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                        ]
                                            .divide(SizedBox(width: 12.0))
                                            .addToStart(SizedBox(width: 15.0))
                                            .addToEnd(SizedBox(width: 15.0)),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                            content: SingleChildScrollView(
                              primary: false,
                              child: Column(
                                mainAxisSize: MainAxisSize.min,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                                        // ===== فلتر سريع: نوع العرض حسب التصنيف =====
                                  Builder(
                                    builder: (context) {
                                      final cat =
                                          _model.filterCategory ?? widget.category ?? '';
                                      final allowed =
                                          FFAppConstants.ListingTypesByCategory[cat];
                                      if (allowed == null || allowed.isEmpty) {
                                        return SizedBox.shrink();
                                      }
                                      Widget quick(String value, String text) {
                                        final sel = _model.filterListingType == value;
                                        return Expanded(
                                          child: InkWell(
                                            splashColor: Colors.transparent,
                                            focusColor: Colors.transparent,
                                            hoverColor: Colors.transparent,
                                            highlightColor: Colors.transparent,
                                            onTap: () async {
                                              safeSetState(() =>
                                                  _model.filterListingType = sel ? '' : value);
                                              // فلترة حقيقية على الخادم
                                              await _loadNextPage(reset: true);
                                            },
                                            child: Container(
                                              padding: EdgeInsets.symmetric(vertical: 9.0),
                                              decoration: BoxDecoration(
                                                color: sel
                                                    ? FlutterFlowTheme.of(context).primary
                                                    : FlutterFlowTheme.of(context)
                                                        .secondaryBackground,
                                                borderRadius: BorderRadius.circular(10.0),
                                                border: Border.all(
                                                  color: sel
                                                      ? FlutterFlowTheme.of(context).primary
                                                      : FlutterFlowTheme.of(context).alternate,
                                                ),
                                              ),
                                              alignment: Alignment.center,
                                              child: Text(
                                                text,
                                                style: FlutterFlowTheme.of(context)
                                                    .bodyMedium
                                                    .override(
                                                      font: GoogleFonts.cairo(
                                                          fontWeight: sel
                                                              ? FontWeight.w600
                                                              : FontWeight.normal),
                                                      color: sel
                                                          ? Colors.white
                                                          : FlutterFlowTheme.of(context)
                                                              .primaryText,
                                                      letterSpacing: 0.0,
                                                    ),
                                              ),
                                            ),
                                          ),
                                        );
                                      }

                                      final chips = <Widget>[];
                                      for (var i = 0; i < allowed.length; i++) {
                                        if (i > 0) chips.add(SizedBox(width: 8.0));
                                        chips.add(quick(allowed[i],
                                            FFAppConstants.ListingTypeLabels[allowed[i]] ??
                                                allowed[i]));
                                      }
                                      return Padding(
                                        padding: EdgeInsetsDirectional.fromSTEB(
                                            15.0, 8.0, 15.0, 4.0),
                                        child: Row(children: chips),
                                      );
                                    },
                                  ),
                                  Padding(
                                    padding: EdgeInsetsDirectional.fromSTEB(
                                        0.0, 1.0, 0.0, 0.0),
                                    child:
                  // عرض الإعلانات المحمّلة صفحةً صفحة (Pagination حقيقية).
                                        // لا StreamBuilder على المجموعة كاملة — كل دفعة 20 وثيقة فقط.
                                        Builder(
                                          builder: (context) {
                                            if (!_model.initialLoadDone && _model.isLoadingPage) {
                                              return Center(
                                                child: SizedBox(
                                                  width: 25.0,
                                                  height: 25.0,
                                                  child: CircularProgressIndicator(
                                                    valueColor: AlwaysStoppedAnimation<Color>(
                                                      FlutterFlowTheme.of(context).primary,
                                                    ),
                                                  ),
                                                ),
                                              );
                                            }
                                            final results = _applyFilters(_model.loadedProperties);
                                            if (results.isEmpty) {
                                              return Padding(
                                                padding: EdgeInsetsDirectional.fromSTEB(24.0, 40.0, 24.0, 0.0),
                                                child: Text(
                                                  'لا توجد نتائج مطابقة لبحثك',
                                                  textAlign: TextAlign.center,
                                                  style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                        font: GoogleFonts.cairo(),
                                                        color: FlutterFlowTheme.of(context).secondaryText,
                                                        letterSpacing: 0.0,
                                                      ),
                                                ),
                                              );
                                            }
                                            return NotificationListener<ScrollNotification>(
                                              onNotification: (n) {
                                                // طلب الدفعة التالية عند الاقتراب من نهاية القائمة
                                                if (n.metrics.pixels >= n.metrics.maxScrollExtent - 300 &&
                                                    !_model.isLoadingPage &&
                                                    _model.hasMorePages) {
                                                  _loadNextPage();
                                                }
                                                return false;
                                              },
                                              child: ListView.separated(
                                                padding: EdgeInsets.fromLTRB(15.0, 0.0, 15.0, 24.0),
                                                primary: false,
                                                shrinkWrap: true,
                                                itemCount: results.length + (_model.hasMorePages ? 1 : 0),
                                                separatorBuilder: (_, __) => SizedBox(height: 15.0),
                                                itemBuilder: (context, i) {
                                                  if (i >= results.length) {
                                                    // مؤشر تحميل الدفعة التالية
                                                    return Padding(
                                                      padding: EdgeInsets.symmetric(vertical: 16.0),
                                                      child: Center(
                                                        child: SizedBox(
                                                          width: 22.0,
                                                          height: 22.0,
                                                          child: CircularProgressIndicator(
                                                            valueColor: AlwaysStoppedAnimation<Color>(
                                                              FlutterFlowTheme.of(context).primary,
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    );
                                                  }
                                                  return PropertyCardWidget(
                                                    key: Key('propCard_$i'),
                                                    data: results[i],
                                                    index: i,
                                                  );
                                                },
                                              ),
                                            );
                                          },
                                        ),
                                  ),
                                ].addToEnd(SizedBox(height: 20.0)),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
       ),
      ),
    );
  }

  TutorialCoachMark createPageWalkthrough(BuildContext context) =>
      TutorialCoachMark(
        targets: createWalkthroughTargets(context),
        onFinish: () async {
          safeSetState(() => _model.archiveController = null);
        },
        onSkip: () {
          return true;
        },
      );
}
