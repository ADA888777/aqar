import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../auth/firebase_auth/auth_util.dart';

import '../flutter_flow/flutter_flow_util.dart';
import 'schema/util/firestore_util.dart';

import 'schema/users_record.dart';
import 'schema/property_data_record.dart';
import 'schema/realtors_record.dart';
import 'schema/chats_record.dart';
import 'schema/messages_record.dart';
import 'schema/reviews_record.dart';
import 'schema/contact_requests_record.dart';
import 'schema/property_requests_record.dart';

export 'dart:async' show StreamSubscription;
export 'package:cloud_firestore/cloud_firestore.dart' hide Order;
export 'package:firebase_core/firebase_core.dart';
export 'schema/index.dart';
export 'schema/util/firestore_util.dart';
export 'schema/util/schema_util.dart';

export 'schema/users_record.dart';
export 'schema/property_data_record.dart';
export 'schema/realtors_record.dart';
export 'schema/chats_record.dart';
export 'schema/messages_record.dart';
export 'schema/reviews_record.dart';
export 'schema/contact_requests_record.dart';
export 'schema/property_requests_record.dart';

/// Functions to query UsersRecords (as a Stream and as a Future).
Future<int> queryUsersRecordCount({
  Query Function(Query)? queryBuilder,
  int limit = -1,
}) =>
    queryCollectionCount(
      UsersRecord.collection,
      queryBuilder: queryBuilder,
      limit: limit,
    );

Stream<List<UsersRecord>> queryUsersRecord({
  Query Function(Query)? queryBuilder,
  int limit = -1,
  bool singleRecord = false,
}) =>
    queryCollection(
      UsersRecord.collection,
      UsersRecord.fromSnapshot,
      queryBuilder: queryBuilder,
      limit: limit,
      singleRecord: singleRecord,
    );

Future<List<UsersRecord>> queryUsersRecordOnce({
  Query Function(Query)? queryBuilder,
  int limit = -1,
  bool singleRecord = false,
}) =>
    queryCollectionOnce(
      UsersRecord.collection,
      UsersRecord.fromSnapshot,
      queryBuilder: queryBuilder,
      limit: limit,
      singleRecord: singleRecord,
    );

/// Functions to query PropertyDataRecords (as a Stream and as a Future).
Future<int> queryPropertyDataRecordCount({
  Query Function(Query)? queryBuilder,
  int limit = -1,
}) =>
    queryCollectionCount(
      PropertyDataRecord.collection,
      queryBuilder: queryBuilder,
      limit: limit,
    );

Stream<List<PropertyDataRecord>> queryPropertyDataRecord({
  Query Function(Query)? queryBuilder,
  int limit = -1,
  bool singleRecord = false,
}) =>
    queryCollection(
      PropertyDataRecord.collection,
      PropertyDataRecord.fromSnapshot,
      queryBuilder: queryBuilder,
      limit: limit,
      singleRecord: singleRecord,
    );

Future<List<PropertyDataRecord>> queryPropertyDataRecordOnce({
  Query Function(Query)? queryBuilder,
  int limit = -1,
  bool singleRecord = false,
}) =>
    queryCollectionOnce(
      PropertyDataRecord.collection,
      PropertyDataRecord.fromSnapshot,
      queryBuilder: queryBuilder,
      limit: limit,
      singleRecord: singleRecord,
    );

/// Functions to query RealtorsRecords (as a Stream and as a Future).
Future<int> queryRealtorsRecordCount({
  Query Function(Query)? queryBuilder,
  int limit = -1,
}) =>
    queryCollectionCount(
      RealtorsRecord.collection,
      queryBuilder: queryBuilder,
      limit: limit,
    );

Stream<List<RealtorsRecord>> queryRealtorsRecord({
  Query Function(Query)? queryBuilder,
  int limit = -1,
  bool singleRecord = false,
}) =>
    queryCollection(
      RealtorsRecord.collection,
      RealtorsRecord.fromSnapshot,
      queryBuilder: queryBuilder,
      limit: limit,
      singleRecord: singleRecord,
    );

Future<List<RealtorsRecord>> queryRealtorsRecordOnce({
  Query Function(Query)? queryBuilder,
  int limit = -1,
  bool singleRecord = false,
}) =>
    queryCollectionOnce(
      RealtorsRecord.collection,
      RealtorsRecord.fromSnapshot,
      queryBuilder: queryBuilder,
      limit: limit,
      singleRecord: singleRecord,
    );

/// Functions to query ChatsRecords (as a Stream and as a Future).
Future<int> queryChatsRecordCount({
  Query Function(Query)? queryBuilder,
  int limit = -1,
}) =>
    queryCollectionCount(
      ChatsRecord.collection,
      queryBuilder: queryBuilder,
      limit: limit,
    );

Stream<List<ChatsRecord>> queryChatsRecord({
  Query Function(Query)? queryBuilder,
  int limit = -1,
  bool singleRecord = false,
}) =>
    queryCollection(
      ChatsRecord.collection,
      ChatsRecord.fromSnapshot,
      queryBuilder: queryBuilder,
      limit: limit,
      singleRecord: singleRecord,
    );

Future<List<ChatsRecord>> queryChatsRecordOnce({
  Query Function(Query)? queryBuilder,
  int limit = -1,
  bool singleRecord = false,
}) =>
    queryCollectionOnce(
      ChatsRecord.collection,
      ChatsRecord.fromSnapshot,
      queryBuilder: queryBuilder,
      limit: limit,
      singleRecord: singleRecord,
    );

/// Functions to query MessagesRecords (as a Stream and as a Future).
Future<int> queryMessagesRecordCount({
  Query Function(Query)? queryBuilder,
  int limit = -1,
}) =>
    queryCollectionCount(
      MessagesRecord.collection,
      queryBuilder: queryBuilder,
      limit: limit,
    );

Stream<List<MessagesRecord>> queryMessagesRecord({
  Query Function(Query)? queryBuilder,
  int limit = -1,
  bool singleRecord = false,
}) =>
    queryCollection(
      MessagesRecord.collection,
      MessagesRecord.fromSnapshot,
      queryBuilder: queryBuilder,
      limit: limit,
      singleRecord: singleRecord,
    );

Future<List<MessagesRecord>> queryMessagesRecordOnce({
  Query Function(Query)? queryBuilder,
  int limit = -1,
  bool singleRecord = false,
}) =>
    queryCollectionOnce(
      MessagesRecord.collection,
      MessagesRecord.fromSnapshot,
      queryBuilder: queryBuilder,
      limit: limit,
      singleRecord: singleRecord,
    );

/// Functions to query ReviewsRecords (as a Stream and as a Future).
Future<int> queryReviewsRecordCount({
  Query Function(Query)? queryBuilder,
  int limit = -1,
}) =>
    queryCollectionCount(
      ReviewsRecord.collection,
      queryBuilder: queryBuilder,
      limit: limit,
    );

Stream<List<ReviewsRecord>> queryReviewsRecord({
  Query Function(Query)? queryBuilder,
  int limit = -1,
  bool singleRecord = false,
}) =>
    queryCollection(
      ReviewsRecord.collection,
      ReviewsRecord.fromSnapshot,
      queryBuilder: queryBuilder,
      limit: limit,
      singleRecord: singleRecord,
    );

Future<List<ReviewsRecord>> queryReviewsRecordOnce({
  Query Function(Query)? queryBuilder,
  int limit = -1,
  bool singleRecord = false,
}) =>
    queryCollectionOnce(
      ReviewsRecord.collection,
      ReviewsRecord.fromSnapshot,
      queryBuilder: queryBuilder,
      limit: limit,
      singleRecord: singleRecord,
    );

/// Functions to query PropertyRequestsRecords.
Stream<List<PropertyRequestsRecord>> queryPropertyRequestsRecord({
  Query Function(Query)? queryBuilder,
  int limit = -1,
  bool singleRecord = false,
}) =>
    queryCollection(
      PropertyRequestsRecord.collection,
      PropertyRequestsRecord.fromSnapshot,
      queryBuilder: queryBuilder,
      limit: limit,
      singleRecord: singleRecord,
    );

Future<List<PropertyRequestsRecord>> queryPropertyRequestsRecordOnce({
  Query Function(Query)? queryBuilder,
  int limit = -1,
  bool singleRecord = false,
}) =>
    queryCollectionOnce(
      PropertyRequestsRecord.collection,
      PropertyRequestsRecord.fromSnapshot,
      queryBuilder: queryBuilder,
      limit: limit,
      singleRecord: singleRecord,
    );

/// هل المستخدم الحالي مدير؟
/// ملاحظة أمنية: هذا للواجهة فقط (إظهار/إخفاء الأزرار).
/// الحماية الحقيقية في Firestore Rules عبر isAdmin() هناك —
/// فحتى لو تلاعب أحد بالتطبيق، الخادم يرفض العملية.
bool get currentUserIsAdmin =>
    currentUserDocument?.role.trim().toLowerCase() == 'admin';

/// حذف إعلان مخالف (للمدير فقط).
/// الخادم يتحقق من الصلاحية؛ الفشل يعني أن المستخدم ليس مديراً.
Future<void> adminDeleteProperty(PropertyDataRecord property) async {
  await property.reference.delete();
}

/// تعطيل إعلان مخالف بدل حذفه (أفضل للمراجعة والاسترجاع).
Future<void> adminDisableProperty(PropertyDataRecord property) async {
  await property.reference.update({
    'isApproved': false,
    'is_archived': true,
  });
}

/// ═══ دورة حياة الإعلان ═══
/// مدة صلاحية الإعلان بالأيام (قابلة للتعديل من مكان واحد)
const int kListingDurationDays = 30;

/// مدة الاحتفاظ بالإعلانات المؤرشفة قبل الحذف اليدوي (للمراجعة)
const int kArchiveRetentionDays = 180;

/// إعادة نشر إعلان: يمدّد صلاحيته 30 يوماً ويعيده للقوائم.
Future<void> republishProperty(PropertyDataRecord property) async {
  final me = currentUserReference;
  if (me == null || property.ownerRef != me) {
    throw Exception('not-owner');
  }
  final now = DateTime.now();
  await property.reference.update({
    'published_at': now,
    'expires_at': now.add(Duration(days: kListingDurationDays)),
    'is_archived': false,
  });
}

/// أرشفة إعلان (حذف ناعم): يختفي من العامة ويبقى عند مالكه.
Future<void> archiveProperty(PropertyDataRecord property) async {
  final me = currentUserReference;
  if (me == null || property.ownerRef != me) {
    throw Exception('not-owner');
  }
  await property.reference.update({'is_archived': true});
}

/// حذف نهائي — يُستخدم فقط بطلب صريح من المالك بعد تأكيد.
Future<void> deletePropertyPermanently(PropertyDataRecord property) async {
  final me = currentUserReference;
  if (me == null || property.ownerRef != me) {
    throw Exception('not-owner');
  }
  await property.reference.delete();
}

/// جلب صفحة واحدة من الإعلانات — Pagination حقيقية بـ cursor.
///
/// يطلب من Firestore [pageSize] وثيقة فقط (لا يجلب المجموعة كاملة)،
/// ويبدأ بعد آخر وثيقة في الصفحة السابقة عبر startAfterDocument.
/// هذا يجعل التكلفة ثابتة مهما بلغ عدد الإعلانات (50 ألف أو أكثر).
Future<List<PropertyDataRecord>> fetchPropertiesPage({
  int pageSize = 15,
  DocumentSnapshot? startAfter,
  String? category,
  String? listingType,
  String? area, // مناطق الكويت — بدل المحافظة (قرار العميل)
  int? floors,
}) async {
  Query q = PropertyDataRecord.collection
      .where('isApproved', isEqualTo: true);

  // فلاتر المساواة تُنفَّذ على الخادم (لا محلياً) فتقل الوثائق المنقولة
  if (category != null && category.trim().isNotEmpty) {
    q = q.where('category', isEqualTo: category.trim());
  }
  if (listingType != null && listingType.trim().isNotEmpty) {
    q = q.where('ListingTypy', isEqualTo: listingType.trim());
  }
  if (area != null && area.trim().isNotEmpty) {
    q = q.where('area', isEqualTo: area.trim());
  }
  if (floors != null && floors > 0) {
    q = q.where('floors', isEqualTo: floors);
  }

  q = q.orderBy('created_at', descending: true);
  if (startAfter != null) {
    q = q.startAfterDocument(startAfter);
  }
  q = q.limit(pageSize);

  final snap = await q.get();
  // استبعاد المنتهية والمؤرشفة (الفلترة الزمنية محلياً لتفادي
  // فهرس مركّب إضافي؛ الحجم صغير أصلاً — 20 وثيقة فقط)
  return snap.docs
      .map((d) => PropertyDataRecord.fromSnapshot(d))
      .where((p) => p.isLive)
      .toList();
}

/// نفس الاستعلام لكن يُرجع لقطات الوثائق أيضاً (لازمة للـ cursor).
Future<QuerySnapshot> fetchPropertiesPageSnapshot({
  int pageSize = 15,
  DocumentSnapshot? startAfter,
  String? category,
  String? listingType,
  String? area, // مناطق الكويت — بدل المحافظة (قرار العميل)
  int? floors,
}) async {
  Query q = PropertyDataRecord.collection
      .where('isApproved', isEqualTo: true);
  if (category != null && category.trim().isNotEmpty) {
    q = q.where('category', isEqualTo: category.trim());
  }
  if (listingType != null && listingType.trim().isNotEmpty) {
    q = q.where('ListingTypy', isEqualTo: listingType.trim());
  }
  if (area != null && area.trim().isNotEmpty) {
    q = q.where('area', isEqualTo: area.trim());
  }
  if (floors != null && floors > 0) {
    q = q.where('floors', isEqualTo: floors);
  }
  q = q.orderBy('created_at', descending: true);
  if (startAfter != null) {
    q = q.startAfterDocument(startAfter);
  }
  return q.limit(pageSize).get();
}

/// تسجيل مشاهدة للإعلان — مرة واحدة فقط لكل مستخدم.
/// لا تُحسب مشاهدة المالك لإعلانه، ولا تتكرر بإعادة بناء الواجهة
/// لأننا نستخدم arrayUnion (لا increment).
Future<void> recordPropertyView(PropertyDataRecord property) async {
  final me = currentUserReference;
  if (me == null) return;                       // الزائر لا يُحتسب
  if (property.ownerRef == me) return;          // المالك لا يزيد عدّاد إعلانه
  if (property.viewedBy.contains(me)) return;   // شوهد من قبل
  try {
    await property.reference.update({
      'viewed_by': FieldValue.arrayUnion([me]),
    });
  } catch (_) {
    // فشل التسجيل لا يجب أن يعطّل عرض الإعلان
  }
}

/// إرسال رسالة — نقطة واحدة يستخدمها كل التطبيق.
/// تكتب participants (مطلوبة لقواعد الأمان) و receiver_ref (للإشعارات)
/// وتحدّث ملخص المحادثة في عملية واحدة.
Future<void> sendChatMessage({
  required DocumentReference chatRef,
  required String text,
}) async {
  final me = currentUserReference;
  if (me == null || text.trim().isEmpty) return;

  final chat = await ChatsRecord.getDocumentOnce(chatRef);
  final users = chat.users.toList();
  final other = users.firstWhere((u) => u != me, orElse: () => me);

  // منع الإرسال إن كان أحد الطرفين حاظراً للآخر
  if (await isBlockedBetween(me, other)) {
    throw Exception('blocked-conversation');
  }

  await MessagesRecord.collection.doc().set({
    ...createMessagesRecordData(
      chatRef: chatRef,
      senderRef: me,
      text: text.trim(),
      createdAt: DateTime.now(),
      receiverRef: other,
      isRead: false,
    ),
    'participants': users.isNotEmpty ? users : [me, other],
    'deleted_for': <DocumentReference>[],
  });

  await chatRef.update(createChatsRecordData(
    lastMessage: text.trim(),
    lastMessageTime: DateTime.now(),
  ));
}

/// هل بين المستخدمَين حظر (بأي اتجاه)؟
Future<bool> isBlockedBetween(
    DocumentReference a, DocumentReference b) async {
  try {
    final ua = await UsersRecord.getDocumentOnce(a);
    if (ua.blockedUsers.contains(b)) return true;
    final ub = await UsersRecord.getDocumentOnce(b);
    return ub.blockedUsers.contains(a);
  } catch (_) {
    return false;
  }
}

/// حظر / فك حظر مستخدم
Future<void> setUserBlocked(DocumentReference other, bool blocked) async {
  final me = currentUserReference;
  if (me == null) return;
  await me.update({
    'blocked_users':
        blocked ? FieldValue.arrayUnion([other]) : FieldValue.arrayRemove([other]),
  });
}

/// مسح سجل المحادثة للمستخدم الحالي فقط (حذف ناعم — لا يمس الطرف الآخر)
Future<void> clearChatHistoryForMe(DocumentReference chatRef) async {
  final me = currentUserReference;
  if (me == null) return;
  final msgs = await queryMessagesRecordOnce(
    queryBuilder: (q) => q.where('chat_ref', isEqualTo: chatRef),
  );
  for (final m in msgs) {
    await m.reference.update({
      'deleted_for': FieldValue.arrayUnion([me]),
    });
  }
}

/// حذف المحادثة للمستخدم الحالي (تُخفى من قائمته)
Future<void> deleteChatForMe(DocumentReference chatRef) async {
  final me = currentUserReference;
  if (me == null) return;
  await clearChatHistoryForMe(chatRef);
  await chatRef.update({
    'deleted_for': FieldValue.arrayUnion([me]),
  });
}

/// تعليم رسائل المحادثة كمقروءة للمستخدم الحالي
Future<void> markChatAsRead(DocumentReference chatRef) async {
  final me = currentUserReference;
  if (me == null) return;
  final msgs = await queryMessagesRecordOnce(
    queryBuilder: (q) => q
        .where('chat_ref', isEqualTo: chatRef)
        .where('receiver_ref', isEqualTo: me)
        .where('is_read', isEqualTo: false),
  );
  for (final m in msgs) {
    await m.reference.update({'is_read': true});
  }
}

/// Returns an existing chat between the current user and [otherUser],
/// or creates a new one if none exists.
Future<DocumentReference> getOrCreateChat(DocumentReference otherUser) async {
  final me = currentUserReference!;
  final existing = await ChatsRecord.collection
      .where('users', arrayContains: me)
      .get()
      .then((s) => s.docs.where((d) {
            final users = (d.data() as Map<String, dynamic>)['users'];
            return users is List && users.contains(otherUser);
          }));
  if (existing.isNotEmpty) {
    return existing.first.reference;
  }
  final chatRef = ChatsRecord.collection.doc();
  await chatRef.set({
    ...createChatsRecordData(
      lastMessage: '',
      lastMessageTime: DateTime.now(),
    ),
    'users': [me, otherUser],
  });
  return chatRef;
}

Future<int> queryCollectionCount(
  Query collection, {
  Query Function(Query)? queryBuilder,
  int limit = -1,
}) {
  final builder = queryBuilder ?? (q) => q;
  var query = builder(collection);
  if (limit > 0) {
    query = query.limit(limit);
  }

  return query.count().get().catchError((err) {
    print('Error querying $collection: $err');
  }).then((value) => value.count!);
}

Stream<List<T>> queryCollection<T>(
  Query collection,
  RecordBuilder<T> recordBuilder, {
  Query Function(Query)? queryBuilder,
  int limit = -1,
  bool singleRecord = false,
}) {
  final builder = queryBuilder ?? (q) => q;
  var query = builder(collection);
  if (limit > 0 || singleRecord) {
    query = query.limit(singleRecord ? 1 : limit);
  }
  return query.snapshots().handleError((err) {
    print('Error querying $collection: $err');
  }).map((s) => s.docs
      .map(
        (d) => safeGet(
          () => recordBuilder(d),
          (e) => print('Error serializing doc ${d.reference.path}:\n$e'),
        ),
      )
      .where((d) => d != null)
      .map((d) => d!)
      .toList());
}

Future<List<T>> queryCollectionOnce<T>(
  Query collection,
  RecordBuilder<T> recordBuilder, {
  Query Function(Query)? queryBuilder,
  int limit = -1,
  bool singleRecord = false,
}) {
  final builder = queryBuilder ?? (q) => q;
  var query = builder(collection);
  if (limit > 0 || singleRecord) {
    query = query.limit(singleRecord ? 1 : limit);
  }
  return query.get().then((s) => s.docs
      .map(
        (d) => safeGet(
          () => recordBuilder(d),
          (e) => print('Error serializing doc ${d.reference.path}:\n$e'),
        ),
      )
      .where((d) => d != null)
      .map((d) => d!)
      .toList());
}

Filter filterIn(String field, List? list) => (list?.isEmpty ?? true)
    ? Filter(field, whereIn: null)
    : Filter(field, whereIn: list);

Filter filterArrayContainsAny(String field, List? list) =>
    (list?.isEmpty ?? true)
        ? Filter(field, arrayContainsAny: null)
        : Filter(field, arrayContainsAny: list);

extension QueryExtension on Query {
  Query whereIn(String field, List? list) => (list?.isEmpty ?? true)
      ? where(field, whereIn: null)
      : where(field, whereIn: list);

  Query whereNotIn(String field, List? list) => (list?.isEmpty ?? true)
      ? where(field, whereNotIn: null)
      : where(field, whereNotIn: list);

  Query whereArrayContainsAny(String field, List? list) =>
      (list?.isEmpty ?? true)
          ? where(field, arrayContainsAny: null)
          : where(field, arrayContainsAny: list);
}

class FFFirestorePage<T> {
  final List<T> data;
  final Stream<List<T>>? dataStream;
  final QueryDocumentSnapshot? nextPageMarker;

  FFFirestorePage(this.data, this.dataStream, this.nextPageMarker);
}

Future<FFFirestorePage<T>> queryCollectionPage<T>(
  Query collection,
  RecordBuilder<T> recordBuilder, {
  Query Function(Query)? queryBuilder,
  DocumentSnapshot? nextPageMarker,
  required int pageSize,
  required bool isStream,
}) async {
  final builder = queryBuilder ?? (q) => q;
  var query = builder(collection).limit(pageSize);
  if (nextPageMarker != null) {
    query = query.startAfterDocument(nextPageMarker);
  }
  Stream<QuerySnapshot>? docSnapshotStream;
  QuerySnapshot docSnapshot;
  if (isStream) {
    docSnapshotStream = query.snapshots();
    docSnapshot = await docSnapshotStream.first;
  } else {
    docSnapshot = await query.get();
  }
  final getDocs = (QuerySnapshot s) => s.docs
      .map(
        (d) => safeGet(
          () => recordBuilder(d),
          (e) => print('Error serializing doc ${d.reference.path}:\n$e'),
        ),
      )
      .where((d) => d != null)
      .map((d) => d!)
      .toList();
  final data = getDocs(docSnapshot);
  final dataStream = docSnapshotStream?.map(getDocs);
  final nextPageToken = docSnapshot.docs.isEmpty ? null : docSnapshot.docs.last;
  return FFFirestorePage(data, dataStream, nextPageToken);
}

// Creates a Firestore document representing the logged in user if it doesn't yet exist
Future maybeCreateUser(User user) async {
  final userRecord = UsersRecord.collection.doc(user.uid);
  final userExists = await userRecord.get().then((u) => u.exists);
  if (userExists) {
    currentUserDocument = await UsersRecord.getDocumentOnce(userRecord);
    return;
  }

  final userData = createUsersRecordData(
    email: user.email ??
        FirebaseAuth.instance.currentUser?.email ??
        user.providerData.firstOrNull?.email,
    displayName:
        user.displayName ?? FirebaseAuth.instance.currentUser?.displayName,
    photoUrl: user.photoURL,
    uid: user.uid,
    phoneNumber: user.phoneNumber,
    createdTime: getCurrentTimestamp,
  );

  await userRecord.set(userData);
  currentUserDocument = UsersRecord.getDocumentFromData(userData, userRecord);
}

Future updateUserDocument({String? email}) async {
  await currentUserDocument?.reference
      .update(createUsersRecordData(email: email));
}
