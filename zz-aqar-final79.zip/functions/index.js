/**
 * وظائف العقار — مُصمَّمة لأقل تكلفة ممكنة على Blaze.
 *
 * وظيفة مجدولة واحدة فقط (كما طُلب) + مشغّل كتابة واحد خفيف.
 * التقدير: أقل من 100 استدعاء يومياً — ضمن الطبقة المجانية عملياً.
 */
const { onSchedule } = require('firebase-functions/v2/scheduler');
const { onDocumentWritten } = require('firebase-functions/v2/firestore');
const { setGlobalOptions } = require('firebase-functions/v2');
const admin = require('firebase-admin');

admin.initializeApp();
const db = admin.firestore();

// سقف صارم للنسخ المتزامنة — يمنع أي انفجار في التكلفة
// nam5 = الولايات المتحدة المتعددة. الوظيفة يجب أن تكون في نفس القارة،
// وإلا عبرت كل قراءة الأطلسي (زمن أطول + رسوم خروج بيانات).
setGlobalOptions({ region: 'us-central1', maxInstances: 3 });

const MS_PER_DAY = 24 * 60 * 60 * 1000;
const LISTING_DAYS = 30;

/* ─────────────────────────────────────────────────────────
   توليد الكلمات المفتاحية للبحث العربي
   ───────────────────────────────────────────────────────── */

/**
 * تطبيع النص العربي — ضروري ليجد المستخدم "شاليه" وهو كتب "شالية".
 *  • توحيد الألف: أ إ آ ← ا
 *  • توحيد التاء المربوطة: ة ← ه
 *  • توحيد الياء: ى ← ي
 *  • حذف التشكيل والتطويل
 */
function normalizeArabic(text) {
  return String(text || '')
    .replace(/[\u064B-\u065F\u0670]/g, '') // التشكيل
    .replace(/\u0640/g, '')                // التطويل ـ
    .replace(/[أإآٱ]/g, 'ا')
    .replace(/ة/g, 'ه')
    .replace(/ى/g, 'ي')
    .replace(/[ؤئ]/g, 'ء')
    .toLowerCase()
    .trim();
}

/**
 * يبني مصفوفة الكلمات المفتاحية من البيانات الفعلية للإعلان فقط.
 * لا قيم افتراضية ولا بيانات وهمية — الحقل الفارغ يُتجاهل.
 *
 * يولّد: الكلمات الكاملة + البادئات (3 أحرف فأكثر) ليعمل البحث الجزئي.
 * مثال: "شاليه" ← شا، شال، شالي، شاليه
 */
function buildSearchKeywords(data) {
  const sources = [
    data.title,
    data.area,
    data.governorate,
    data.street,
    data.block,
    data.category,
    data.ListingTypy,
    data.description,
  ];

  const keywords = new Set();

  for (const src of sources) {
    if (!src || typeof src !== 'string') continue;
    const norm = normalizeArabic(src);
    // تقسيم على المسافات وعلامات الترقيم
    const words = norm.split(/[\s،,.\-_/\\()]+/).filter((w) => w.length >= 2);

    for (const w of words) {
      keywords.add(w);
      // بادئات للبحث الجزئي — نبدأ من 3 أحرف لتقليل حجم المصفوفة
      for (let i = 3; i < w.length; i++) {
        keywords.add(w.slice(0, i));
      }
    }
  }

  // حد Firestore العملي: نُبقي المصفوفة معقولة الحجم
  return Array.from(keywords).slice(0, 400);
}

/**
 * يحسب is_live من منطق الإعلان الحقيقي — المصدر الوحيد للحقيقة.
 * الإعلان حيّ إذا: معتمد، وغير مؤرشف، وغير محذوف، ولم تنتهِ مدته.
 */
function computeIsLive(data) {
  if (data.isApproved !== true) return false;
  if (data.is_archived === true) return false;
  if (data.is_deleted === true) return false;

  const expires = data.expires_at;
  if (expires && typeof expires.toMillis === 'function') {
    if (expires.toMillis() <= Date.now()) return false;
  }
  return true;
}

/* ─────────────────────────────────────────────────────────
   1) مشغّل الكتابة: يحافظ على is_live و search_keywords
   ───────────────────────────────────────────────────────── */
exports.onPropertyWrite = onDocumentWritten(
  'PropertyData/{propertyId}',
  async (event) => {
    const after = event.data?.after;
    if (!after || !after.exists) return null; // حُذف الإعلان

    const data = after.data();

    // expires_at: يُضبط مرة واحدة عند أول كتابة (30 يوماً من النشر)
    const patch = {};
    if (!data.expires_at) {
      const base = data.published_at?.toMillis?.()
        ?? data.created_at?.toMillis?.()
        ?? Date.now();
      patch.expires_at = admin.firestore.Timestamp.fromMillis(
        base + LISTING_DAYS * MS_PER_DAY
      );
    }

    const desiredLive = computeIsLive({ ...data, ...patch });
    if (data.is_live !== desiredLive) patch.is_live = desiredLive;

    const desiredKw = buildSearchKeywords(data);
    const currentKw = Array.isArray(data.search_keywords) ? data.search_keywords : [];
    const kwChanged =
      desiredKw.length !== currentKw.length ||
      desiredKw.some((k, i) => k !== currentKw[i]);
    if (kwChanged) patch.search_keywords = desiredKw;

    // لا كتابة إن لم يتغيّر شيء — يمنع حلقة تشغيل لا نهائية ويوفّر التكلفة
    if (Object.keys(patch).length === 0) return null;

    await after.ref.update(patch);
    return null;
  }
);

/* ─────────────────────────────────────────────────────────
   2) الوظيفة المجدولة الوحيدة: إطفاء الإعلانات المنتهية
   ───────────────────────────────────────────────────────── */
exports.expireListings = onSchedule(
  {
    schedule: 'every day 03:00',
    timeZone: 'Asia/Kuwait',
    retryCount: 1,
  },
  async () => {
    const now = admin.firestore.Timestamp.now();
    let processed = 0;

    // استعلام مُوجَّه: الإعلانات الحيّة التي انتهت مدتها فقط.
    // لا يمسح المجموعة كاملة — التكلفة تتناسب مع المنتهي فقط.
    while (true) {
      const snap = await db
        .collection('PropertyData')
        .where('is_live', '==', true)
        .where('expires_at', '<=', now)
        .limit(400)
        .get();

      if (snap.empty) break;

      const batch = db.batch();
      snap.docs.forEach((d) => batch.update(d.ref, { is_live: false }));
      await batch.commit();

      processed += snap.size;
      if (snap.size < 400) break;
    }

    console.log(`expireListings: أُطفئ ${processed} إعلاناً منتهياً`);
    return null;
  }
);

/* ─────────────────────────────────────────────────────────
   3) Migration لمرة واحدة — يُستدعى يدوياً ثم يُحذف
   ───────────────────────────────────────────────────────── */
exports.backfillListings = require('firebase-functions/v2/https').onRequest(
  { timeoutSeconds: 540, maxInstances: 1 },
  async (req, res) => {
    // حماية: يتطلب مفتاحاً يُمرَّر عبر متغير بيئة
    if (req.query.key !== process.env.BACKFILL_KEY) {
      res.status(403).send('forbidden');
      return;
    }

    let cursor = null;
    let updated = 0;
    let skipped = 0;

    while (true) {
      let q = db.collection('PropertyData').orderBy('__name__').limit(300);
      if (cursor) q = q.startAfter(cursor);
      const snap = await q.get();
      if (snap.empty) break;

      const batch = db.batch();
      let writes = 0;

      for (const doc of snap.docs) {
        const data = doc.data();
        const patch = {};

        // لا نكسر الإعلانات القديمة: نضيف الناقص فقط، ولا نحذف شيئاً
        if (!data.expires_at) {
          const base = data.published_at?.toMillis?.()
            ?? data.created_at?.toMillis?.()
            ?? Date.now();
          patch.expires_at = admin.firestore.Timestamp.fromMillis(
            base + LISTING_DAYS * MS_PER_DAY
          );
        }
        if (!Array.isArray(data.search_keywords) || data.search_keywords.length === 0) {
          patch.search_keywords = buildSearchKeywords(data);
        }
        const live = computeIsLive({ ...data, ...patch });
        if (data.is_live !== live) patch.is_live = live;

        if (Object.keys(patch).length > 0) {
          batch.update(doc.ref, patch);
          writes++;
        } else {
          skipped++;
        }
      }

      if (writes > 0) await batch.commit();
      updated += writes;
      cursor = snap.docs[snap.docs.length - 1];
      if (snap.size < 300) break;
    }

    res.json({ updated, skipped, done: true });
  }
);
